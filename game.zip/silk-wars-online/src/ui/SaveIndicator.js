/** Kleine Anzeige, wann zuletzt gespeichert wurde. */
export class SaveIndicator {
  constructor(element, { bus }) {
    this.element = element;

    bus.on('save:started', () => this.#set('speichert …', 'busy'));
    bus.on('save:done', ({ at, storage }) => {
      const time = at.toLocaleTimeString('de-DE', { hour: '2-digit', minute: '2-digit' });
      this.#set(`gespeichert ${time} (${storage})`, 'ok');
    });
    bus.on('save:failed', () => this.#set('Speichern fehlgeschlagen', 'fail'));
    bus.on('save:removed', () => this.#set('Speicherstand gelöscht', 'ok'));
  }

  #set(text, tone) {
    this.element.textContent = text;
    this.element.dataset.tone = tone;
    this.element.classList.remove('is-faded');
    clearTimeout(this._timer);
    if (tone !== 'busy') this._timer = setTimeout(() => this.element.classList.add('is-faded'), 4000);
  }
}
