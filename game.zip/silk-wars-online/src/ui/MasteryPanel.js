import { masteries, synergies } from '../game/data/masteries.js';

/**
 * Mastery- und Skillfenster (Taste K).
 *
 * Ein gemeinsamer Punkte-Pool für Mastery-Level UND Skill-Ränge — die
 * Entscheidung zwischen breit und tief trifft der Spieler hier.
 */
export class MasteryPanel {
  constructor(element, { bus, player }) {
    this.element = element;
    this.player = player;
    this.bus = bus;
    this.element.hidden = true;

    element.addEventListener('click', (event) => {
      const button = event.target.closest('button');
      if (!button) return;

      const { mastery, skill, assign } = button.dataset;
      if (mastery) this.player.skills.levelMastery(mastery);
      else if (skill) this.player.skills.rankSkill(skill);
      else if (assign) this.bus.emit('actionbar:assignRequest', { abilityId: assign });
      else if (button.dataset.clear) this.bus.emit('actionbar:clear', {});

      this.refresh();
    });

    for (const event of ['entity:levelup', 'progression:changed', 'actionbar:changed']) {
      bus.on(event, () => this.refresh());
    }
  }

  toggle() {
    this.element.hidden = !this.element.hidden;
    if (!this.element.hidden) this.refresh();
  }

  refresh() {
    if (this.element.hidden) return;
    const skills = this.player.skills;
    const overview = skills.overview();
    const active = new Set(skills.activeSynergies().map((synergy) => synergy.id));

    const group = (category) => overview
      .filter((mastery) => mastery.category === category)
      .map((mastery) => `
        <div class="mastery">
          <div class="mastery-head">
            <span class="mastery-glyph">${mastery.glyph}</span>
            <b>${mastery.name}</b>
            <span class="mastery-level">${mastery.level} / ${mastery.maxLevel}</span>
            <button type="button" data-mastery="${mastery.id}" ${mastery.canLevel ? '' : 'disabled'}>+</button>
          </div>
          ${mastery.skills.map((skill) => `
            <div class="skill ${skill.available ? '' : 'is-locked'}">
              <span class="skill-glyph">${skill.glyph}</span>
              <b>${skill.name}</b>
              <span class="skill-rank">${skill.available ? `Rang ${skill.rank} / ${skill.maxRank}` : `ab Mastery ${skill.requires}`}</span>
              <button type="button" data-skill="${skill.ability}" ${skill.canRank ? '' : 'disabled'}>+</button>
              <button type="button" data-assign="${skill.ability}" ${skill.rank > 0 ? '' : 'disabled'} title="Auf die Leiste legen">▤</button>
            </div>`).join('')}
        </div>`).join('');

    this.element.innerHTML = `
      <p class="panel-title">Masteries</p>
      <p class="panel-note">${skills.points} Punkte frei — ein Pool für Mastery-Level und Skill-Ränge</p>
      <div class="panel-footer"><button type="button" data-clear="1">Action-Bars leeren</button></div>
      <div class="mastery-columns">
        <div><p class="mastery-category">Waffen</p>${group('weapon')}</div>
        <div><p class="mastery-category">Magie</p>${group('magic')}</div>
      </div>
      <p class="mastery-category">Synergien</p>
      <ul class="synergy-list">
        ${[...this.#synergyRows(active)].join('')}
      </ul>`;
  }

  *#synergyRows(active) {
    const skills = this.player.skills;
    for (const id of synergies.ids()) {
      const synergy = synergies.get(id);
      const requirements = Object.entries(synergy.requires)
        .map(([masteryId, level]) => `${masteries.get(masteryId).name} ${skills.masteryLevel(masteryId)}/${level}`)
        .join(', ');
      yield `<li class="${active.has(id) ? 'is-active' : ''}"><b>${synergy.name}</b><span>${requirements}</span></li>`;
    }
  }
}
