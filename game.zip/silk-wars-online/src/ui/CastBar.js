/** Ladebalken für Fähigkeiten mit Ladezeit. */
export class CastBar {
  constructor(element, { bus, playerId = 'player' }) {
    this.element = element;
    this.fill = element.querySelector('i');
    this.label = element.querySelector('b');
    this.element.hidden = true;

    bus.on('cast:started', ({ id, name, castTime, element: school }) => {
      if (id !== playerId) return;
      this.element.hidden = false;
      this.element.dataset.element = school;
      this.label.textContent = `${name} — ${castTime.toFixed(1)} s`;
      this.fill.style.width = '0%';
    });

    bus.on('cast:progress', ({ id, progress }) => {
      if (id !== playerId) return;
      this.fill.style.width = `${(progress * 100).toFixed(0)}%`;
    });

    bus.on('cast:finished', ({ id }) => { if (id === playerId) this.element.hidden = true; });
    bus.on('cast:cancelled', ({ id, reason }) => {
      if (id !== playerId) return;
      this.element.hidden = true;
      bus.emit('ui:notice', { text: `Zauber unterbrochen (${reason})`, tone: 'warn' });
    });
  }
}
