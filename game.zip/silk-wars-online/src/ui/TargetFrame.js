const FACTION_LABEL = {
  hostile: 'feindlich',
  neutral: 'neutral',
  player: 'verbündet',
};

/** Rahmen des ausgewählten Ziels: Name, Stufe, Leben, Entfernung. */
export class TargetFrame {
  constructor(element, { bus }) {
    this.element = element;
    this.name = element.querySelector('[data-field="name"]');
    this.meta = element.querySelector('[data-field="meta"]');
    this.fill = element.querySelector('[data-bar="health"] i');
    this.label = element.querySelector('[data-bar="health"] b');
    this.targetId = null;
    this.element.hidden = true;

    bus.on('target:changed', (payload) => this.#setTarget(payload));

    bus.on('entity:resources', (payload) => {
      if (payload.id !== this.targetId) return;
      this.#setHealth(payload.health, payload.maxHealth);
    });

    bus.on('entity:died', ({ id }) => {
      if (id === this.targetId) this.element.classList.add('is-dead');
    });

    bus.on('entity:revived', ({ id }) => {
      if (id === this.targetId) this.element.classList.remove('is-dead');
    });
  }

  #setTarget({ id, entity, name, level, faction }) {
    this.targetId = id;
    this.element.hidden = !id;
    if (!entity) return;

    this.element.classList.toggle('is-dead', !entity.isAlive);
    this.element.dataset.faction = faction ?? 'neutral';
    this.name.textContent = `${name} — Stufe ${level}`;
    this.meta.textContent = FACTION_LABEL[faction] ?? faction ?? '';
    this.#setHealth(entity.resources.health, entity.resources.maxHealth);
  }

  #setHealth(value, max) {
    const ratio = max > 0 ? value / max : 0;
    this.fill.style.width = `${Math.max(0, ratio * 100).toFixed(1)}%`;
    this.label.textContent = `${Math.round(value)} / ${Math.round(max)}`;
  }

  /** Entfernung wird pro Frame nachgereicht, nicht als Ereignis gesendet. */
  updateDistance(distance) {
    if (!this.targetId || distance === null) return;
    const faction = FACTION_LABEL[this.element.dataset.faction] ?? '';
    this.meta.textContent = `${faction} · ${distance.toFixed(1)} m`;
  }
}
