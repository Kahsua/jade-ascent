import { EQUIPMENT_SLOTS, SLOT_LABELS, items } from '../game/data/items.js';

const RARITY_LABEL = { common: 'gewöhnlich', rare: 'selten' };

const STAT_LABELS = {
  physicalPower: 'Physischer Schaden',
  magicPower: 'Magieschaden',
  armor: 'Rüstung',
  magicResist: 'Magieresistenz',
  maxHealth: 'Leben',
  maxMana: 'Mana',
  healthRegen: 'Lebensregeneration',
  manaRegen: 'Manaregeneration',
  critChance: 'Kritchance',
  critDamage: 'Kritschaden',
};

function formatStats(stats = {}) {
  return Object.entries(stats)
    .filter(([, value]) => value !== 0)
    .map(([stat, value]) => {
      const label = STAT_LABELS[stat] ?? stat;
      const formatted = stat.startsWith('crit') ? `${(value * 100).toFixed(1)} %` : value.toFixed(stat.includes('Regen') ? 2 : 0);
      return `${label} +${formatted}`;
    })
    .join(', ');
}

/**
 * Ausrüstung und Gepäck (Taste I).
 *
 * Das Fenster sendet nur Befehle — "equipment:equip" und "equipment:unequip".
 * Ob etwas passt, entscheidet die Equipment-Komponente anhand der Item-Daten,
 * nicht die Oberfläche.
 */
export class EquipmentPanel {
  constructor(element, { bus, player }) {
    this.element = element;
    this.bus = bus;
    this.player = player;
    this.element.hidden = true;

    element.addEventListener('click', (event) => {
      const button = event.target.closest('button');
      if (!button) return;

      if (button.dataset.equip) {
        bus.emit('equipment:equip', { id: player.id, itemId: button.dataset.equip, slot: button.dataset.slot || null });
      } else if (button.dataset.unequip) {
        bus.emit('equipment:unequip', { id: player.id, slot: button.dataset.unequip });
      }
      this.refresh();
    });

    for (const event of ['entity:equipment', 'entity:inventory', 'entity:levelup']) {
      bus.on(event, () => this.refresh());
    }
  }

  toggle() {
    this.element.hidden = !this.element.hidden;
    if (!this.element.hidden) this.refresh();
  }

  refresh() {
    if (this.element.hidden) return;
    const equipment = this.player.equipment;
    const bonuses = equipment.bonuses();

    const slotRows = EQUIPMENT_SLOTS.map((slot) => {
      const item = equipment.definition(slot);
      return `
        <div class="equip-slot ${item ? '' : 'is-empty'}">
          <span class="equip-slot-name">${SLOT_LABELS[slot]}</span>
          <span class="equip-item">${item ? item.name : '—'}</span>
          <span class="equip-stats">${item ? formatStats(item.stats) : ''}</span>
          <button type="button" data-unequip="${slot}" ${item ? '' : 'disabled'} title="Ablegen">×</button>
        </div>`;
    }).join('');

    // Gepäck: gleiche Gegenstände zusammenfassen.
    const counts = new Map();
    for (const id of equipment.inventory) counts.set(id, (counts.get(id) ?? 0) + 1);

    const bagRows = [...counts.entries()].map(([id, count]) => {
      const item = items.get(id);
      const check = equipment.canEquip(id);
      const offhand = equipment.canEquip(id, 'offHand');
      return `
        <div class="bag-item rarity-${item.rarity ?? 'common'}">
          <span class="equip-item">${item.name}${count > 1 ? ` ×${count}` : ''}</span>
          <span class="equip-stats">${SLOT_LABELS[item.slot]} · ${RARITY_LABEL[item.rarity] ?? ''} · ${formatStats(item.stats)}</span>
          <button type="button" data-equip="${id}" ${check.ok ? '' : 'disabled'} title="${check.ok ? 'Anlegen' : check.reason}">Anlegen</button>
          ${item.dualWield ? `<button type="button" data-equip="${id}" data-slot="offHand" ${offhand.ok ? '' : 'disabled'} title="${offhand.ok ? 'In die Nebenhand' : offhand.reason}">NH</button>` : ''}
        </div>`;
    }).join('') || '<p class="panel-note">Gepäck ist leer</p>';

    this.element.innerHTML = `
      <p class="panel-title">Ausrüstung</p>
      <div class="equip-slots">${slotRows}</div>
      <p class="panel-note">Boni gesamt: ${formatStats(bonuses) || 'keine'}</p>
      <p class="mastery-category">Gepäck</p>
      <div class="bag">${bagRows}</div>`;
  }
}
