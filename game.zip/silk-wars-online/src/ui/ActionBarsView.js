import { abilities } from '../game/data/abilities.js';

const KEY_LABELS = [
  ['1', '2', '3', '4', '5', '6', '7', '8'],
  ['F1', 'F2', 'F3', 'F4', 'F5', 'F6', 'F7', 'F8'],
];

/**
 * Zwei Leisten mit je acht Slots. Ein Slot zeigt nur, was seine Ability-ID
 * hergibt — er kennt keine Kategorien. Abklingzeiten und Drag & Drop kommen
 * in Phase 5 bzw. später dazu; das Markup ist darauf schon vorbereitet.
 */
export class ActionBarsView {
  constructor(element, { bus, bars }) {
    this.element = element;
    this.slots = [];

    bars.forEach((bar, barIndex) => {
      const row = document.createElement('div');
      row.className = 'actionbar';

      bar.forEach((abilityId, slotIndex) => {
        const slot = document.createElement('button');
        slot.className = 'slot';
        slot.type = 'button';
        slot.dataset.bar = String(barIndex);
        slot.dataset.slot = String(slotIndex);
        slot.innerHTML = '<span class="slot-glyph"></span><span class="slot-key"></span>'
          + '<span class="slot-charges"></span><span class="slot-rank"></span>'
          + '<span class="slot-cooldown"></span><span class="slot-timer"></span>';
        slot.querySelector('.slot-key').textContent = KEY_LABELS[barIndex][slotIndex];
        row.appendChild(slot);
        this.slots.push(slot);
        this.#fill(slot, abilityId);
      });

      element.appendChild(row);
    });

    element.addEventListener('click', (event) => {
      const slot = event.target.closest('.slot');
      if (!slot) return;
      bus.emit('actionbar:activate', { bar: Number(slot.dataset.bar), index: Number(slot.dataset.slot) });
    });

    bus.on('actionbar:changed', ({ bar, index, abilityId }) => {
      this.#fill(this.#slot(bar, index), abilityId);
    });

    bus.on('actionbar:used', ({ bar, index }) => {
      const slot = this.#slot(bar, index);
      if (!slot) return;
      slot.classList.add('is-flashing');
      setTimeout(() => slot.classList.remove('is-flashing'), 220);
    });
  }

  /**
   * Abklingzeiten und Ladungen pro Frame nachziehen. Bewusst kein Ereignis:
   * ein Timer, der jede Sekunde 60 Meldungen erzeugt, wäre teurer als das
   * direkte Ablesen der Komponente.
   */
  update(cooldowns, skills = null) {
    for (const slot of this.slots) {
      const abilityId = slot.dataset.ability;
      if (!abilityId) continue;

      const ability = abilities.get(abilityId);

      // Nicht erlernte Fähigkeiten bleiben sichtbar, aber gesperrt.
      if (skills) {
        const unlocked = skills.isUnlocked(abilityId);
        const rank = skills.rankOf(abilityId);
        slot.classList.toggle('is-unlearned', !unlocked);
        slot.querySelector('.slot-rank').textContent = rank > 0 ? `R${rank}` : '';
      }

      const charges = cooldowns.chargesOf(abilityId);
      const sweep = slot.querySelector('.slot-cooldown');
      const timer = slot.querySelector('.slot-timer');
      const badge = slot.querySelector('.slot-charges');

      if (ability.charges) {
        const current = charges?.current ?? ability.charges;
        badge.textContent = String(current);
        const progress = current >= (charges?.max ?? ability.charges) ? 1 : cooldowns.chargeProgress(abilityId);
        sweep.style.height = `${Math.round((1 - progress) * 100)}%`;
        timer.textContent = '';
        slot.classList.toggle('is-locked', current === 0);
        continue;
      }

      const remaining = cooldowns.remaining(abilityId);
      const ratio = ability.cooldown > 0 ? remaining / ability.cooldown : 0;
      sweep.style.height = `${Math.round(ratio * 100)}%`;
      timer.textContent = remaining > 0.05 ? remaining.toFixed(remaining < 3 ? 1 : 0) : '';
      slot.classList.toggle('is-locked', remaining > 0);
    }
  }

  #slot(bar, index) {
    return this.slots.find((slot) => slot.dataset.bar === String(bar) && slot.dataset.slot === String(index));
  }

  #fill(slot, abilityId) {
    if (!slot) return;
    const definition = abilityId ? abilities.find(abilityId) : null;
    slot.dataset.ability = abilityId ?? '';
    slot.querySelector('.slot-glyph').textContent = definition?.glyph ?? '';
    slot.classList.toggle('is-empty', !definition);
    slot.title = definition ? `${definition.name} — ${definition.description}` : 'leer';
  }
}
