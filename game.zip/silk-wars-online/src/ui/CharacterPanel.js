const ATTRIBUTES = [
  ['strength', 'Stärke', 'physischer Schaden'],
  ['dexterity', 'Geschicklichkeit', 'Kritchance und Kritschaden'],
  ['intelligence', 'Intelligenz', 'Magieschaden und Mana'],
  ['vitality', 'Vitalität', 'Leben, Rüstung, Regeneration'],
];

/** Charakterfenster (Taste C): Attribute verteilen, abgeleitete Werte lesen. */
export class CharacterPanel {
  constructor(element, { bus, player, progression }) {
    this.element = element;
    this.player = player;
    this.progression = progression;
    this.bus = bus;
    this.element.hidden = true;

    element.addEventListener('click', (event) => {
      const button = event.target.closest('button');
      if (!button) return;

      if (button.dataset.command) return this.bus.emit('input:command', { name: button.dataset.command });
      if (!button.dataset.attribute) return;
      if (this.progression.spendAttributePoint(button.dataset.attribute)) this.refresh();
    });

    for (const event of ['entity:levelup', 'progression:changed', 'entity:experience']) {
      bus.on(event, () => this.refresh());
    }
  }

  toggle() {
    this.element.hidden = !this.element.hidden;
    if (!this.element.hidden) this.refresh();
  }

  refresh() {
    if (this.element.hidden) return;
    const state = this.player.state;
    const stats = this.player.stats;
    const points = state.unspentAttributePoints;

    this.element.innerHTML = `
      <p class="panel-title">${state.name} — Stufe ${state.level}</p>
      <p class="panel-note">${points > 0 ? `${points} Attributpunkte frei` : 'keine freien Attributpunkte'}</p>
      <table class="attribute-table">
        ${ATTRIBUTES.map(([key, label, note]) => `
          <tr>
            <td><b>${label}</b><span>${note}</span></td>
            <td class="value">${state.attributes[key]}</td>
            <td><button type="button" data-attribute="${key}" ${points > 0 ? '' : 'disabled'}>+</button></td>
          </tr>`).join('')}
      </table>
      <dl class="stat-list">
        <dt>Leben</dt><dd>${stats.maxHealth.toFixed(0)} (+${stats.healthRegen.toFixed(2)}/s)</dd>
        <dt>Mana</dt><dd>${stats.maxMana.toFixed(0)} (+${stats.manaRegen.toFixed(2)}/s)</dd>
        <dt>Physischer Schaden</dt><dd>${stats.physicalPower.toFixed(1)}</dd>
        <dt>Magieschaden</dt><dd>${stats.magicPower.toFixed(1)}</dd>
        <dt>Kritchance</dt><dd>${(stats.critChance * 100).toFixed(1)} % (x${stats.critDamage.toFixed(2)})</dd>
        <dt>Rüstung / Magieres.</dt><dd>${stats.armor.toFixed(1)} / ${stats.magicResist.toFixed(1)}</dd>
      </dl>
      <div class="panel-footer">
        <button type="button" data-command="save">Jetzt speichern</button>
        <button type="button" data-command="resetSave">Neu beginnen</button>
      </div>`;
  }
}
