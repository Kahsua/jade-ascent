import { experienceForLevel } from '../game/stats/deriveStats.js';

/**
 * Leben, Mana und Erfahrung des Spielers.
 *
 * Hört nur auf Ereignisse — das Frame kennt weder Entity noch Spielregeln.
 * Die XP-Leiste zeigt bereits den Fortschritt; das Level-Up selbst kommt in
 * Phase 8.
 */
export class PlayerFrame {
  constructor(element, { bus, playerId = 'player' }) {
    this.element = element;
    this.playerId = playerId;

    this.name = element.querySelector('[data-field="name"]');
    this.health = element.querySelector('[data-bar="health"] i');
    this.healthText = element.querySelector('[data-bar="health"] b');
    this.mana = element.querySelector('[data-bar="mana"] i');
    this.manaText = element.querySelector('[data-bar="mana"] b');
    this.experience = element.querySelector('[data-bar="experience"] i');
    this.experienceText = element.querySelector('[data-bar="experience"] b');

    bus.on('entity:resources', (payload) => {
      if (payload.id !== this.playerId) return;
      this.#setBar(this.health, this.healthText, payload.health, payload.maxHealth);
      this.#setBar(this.mana, this.manaText, payload.mana, payload.maxMana);
    });

    bus.on('entity:experience', ({ id, experience, level }) => {
      if (id !== this.playerId) return;
      this.#setExperience(experience, level);
    });

    bus.on('entity:levelup', ({ id, level }) => {
      if (id !== this.playerId) return;
      this.name.textContent = this.name.textContent.replace(/Stufe \d+/, `Stufe ${level}`);
      this.element.classList.add('is-levelup');
      setTimeout(() => this.element.classList.remove('is-levelup'), 1200);
    });
  }

  setCharacter(state) {
    this.name.textContent = `${state.name} — Stufe ${state.level}`;
    this.#setExperience(state.experience ?? 0, state.level);
  }

  #setBar(fill, label, value, max) {
    const ratio = max > 0 ? value / max : 0;
    fill.style.width = `${Math.max(0, ratio * 100).toFixed(1)}%`;
    label.textContent = `${Math.round(value)} / ${Math.round(max)}`;
  }

  #setExperience(experience, level) {
    const needed = experienceForLevel(level);
    this.#setBar(this.experience, this.experienceText, experience, needed);
  }
}
