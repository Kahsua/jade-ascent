/**
 * Bildschirmknöpfe für Geräte ohne Tastatur.
 *
 * Sie senden nur "input:command" — dieselben Befehle, die auch die Tastatur
 * auslöst. Dadurch gibt es keine zweite Steuerungslogik, die auseinanderlaufen
 * könnte.
 */
const BUTTONS = [
  { command: 'dodge', label: '»', title: 'Ausweichen' },
  { command: 'cycleTarget', label: '⌖', title: 'Nächstes Ziel' },
  { command: 'toggleAuto', label: '⚔', title: 'Autoattack' },
  { command: 'cancel', label: '×', title: 'Abbrechen' },
  { command: 'unstuck', label: '⎋', title: 'Festgefahren? Zurück zum Ausgangspunkt' },
];

const WINDOWS = [
  { panel: 'character', label: 'C', title: 'Charakter' },
  { panel: 'mastery', label: 'K', title: 'Masteries' },
  { panel: 'equipment', label: 'I', title: 'Ausrüstung' },
];

/** Nur im Testmodus sichtbar. */
const GM_BUTTONS = [
  { command: 'god', label: '∞', title: 'Unverwundbarkeit an/aus' },
  { command: 'freeCasts', label: '⚡', title: 'Keine Kosten an/aus' },
];

export class TouchControls {
  constructor(root, { bus }) {
    this.root = root;
    this.bus = bus;

    root.querySelector('[data-role="cluster"]').innerHTML = BUTTONS
      .map((entry) => `<button type="button" class="touch-button" data-command="${entry.command}" title="${entry.title}">${entry.label}</button>`)
      .join('');

    const gm = document.body.classList.contains('gm-mode');
    root.querySelector('[data-role="windows"]').innerHTML = (gm ? [...WINDOWS, ...GM_BUTTONS] : WINDOWS)
      .map((entry) => (entry.panel
        ? `<button type="button" class="touch-button touch-button-small" data-panel="${entry.panel}" title="${entry.title}">${entry.label}</button>`
        : `<button type="button" class="touch-button touch-button-small" data-command="${entry.command}" title="${entry.title}">${entry.label}</button>`))
      .join('');

    root.addEventListener('click', (event) => {
      const button = event.target.closest('button');
      if (!button) return;

      if (button.dataset.command) bus.emit('input:command', { name: button.dataset.command });
      else if (button.dataset.panel) bus.emit('input:command', { name: 'panel', args: [button.dataset.panel] });
    });

    // Verhindert, dass ein Tippen auf einen Knopf zusätzlich als Weltklick ankommt.
    root.addEventListener('touchstart', (event) => event.stopPropagation(), { passive: true });
  }

  enable() {
    this.root.hidden = false;
    document.body.classList.add('touch-mode');
  }
}
