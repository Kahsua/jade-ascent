/** Einblendung nach dem Tod mit Countdown bis zum Wiedereinstieg. */
export class DeathOverlay {
  constructor(element, { bus, playerId = 'player' }) {
    this.element = element;
    this.text = element.querySelector('[data-field="text"]');
    this.remaining = 0;
    this.element.hidden = true;

    bus.on('entity:defeated', ({ id, delay, isPlayer }) => {
      if (id !== playerId || !isPlayer) return;
      this.remaining = delay;
      this.element.hidden = false;
    });

    bus.on('entity:revived', ({ id }) => {
      if (id !== playerId) return;
      this.remaining = 0;
      this.element.hidden = true;
    });
  }

  update(dt) {
    if (this.element.hidden) return;
    this.remaining = Math.max(0, this.remaining - dt);
    this.text.textContent = `Wiedereinstieg in ${Math.ceil(this.remaining)} s`;
  }
}
