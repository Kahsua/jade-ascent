/** Kleines HUD-Feld für die sichtbar getragene Ausrüstung (Phase-2-Demo). */
export class LoadoutReadout {
  constructor(element) {
    this.element = element;
  }

  update(mainHand, offHand) {
    this.element.innerHTML = [
      `<p class="hint-line"><span class="key">Haupthand</span>${mainHand ?? 'leer'}</p>`,
      `<p class="hint-line"><span class="key">Nebenhand</span>${offHand ?? 'leer'}</p>`,
    ].join('');
  }
}
