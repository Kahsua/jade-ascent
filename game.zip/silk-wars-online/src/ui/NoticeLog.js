/** Kurze Rückmeldungen ("kein Ziel", "außer Reichweite") über der Action-Bar. */
export class NoticeLog {
  constructor(element, { bus, lifetime = 3200, max = 4 }) {
    this.element = element;
    this.lifetime = lifetime;
    this.max = max;
    bus.on('ui:notice', (payload) => this.push(payload));
  }

  push({ text, tone = 'info' }) {
    const line = document.createElement('p');
    line.className = `notice notice-${tone}`;
    line.textContent = text;
    this.element.appendChild(line);

    while (this.element.children.length > this.max) this.element.firstElementChild.remove();

    setTimeout(() => {
      line.classList.add('is-fading');
      setTimeout(() => line.remove(), 400);
    }, this.lifetime);
  }
}
