import { CONFIG } from '../core/Config.js';

/** Kleines Zahlenfenster (F3). Liest nur, schreibt nie in den Spielzustand. */
export class DebugOverlay {
  constructor(element, { loop, player, camera, entities }) {
    this.element = element;
    this.loop = loop;
    this.player = player;
    this.camera = camera;
    this.entities = entities;
    this.visible = CONFIG.debug.overlayVisible;
    this._accumulator = 0;
    this.element.hidden = !this.visible;
  }

  toggle() {
    this.visible = !this.visible;
    this.element.hidden = !this.visible;
  }

  update(dt) {
    if (!this.visible) return;
    this._accumulator += dt;
    if (this._accumulator < 0.2) return;
    this._accumulator = 0;

    const state = this.player.state;
    const stats = this.player.stats;
    this.element.textContent = [
      `fps        ${this.loop.stats.fps.toFixed(0)}`,
      `frame      ${this.loop.stats.frameTime.toFixed(1)} ms`,
      `position   ${state.position.x.toFixed(1)} / ${state.position.y.toFixed(1)} / ${state.position.z.toFixed(1)}`,
      `tempo      ${state.speed.toFixed(2)} m/s`,
      `kamera     yaw ${this.camera.yaw.toFixed(2)}  dist ${this.camera.distance.toFixed(1)}`,
      `entities   ${this.entities.all().length}`,
      '',
      `leben      ${this.player.resources.health.toFixed(0)} / ${stats.maxHealth.toFixed(0)}  (+${stats.healthRegen.toFixed(2)}/s)`,
      `mana       ${this.player.resources.mana.toFixed(0)} / ${stats.maxMana.toFixed(0)}  (+${stats.manaRegen.toFixed(2)}/s)`,
      `phys/magie ${stats.physicalPower.toFixed(1)} / ${stats.magicPower.toFixed(1)}`,
      `krit       ${(stats.critChance * 100).toFixed(1)} %  x${stats.critDamage.toFixed(2)}`,
      `rüstung    ${stats.armor.toFixed(1)}  magieres ${stats.magicResist.toFixed(1)}`,
    ].join('\n');
  }
}
