/**
 * Buff-/Debuff-Leiste. Wird wie die Abklingzeiten pro Frame aus dem
 * StatusEffectController abgelesen; neu aufgebaut wird das Markup nur, wenn
 * sich die Menge der Effekte ändert.
 */
export class StatusBar {
  #signature = '';

  constructor(element) {
    this.element = element;
    this.pills = new Map();
  }

  render(effects = []) {
    const signature = effects.map((effect) => `${effect.id}:${effect.stacks}`).join('|');

    if (signature !== this.#signature) {
      this.#signature = signature;
      this.element.innerHTML = '';
      this.pills.clear();

      for (const effect of effects) {
        const pill = document.createElement('span');
        pill.className = `status-pill status-${effect.category}`;
        pill.title = effect.name;
        pill.innerHTML = `<b>${effect.glyph}</b>${effect.stacks > 1 ? `<u>${effect.stacks}</u>` : ''}<i></i><em></em>`;
        this.element.appendChild(pill);
        this.pills.set(effect.id, pill);
      }
    }

    for (const effect of effects) {
      const pill = this.pills.get(effect.id);
      if (!pill) continue;
      pill.querySelector('i').style.width = `${Math.max(0, (effect.remaining / effect.duration) * 100).toFixed(0)}%`;
      pill.querySelector('em').textContent = effect.remaining >= 1
        ? `${Math.ceil(effect.remaining)}`
        : effect.remaining.toFixed(1);
    }
  }
}
