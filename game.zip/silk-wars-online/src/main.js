import { CONFIG } from './core/Config.js';
import { EventBus } from './core/EventBus.js';
import { GameLoop } from './core/GameLoop.js';

import { PlayerState } from './game/PlayerState.js';
import { MovementSystem } from './game/MovementSystem.js';
import { EntityManager } from './game/entities/EntityManager.js';
import { TargetingSystem } from './game/targeting/TargetingSystem.js';
import { ActionBarSystem } from './game/ActionBarSystem.js';
import { AbilityExecutor } from './game/abilities/AbilityExecutor.js';
import { ProjectileSystem } from './game/combat/ProjectileSystem.js';
import { AutoAttackSystem } from './game/combat/AutoAttackSystem.js';
import { AiSystem } from './game/ai/AiSystem.js';
import { RespawnSystem } from './game/world/RespawnSystem.js';
import { ProgressionSystem } from './game/progression/ProgressionSystem.js';
import { SaveSystem } from './game/persistence/SaveSystem.js';
import { createStorage } from './game/persistence/createStorage.js';
import { stateFromSave, restoreResources } from './game/persistence/SaveGame.js';
import { abilities } from './game/data/abilities.js';
import { heightAt } from './game/Heightfield.js';

import { InputController } from './input/InputController.js';
import { TouchController } from './input/TouchController.js';
import { InputRouter } from './input/InputRouter.js';

import { RenderView } from './render/RenderView.js';
import { CameraController } from './render/CameraController.js';
import { createTerrainMesh } from './render/TerrainMesh.js';
import { buildEnvironment } from './render/EnvironmentBuilder.js';
import { assets, registerDefaultModels } from './render/AssetRegistry.js';
import { ViewManager } from './render/ViewManager.js';
import { EntityPicker } from './render/EntityPicker.js';
import { SelectionRing, GroundReticle } from './render/indicators.js';
import { NameplateLayer } from './render/views/NameplateLayer.js';
import { FloatingTextLayer } from './render/views/FloatingTextLayer.js';
import { ProjectileLayer } from './render/ProjectileLayer.js';
import { EffectLayer } from './render/effects.js';

import { DebugOverlay } from './ui/DebugOverlay.js';
import { LoadoutReadout } from './ui/LoadoutReadout.js';
import { PlayerFrame } from './ui/PlayerFrame.js';
import { StatusBar } from './ui/StatusBar.js';
import { DeathOverlay } from './ui/DeathOverlay.js';
import { CharacterPanel } from './ui/CharacterPanel.js';
import { TouchControls } from './ui/TouchControls.js';
import { SaveIndicator } from './ui/SaveIndicator.js';
import { labelOfItem } from './game/data/items.js';
import { MasteryPanel } from './ui/MasteryPanel.js';
import { TargetFrame } from './ui/TargetFrame.js';
import { ActionBarsView } from './ui/ActionBarsView.js';
import { NoticeLog } from './ui/NoticeLog.js';
import { EquipmentPanel } from './ui/EquipmentPanel.js';

/** Verdrahtung — und nur Verdrahtung. Keine Spielregeln in dieser Datei. */

const POPULATION = [
  { template: 'npc.villager', x: -7, z: 3, facing: 0.7 },
  { template: 'npc.warrior', x: 6.5, z: 4, facing: -0.8 },
  { template: 'npc.archer', x: -4, z: -7, facing: 2.6 },
  { template: 'npc.mage', x: 4.5, z: -8, facing: 3.5 },
  { template: 'beast.wolf', x: 11, z: -3, facing: 1.3 },
  { template: 'beast.wolf', x: 14, z: -8, facing: 2.1 },
];

async function boot() {
  const canvas = document.getElementById('game-canvas');
  const bus = new EventBus();

  // --- Anzeige -------------------------------------------------------------
  const view = new RenderView(canvas);
  const terrain = createTerrainMesh();
  view.scene.add(terrain);

  const environment = buildEnvironment();
  view.scene.add(environment.group);

  registerDefaultModels();
  const views = new ViewManager({ scene: view.scene, bus });
  const selectionRing = new SelectionRing(view.scene);
  const reticle = new GroundReticle(view.scene);

  // --- Eingabe & Kamera ----------------------------------------------------
  // Berührungsgeräte bekommen zusätzlich Stick, Gesten und Bildschirmknöpfe.
  // Erzwingen lässt sich das zum Ausprobieren mit ?touch=1 in der Adresse.
  const touchMode = window.matchMedia?.('(pointer: coarse)').matches
    || new URLSearchParams(window.location.search).has('touch');

  const keyboard = new InputController(canvas);
  const input = new InputRouter([keyboard]);

  if (touchMode) {
    input.add(new TouchController(canvas, {
      stickElement: document.getElementById('touch-stick'),
      knobElement: document.getElementById('touch-knob'),
      radius: CONFIG.touch.stickRadius,
    }));
    new TouchControls(document.getElementById('touch-ui'), { bus }).enable();
  }
  const camera = new CameraController(view.camera, input, {
    obstacles: [terrain, environment.group],
  });
  const picker = new EntityPicker({ camera: view.camera, viewManager: views, terrain });

  const nameplates = new NameplateLayer({
    container: document.getElementById('nameplates'),
    camera: view.camera,
    bus,
    exclude: 'player',
  });

  // --- Logik ---------------------------------------------------------------
  const entities = new EntityManager({ bus });
  const movement = new MovementSystem({ colliders: environment.colliders, bus });

  // Speicherstand laden, bevor der Spieler entsteht — dann muss nichts
  // nachträglich in eine bestehende Entity gespiegelt werden.
  const storage = createStorage();
  const saveSystem = new SaveSystem({ entities, bus, storage });
  const saved = await saveSystem.load();

  const playerState = stateFromSave(saved, { position: { x: 0, z: 4 } });
  const player = entities.spawn('player', { state: playerState });
  if (saved) restoreResources(player, saved);

  for (const spot of POPULATION) {
    entities.spawn(spot.template, {
      position: { x: spot.x, y: heightAt(spot.x, spot.z), z: spot.z },
      facing: spot.facing,
    });
  }

  const targeting = new TargetingSystem({ entities, bus, ownerId: player.id });
  const actionBars = new ActionBarSystem({ state: playerState, bus, targeting });

  // Kampf: ein Executor für alle Fähigkeiten, ein Geschosssystem, ein
  // Autoattack-System, das sich seine Fähigkeit aus der Waffe holt.
  const projectiles = new ProjectileSystem({ entities, bus });
  new AbilityExecutor({ entities, bus, projectiles });
  const autoAttack = new AutoAttackSystem({ entities, bus, targeting, ownerId: player.id });

  // KI und Wiedereinstieg: Monster laufen durch dieselbe Bewegung und
  // greifen über dieselbe Ability-Pipeline an wie der Spieler.
  const ai = new AiSystem({ entities, bus, movement, playerId: player.id });
  const respawn = new RespawnSystem({ entities, bus });
  const progression = new ProgressionSystem({ entities, bus, playerId: player.id });

  const projectileLayer = new ProjectileLayer({ scene: view.scene, bus, projectiles });
  const effects = new EffectLayer({ scene: view.scene, bus });
  new FloatingTextLayer({ container: document.getElementById('floaters'), camera: view.camera, entities, bus });

  // --- UI ------------------------------------------------------------------
  const loop = new GameLoop(bus);
  const debug = new DebugOverlay(document.getElementById('debug-panel'), { loop, player, camera, entities });
  const loadout = new LoadoutReadout(document.getElementById('loadout'));
  const playerFrame = new PlayerFrame(document.getElementById('player-frame'), { bus });
  const targetFrame = new TargetFrame(document.getElementById('target-frame'), { bus });
  const deathOverlay = new DeathOverlay(document.getElementById('death-overlay'), { bus });
  new SaveIndicator(document.getElementById('save-indicator'), { bus });
  const characterPanel = new CharacterPanel(document.getElementById('character-panel'), { bus, player, progression });
  const masteryPanel = new MasteryPanel(document.getElementById('mastery-panel'), { bus, player });
  const playerStatus = new StatusBar(document.getElementById('player-status'));
  const targetStatus = new StatusBar(document.getElementById('target-status'));
  const notices = new NoticeLog(document.getElementById('notices'), { bus });
  const equipment = new EquipmentPanel(document.getElementById('equipment-panel'), { bus, player });
  const actionBarsView = new ActionBarsView(document.getElementById('action-bars'), { bus, bars: playerState.actionBars });
  playerFrame.setCharacter(playerState);

  // Befehle an die Ausrüstungs-Komponente. Ob etwas passt, entscheidet sie —
  // die Oberfläche kennt die Regeln nicht.
  bus.on('equipment:equip', ({ id, itemId, slot }) => {
    const entity = entities.get(id);
    const result = entity?.equipment?.equip(itemId, slot);
    if (result && !result.ok) bus.emit('ui:notice', { text: result.reason, tone: 'warn' });
  });

  bus.on('equipment:unequip', ({ id, slot }) => entities.get(id)?.equipment?.unequip(slot));

  bus.on('entity:equipment', ({ id }) => {
    if (id !== player.id) return;
    loadout.update(labelOfItem(playerState.equipment.mainHand), labelOfItem(playerState.equipment.offHand));
  });

  bus.on('target:changed', ({ entity }) => selectionRing.attach(entity));

  bus.on('ai:aggro', ({ id, targetId }) => {
    if (targetId !== player.id) return;
    bus.emit('ui:notice', { text: `${entities.get(id)?.state.name} greift an!`, tone: 'warn' });
  });

  bus.on('entity:defeated', ({ id, name, isPlayer, delay }) => {
    if (isPlayer) return; // dafür gibt es die Einblendung
    bus.emit('ui:notice', { text: `${name} besiegt (kehrt in ${delay} s zurück)`, tone: 'hint' });
  });

  bus.on('targeting:ground', (payload) => {
    if (payload.active) reticle.begin(payload);
    else reticle.end();
  });

  bus.on('autoattack:changed', ({ enabled, ability }) => {
    bus.emit('ui:notice', { text: enabled ? `Autoattack an: ${ability}` : 'Autoattack aus', tone: 'hint' });
    document.getElementById('autoattack-flag').hidden = !enabled;
  });

  bus.on('actionbar:activate', ({ bar, index }) => activateSlot(bar, index));

  // Skill aus dem Mastery-Fenster auf den ersten freien Slot legen.
  bus.on('actionbar:assignRequest', ({ abilityId }) => {
    for (let bar = 0; bar < playerState.actionBars.length; bar += 1) {
      const slots = playerState.actionBars[bar];
      if (slots.includes(abilityId)) {
        return bus.emit('ui:notice', { text: 'Liegt bereits auf der Leiste', tone: 'info' });
      }
      const index = slots.indexOf(null);
      if (index >= 0) {
        actionBars.assign(bar, index, abilityId);
        return bus.emit('ui:notice', { text: `Auf Leiste ${bar + 1}, Slot ${index + 1} gelegt`, tone: 'hint' });
      }
    }
    bus.emit('ui:notice', { text: 'Keine freien Slots', tone: 'warn' });
  });

  function activateSlot(bar, index) {
    const entry = actionBars.activate(bar, index);
    if (entry) bus.emit('actionbar:used', { bar, index, abilityId: entry.id });
  }

  // --- Takt ----------------------------------------------------------------
  bus.on('update', (dt) => {
    const direction = camera.toWorldDirection(input.getMoveIntent());

    // Der StatusEffectController ist das "gates"-Objekt: er entscheidet, ob
    // überhaupt gelaufen werden darf und wie schnell.
    movement.update(playerState, dt, player.isAlive ? direction : null, player.status);

    ai.update(dt);
    entities.update(dt);
    targeting.update();
    projectiles.update(dt);
    autoAttack.update();
    respawn.update(dt);
    saveSystem.update(dt);
  });

  bus.on('render', (dt) => {
    handleClicks();

    if (targeting.pending) {
      const ground = picker.pickGround(input.pointer, playerState.position.y);
      if (ground) {
        const point = targeting.clampToRange(ground);
        reticle.update(point, playerState.position, point.clamped);
      }
    }

    views.sync(dt);
    projectileLayer.sync(dt);
    effects.update(dt);
    selectionRing.update(dt);
    actionBarsView.update(player.cooldowns, player.skills);
    playerStatus.render(player.status.list());
    targetStatus.render(targeting.target?.status.list() ?? []);
    deathOverlay.update(dt);
    camera.update(dt, playerState.position);
    nameplates.update();
    targetFrame.updateDistance(targeting.distanceToTarget());
    view.updateSun(playerState.position);
    view.render();
    debug.update(dt);
  });

  function handleClicks() {
    for (const click of input.consumeClicks()) {
      // Rechtsklick dreht die Kamera und bricht dabei das Boden-Zielen ab.
      if (click.button === 2) {
        targeting.cancelGroundTargeting();
        continue;
      }
      if (click.button !== 0) continue;

      if (targeting.pending) {
        const ground = picker.pickGround(click, playerState.position.y);
        if (ground) targeting.confirmGroundTargeting(targeting.clampToRange(ground));
        continue;
      }

      const hitId = picker.pickEntity(click);
      if (hitId && hitId !== player.id) targeting.select(hitId);
      else targeting.clear();
    }
  }

  // --- Befehle -------------------------------------------------------------
  // Tastatur und Bildschirmknöpfe lösen dieselben Befehle aus. Es gibt keine
  // zweite Steuerungslogik, die auseinanderlaufen könnte.
  const panels = { character: characterPanel, mastery: masteryPanel, equipment };

  const commands = {
    debug: () => debug.toggle(),
    panel: (name) => panels[name]?.toggle(),
    cycleTarget: () => void targeting.cycle(),
    toggleAuto: () => autoAttack.toggle(),
    save: () => saveSystem.saveNow('manuell'),

    resetSave: async () => {
      if (!window.confirm('Speicherstand löschen und neu beginnen?')) return;
      await saveSystem.reset();
      window.location.reload();
    },
    slot: (bar, index) => activateSlot(bar, index),

    // Ausweichen läuft durch dieselbe Pipeline wie jeder Skill — der Befehl
    // fordert nur die Fähigkeit an, Ladungen prüft der Executor.
    dodge: () => bus.emit('ability:requested', {
      abilityId: 'ability.dodge', casterId: player.id, targetId: null, point: null,
    }),

    cancel: () => {
      for (const [name, panel] of Object.entries(panels)) {
        if (!panel.element.hidden) return panel.toggle();
      }
      if (!targeting.cancelGroundTargeting()) targeting.clear();
    },
  };

  bus.on('input:command', ({ name, args = [] }) => commands[name]?.(...args));
  const run = (name, ...args) => bus.emit('input:command', { name, args });

  window.addEventListener('keydown', (event) => {
    if (event.repeat) return;

    if (event.code === 'F3') return run('debug');
    if (event.code === 'KeyI') return run('panel', 'equipment');
    if (event.code === 'KeyC') return run('panel', 'character');
    if (event.code === 'KeyK') return run('panel', 'mastery');
    if (event.code === 'Tab') return run('cycleTarget');
    if (event.code === 'Escape') return run('cancel');
    if (event.code === 'Space') return run('dodge');
    if (event.code === 'KeyT') return run('toggleAuto');

    const digit = /^Digit([1-8])$/.exec(event.code);
    if (digit) return run('slot', 0, Number(digit[1]) - 1);

    const fkey = /^F([1-8])$/.exec(event.code);
    if (fkey && event.code !== 'F3') return run('slot', 1, Number(fkey[1]) - 1);
  });

  loadout.update(labelOfItem(playerState.equipment.mainHand), labelOfItem(playerState.equipment.offHand));

  // Auf dem Handy ist das Wegwischen der Anwendung der Normalfall, nicht das
  // Schließen des Tabs — deshalb beides abfangen.
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'hidden') saveSystem.saveNow('Wechsel');
  });
  window.addEventListener('pagehide', () => saveSystem.saveNow('Verlassen'));

  if (saved) {
    bus.emit('ui:notice', { text: `Spielstand geladen — Stufe ${playerState.level} (${storage.name})`, tone: 'hint' });
  }

  loop.start();

  if (CONFIG.debug.exposeGlobals) {
    window.game = {
      bus, loop, view, camera, input, player, playerState, entities, views,
      movement, targeting, actionBars, keyboard, projectiles, autoAttack, ai, respawn, progression,
      environment, assets, CONFIG,
    };
  }

  return { bus, loop };
}

function fail(message) {
  const text = document.getElementById('boot-text');
  text.classList.add('failed');
  text.textContent = message;
}

boot().then(() => {
  const screen = document.getElementById('boot');
  requestAnimationFrame(() => {
    screen.classList.add('done');
    setTimeout(() => screen.remove(), 500);
  });
}).catch((error) => {
  console.error(error);
  fail('Start fehlgeschlagen. Öffne die Konsole für Details — meistens fehlt WebGL2 oder die Seite läuft über file:// statt über einen lokalen Server.');
});
