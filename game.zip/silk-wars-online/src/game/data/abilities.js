import { Registry } from '../../core/Registry.js';

/**
 * Fähigkeiten sind Datendefinitionen mit einer Liste von KOMPONENTEN.
 *
 * Ein AbilityExecutor liest diese Liste und ruft für jeden Komponententyp
 * einen wiederverwendbaren Handler auf. Eine neue Fähigkeit ist ein neuer
 * Eintrag hier — kein neuer Code.
 *
 * Komponententypen (siehe abilities/componentHandlers.js):
 *   damage         Schaden auf das aktuelle Ziel der Komponente
 *   projectile     Geschoss, das seine eigenen onHit-Komponenten mitführt
 *   aoe            Fläche; führt verschachtelte Komponenten pro Getroffenem aus
 *   movement       Ausweichschritt / Sprung
 *   resource       Leben oder Mana verändern
 *   status_effect  Buff/Debuff (Registry und Controller kommen in Phase 6)
 *
 * "targeting" bestimmt, was die Eingabe verlangt: 'target' | 'ground' | 'self'.
 * "animation" ist ein Hinweis an die Anzeige, keine Spiellogik.
 */
export const abilities = new Registry('abilities');

abilities.registerAll({
  'ability.strike': {
    name: 'Hieb', glyph: '⚔', targeting: 'target', range: 2.8, cooldown: 1.2, mana: 0,
    animation: 'swing',
    description: 'Nahkampfschlag mit der Haupthand.',
    components: [
      { type: 'damage', school: 'physical', base: 6, coefficient: 1 },
    ],
  },

  // --- Großschwert ---------------------------------------------------------
  'ability.gs.combo': {
    name: 'Schwerer Fünfschlag', glyph: '⁙', targeting: 'target', range: 3.6, cooldown: 10, mana: 8,
    animation: 'swing', element: 'physical',
    description: 'Fünf wuchtige Schwünge, spürbar langsamer als mit dem Schwert.',
    components: [{
      type: 'repeat', times: 5, interval: 0.26,
      components: [{ type: 'damage', school: 'physical', base: 7, coefficient: 0.7 }],
    }],
  },

  'ability.gs.spin': {
    name: 'Großer Wirbel', glyph: '⊛', targeting: 'self', radius: 4.2, cooldown: 18, mana: 16,
    animation: 'swing', element: 'physical',
    description: 'Breite Drehung mit dem Zweihänder — trifft alles im Umkreis mehrfach.',
    components: [{
      type: 'repeat', times: 3, interval: 0.36,
      components: [{
        type: 'aoe', at: 'self', radius: 4.2, vfx: 'slash',
        components: [{ type: 'damage', school: 'physical', base: 9, coefficient: 0.8 }],
      }],
    }],
  },

  'ability.gs.throw': {
    name: 'Zweihänderwurf', glyph: '⟲', targeting: 'target', range: 15, cooldown: 14, mana: 12,
    animation: 'swing', element: 'physical', hideWeapon: true,
    description: 'Der Zweihänder überschlägt sich schwer durch die Luft und kehrt zurück.',
    components: [{
      type: 'projectile', speed: 18, model: 'sword', lifetime: 4, radius: 0.8, returns: true,
      onHit: [
        { type: 'damage', school: 'physical', base: 18, coefficient: 1.5 },
        { type: 'status_effect', effect: 'knockback' },
      ],
    }],
  },

  'ability.gs.berserk': {
    name: 'Berserkerschläge', glyph: '⁘', targeting: 'self', radius: 3, cooldown: 22, mana: 18,
    animation: 'swing', element: 'physical',
    description: 'Mehrere schwere Schläge auf der Stelle, jeder mit Bodenriss.',
    components: [{
      type: 'repeat', times: 4, interval: 0.45,
      components: [{
        type: 'aoe', at: 'self', radius: 3, vfx: 'slash',
        components: [
          { type: 'damage', school: 'physical', base: 13, coefficient: 1.1 },
          { type: 'status_effect', effect: 'knockdown', duration: 1, chance: 0.25 },
        ],
      }],
    }],
  },

  'ability.gs.splitter': {
    name: 'Erdspalter', glyph: '⟋', targeting: 'self', cooldown: 16, mana: 16,
    animation: 'swing', element: 'physical',
    description: 'Ein Riss läuft geradlinig nach vorne und reißt alles mit.',
    components: [{
      type: 'hazard', at: 'self', radius: 1.8, duration: 2.2, interval: 0.2, speed: 11,
      model: 'field', vfx: 'physical',
      components: [
        { type: 'damage', school: 'physical', base: 9, coefficient: 0.85 },
        { type: 'status_effect', effect: 'knockdown', duration: 1.2, chance: 0.3 },
      ],
    }],
  },

  'ability.gs.jump': {
    name: 'Wuchtsprung', glyph: '⤓', targeting: 'ground', range: 12, radius: 4, cooldown: 20, mana: 18,
    animation: 'swing', element: 'physical',
    description: 'Hoher Sprung, die Landung erschüttert den Boden im Umkreis.',
    components: [
      { type: 'movement', mode: 'leap', toward: 'point', distance: 12, duration: 0.45 },
      {
        type: 'sequence',
        steps: [{
          delay: 0.45,
          components: [{
            type: 'aoe', at: 'self', radius: 4, vfx: 'slash',
            components: [
              { type: 'damage', school: 'physical', base: 16, coefficient: 1.35 },
              { type: 'status_effect', effect: 'knockdown', duration: 1.5 },
            ],
          }],
        }],
      },
    ],
  },

  'ability.gs.rush': {
    name: 'Wuchtansturm', glyph: '⇉', targeting: 'self', cooldown: 18, mana: 16,
    animation: 'swing', element: 'physical',
    description: 'Sprint mit angelegtem Zweihänder, der Einschlag wirft alles um.',
    components: [
      { type: 'movement', mode: 'leap', toward: 'forward', distance: 10, duration: 0.5 },
      {
        type: 'hazard', at: 'self', follow: 'self', radius: 2.2, duration: 0.6, interval: 0.15,
        vfx: 'physical',
        components: [
          { type: 'damage', school: 'physical', base: 10, coefficient: 0.9 },
          { type: 'status_effect', effect: 'knockback' },
        ],
      },
    ],
  },

  // --- Dolche ---------------------------------------------------------------
  'ability.dagger.throw': {
    name: 'Dolchwurf', glyph: '⤝', targeting: 'target', range: 14, cooldown: 4, mana: 4,
    animation: 'thrust', element: 'imbue',
    description: 'Schneller Wurf — nimmt die Farbe des aktiven Banns an.',
    components: [{
      type: 'projectile', speed: 38, model: null, lifetime: 2,
      onHit: [{ type: 'damage', school: 'physical', base: 7, coefficient: 0.9 }],
    }],
  },

  'ability.dagger.rush': {
    name: 'Klingenhatz', glyph: '⇢', targeting: 'target', range: 12, cooldown: 11, mana: 10,
    animation: 'thrust', element: 'imbue',
    description: 'Dash zum Ziel; mit Bann entlädt sich am Ende das Element.',
    components: [
      { type: 'movement', mode: 'leap', toward: 'target', distance: 12, duration: 0.3 },
      {
        type: 'sequence',
        steps: [{
          delay: 0.3,
          components: [{
            type: 'aoe', at: 'self', radius: 2.6, vfx: 'imbue', elementProc: true,
            components: [{ type: 'damage', school: 'physical', base: 9, coefficient: 1 }],
          }],
        }],
      },
    ],
  },

  'ability.dagger.scream': {
    name: 'Schrei', glyph: '≻', targeting: 'self', radius: 7, cooldown: 15, mana: 14,
    animation: 'cast', element: 'imbue',
    description: 'Ein Kegel nach vorne — Frostnebel, Flammenatem oder Blitzfächer, je nach Bann.',
    components: [{
      type: 'repeat', times: 3, interval: 0.4,
      components: [{
        type: 'aoe', at: 'self', shape: 'cone', angle: 1.3, radius: 7, vfx: 'imbue', elementProc: true,
        components: [{ type: 'damage', school: 'magic', base: 6, coefficient: 0.6 }],
      }],
    }],
  },

  'ability.dagger.ring': {
    name: 'Klingenring', glyph: '◎', targeting: 'self', radius: 5, cooldown: 17, mana: 14,
    animation: 'swing', element: 'imbue',
    description: 'Dolch in den Boden — ein Ring breitet sich schnell nach außen aus.',
    components: [{
      type: 'aoe', at: 'self', radius: 5, vfx: 'imbue', elementProc: true,
      components: [
        { type: 'damage', school: 'magic', base: 11, coefficient: 1.05 },
        { type: 'status_effect', effect: 'knockback' },
      ],
    }],
  },

  'ability.dagger.updraft': {
    name: 'Aufwind', glyph: '⇡', targeting: 'self', radius: 3.4, cooldown: 14, mana: 10,
    animation: 'dash', element: 'physical', launches: true,
    description: 'Rückwärtssalto; der Wirbel darunter reißt alles zu Boden.',
    components: [
      { type: 'movement', mode: 'leap', toward: 'away', distance: 6, duration: 0.32 },
      {
        type: 'aoe', at: 'self', radius: 3.4, vfx: 'physical',
        components: [
          { type: 'damage', school: 'physical', base: 8, coefficient: 0.8 },
          { type: 'status_effect', effect: 'knockdown', duration: 1.8 },
        ],
      },
    ],
  },

  'ability.dagger.storm': {
    name: 'Dolchsturm', glyph: '✻', targeting: 'self', radius: 4.5, cooldown: 26, mana: 24,
    animation: 'swing', element: 'imbue',
    description: 'Wirbel mit beiden Klingen — die stärkste Fläche der Dolche.',
    components: [
      { type: 'status_effect', effect: 'haste', at: 'self', duration: 1.6 },
      {
        type: 'repeat', times: 5, interval: 0.22,
        components: [{
          type: 'aoe', at: 'self', radius: 4.5, vfx: 'imbue', elementProc: true,
          components: [{ type: 'damage', school: 'physical', base: 8, coefficient: 0.85 }],
        }],
      },
    ],
  },

  'ability.dagger.block': {
    name: 'Klingenkreuz', glyph: '⊓', targeting: 'self', cooldown: 15, mana: 0,
    animation: 'cast', element: 'physical',
    description: 'Beide Dolche gekreuzt: weniger Schaden, kurze Dauer.',
    components: [{ type: 'status_effect', effect: 'block', at: 'self', duration: 3 }],
  },

  // --- Stab -----------------------------------------------------------------
  'ability.staff.projectile': {
    name: 'Elementargeschoss', glyph: '✳', targeting: 'target', range: 20, cooldown: 2.5, mana: 6,
    animation: 'cast', element: 'imbue',
    description: 'Ein Geschoss in der Farbe des aktiven Banns.',
    components: [{
      type: 'projectile', speed: 26, model: null, lifetime: 3,
      onHit: [{ type: 'damage', school: 'magic', base: 8, coefficient: 1 }],
    }],
  },

  'ability.staff.meteor': {
    name: 'Meteor', glyph: '☄', targeting: 'ground', range: 18, radius: 4.5, cooldown: 22, mana: 30,
    animation: 'cast', element: 'imbue', castTime: 1.4,
    description: 'Ein Elementarkörper fällt vom Himmel — mit Flugzeit, kein Sofort-Einschlag.',
    components: [{
      type: 'falling', delay: 1.2, radius: 4.5, model: 'meteor', vfx: 'imbue',
      components: [{
        type: 'aoe', at: 'point', radius: 4.5, vfx: 'imbue', elementProc: true,
        components: [{ type: 'damage', school: 'magic', base: 30, coefficient: 2.2 }],
      }],
    }],
  },

  'ability.staff.barrage': {
    name: 'Elementarhagel', glyph: '⁂', targeting: 'ground', range: 16, radius: 6, cooldown: 20, mana: 26,
    animation: 'cast', element: 'imbue',
    description: 'Mehrere Einschläge verteilen sich über ein großes Gebiet.',
    components: [{
      type: 'repeat', times: 6, interval: 0.25,
      components: [{
        type: 'falling', delay: 0.45, radius: 2.2, model: 'shard', vfx: 'imbue',
        components: [{
          type: 'aoe', at: 'point', radius: 2.2, jitter: 4, vfx: 'imbue', elementProc: true,
          components: [{ type: 'damage', school: 'magic', base: 7, coefficient: 0.6 }],
        }],
      }],
    }],
  },

  'ability.staff.rush': {
    name: 'Elementarschritt', glyph: '⇠', targeting: 'self', cooldown: 14, mana: 14,
    animation: 'dash', element: 'imbue',
    description: 'Gleitet rückwärts und hinterlässt eine brennende, eisige oder knisternde Spur.',
    components: [
      { type: 'movement', mode: 'leap', toward: 'away', distance: 8, duration: 0.36 },
      {
        type: 'hazard', at: 'self', radius: 2, duration: 4, interval: 0.5, vfx: 'imbue',
        components: [{ type: 'damage', school: 'magic', base: 5, coefficient: 0.5 }],
      },
    ],
  },

  'ability.staff.charged': {
    name: 'Gebündelte Entladung', glyph: '◉', targeting: 'self', radius: 7, cooldown: 24, mana: 30,
    animation: 'cast', element: 'imbue', castTime: 2,
    description: 'Zwei Sekunden Aufladen, dann entlädt sich alles ringsum.',
    components: [{
      type: 'aoe', at: 'self', radius: 7, vfx: 'imbue', elementProc: true,
      components: [
        { type: 'damage', school: 'magic', base: 26, coefficient: 2 },
        { type: 'status_effect', effect: 'knockback' },
      ],
    }],
  },

  'ability.staff.field': {
    name: 'Elementarfeld', glyph: '▦', targeting: 'ground', range: 15, radius: 4, cooldown: 25, mana: 28,
    animation: 'cast', element: 'imbue',
    description: 'Ein Feld, das bestehen bleibt: Lava, Eisfläche oder knisterndes Gitter.',
    components: [{
      type: 'hazard', at: 'point', radius: 4, duration: 8, interval: 0.8, vfx: 'imbue',
      components: [
        { type: 'damage', school: 'magic', base: 6, coefficient: 0.55 },
        { type: 'status_effect', effect: 'slow', duration: 1.5, magnitude: 0.35 },
      ],
    }],
  },

  // --- Bänne und Elementbuffs ----------------------------------------------
  'ability.imbue.ice': {
    name: 'Eisbann', glyph: '❄', targeting: 'self', cooldown: 30, mana: 25,
    animation: 'cast', element: 'ice',
    description: 'Frost auf der Waffe: 30 % Verlangsamen, 5 % Einfrieren.',
    components: [{ type: 'status_effect', effect: 'imbue.ice', at: 'self', duration: 30 }],
  },

  'ability.imbue.lightning': {
    name: 'Blitzbann', glyph: '⚡', targeting: 'self', cooldown: 30, mana: 25,
    animation: 'cast', element: 'lightning',
    description: 'Funken auf der Waffe: 30 % Überschlag auf einen zweiten Gegner, 5 % Betäubung.',
    components: [{ type: 'status_effect', effect: 'imbue.lightning', at: 'self', duration: 30 }],
  },

  'ability.iceshield': {
    name: 'Eisschild', glyph: '❅', targeting: 'self', cooldown: 26, mana: 18,
    animation: 'cast', element: 'ice',
    description: 'Ein blauer Schimmer nimmt spürbar Schaden ab.',
    components: [{ type: 'status_effect', effect: 'iceshield', at: 'self', duration: 10 }],
  },

  'ability.lightningspeed': {
    name: 'Blitzgeschwindigkeit', glyph: '⏵', targeting: 'self', cooldown: 24, mana: 16,
    animation: 'cast', element: 'lightning',
    description: 'Funken an den Füßen — deutlich schneller unterwegs.',
    components: [{ type: 'status_effect', effect: 'lightningspeed', at: 'self', duration: 8 }],
  },

  'ability.firenova': {
    name: 'Flammenaura', glyph: '✷', targeting: 'self', radius: 3.2, cooldown: 22, mana: 20,
    animation: 'cast', element: 'fire',
    description: 'Flammen umgeben dich; wer zu nah kommt, wird zurückgestoßen.',
    components: [{
      type: 'hazard', at: 'self', follow: 'self', radius: 3.2, duration: 3.5, interval: 0.5, vfx: 'fire',
      components: [
        { type: 'damage', school: 'magic', base: 7, coefficient: 0.6 },
        { type: 'status_effect', effect: 'burn', duration: 3, chance: 0.5 },
        { type: 'status_effect', effect: 'knockback' },
      ],
    }],
  },

  // --- Speer ---------------------------------------------------------------
  'ability.spearthrow': {
    name: 'Speerwurf', glyph: '↗', targeting: 'target', range: 18, cooldown: 7, mana: 6,
    animation: 'thrust', element: 'physical',
    description: 'Der Speer verlässt rotierend die Hand und fliegt geradlinig.',
    components: [{
      type: 'projectile', speed: 30, model: 'spear', lifetime: 3,
      onHit: [{ type: 'damage', school: 'physical', base: 12, coefficient: 1.25 }],
    }],
  },

  'ability.spearblock': {
    name: 'Speerdeckung', glyph: '⊓', targeting: 'self', cooldown: 16, mana: 0,
    animation: 'cast', element: 'physical',
    description: 'Speer quer vor den Körper — deutlich weniger Schaden.',
    components: [{ type: 'status_effect', effect: 'block', at: 'self', duration: 4 }],
  },

  'ability.spearcombo': {
    name: 'Fünfstoß', glyph: '⁙', targeting: 'target', range: 3.8, cooldown: 8, mana: 6,
    animation: 'thrust', element: 'physical',
    description: 'Fünf schnelle Stöße und Schwünge im Wechsel.',
    components: [{
      type: 'repeat', times: 5, interval: 0.13,
      components: [{ type: 'damage', school: 'physical', base: 4, coefficient: 0.55 }],
    }],
  },

  'ability.spearspin': {
    name: 'Speerwirbel', glyph: '⊛', targeting: 'self', radius: 3.8, cooldown: 14, mana: 12,
    animation: 'swing', element: 'physical',
    description: 'Drehung mit ausgestrecktem Speer — trifft alles ringsum.',
    components: [{
      type: 'repeat', times: 3, interval: 0.3,
      components: [{
        type: 'aoe', at: 'self', radius: 3.8, vfx: 'slash',
        components: [{ type: 'damage', school: 'physical', base: 6, coefficient: 0.65 }],
      }],
    }],
  },

  'ability.spearjump': {
    name: 'Speersprung', glyph: '⤒', targeting: 'target', range: 11, cooldown: 15, mana: 12,
    animation: 'thrust', element: 'physical',
    description: 'Sprung im Bogen auf das Ziel, Speer voran — betäubt beim Aufschlag.',
    components: [
      { type: 'movement', mode: 'leap', toward: 'target', distance: 11, duration: 0.36 },
      {
        type: 'sequence',
        steps: [{
          delay: 0.36,
          components: [
            { type: 'damage', school: 'physical', base: 11, coefficient: 1.15 },
            { type: 'status_effect', effect: 'stun', duration: 2 },
          ],
        }],
      },
    ],
  },

  'ability.rush': {
    name: 'Sturmangriff', glyph: '⇉', targeting: 'self', cooldown: 16, mana: 14,
    animation: 'thrust', element: 'physical',
    description: 'Mit vorgehaltenem Speer nach vorne — Getroffene fliegen zur Seite.',
    components: [
      { type: 'movement', mode: 'leap', toward: 'forward', distance: 9, duration: 0.45 },
      {
        type: 'hazard', at: 'self', follow: 'self', radius: 1.9, duration: 0.55, interval: 0.12,
        model: 'field', vfx: 'physical',
        components: [
          { type: 'damage', school: 'physical', base: 7, coefficient: 0.8 },
          { type: 'status_effect', effect: 'knockback' },
        ],
      },
    ],
  },

  'ability.conceal': {
    name: 'Verschleiern', glyph: '☁', targeting: 'self', cooldown: 28, mana: 12,
    animation: 'cast', element: 'dark',
    description: 'Nebel umhüllt dich: Gegner übersehen dich, dein Schaden sinkt.',
    components: [{ type: 'status_effect', effect: 'conceal', at: 'self', duration: 8 }],
  },

  'ability.launch': {
    name: 'Emporschleudern', glyph: '⇧', targeting: 'target', range: 3.6, cooldown: 13, mana: 10,
    animation: 'thrust', element: 'physical', launches: true,
    description: 'Stoß von unten: das Ziel geht hoch und landet hart.',
    components: [
      { type: 'damage', school: 'physical', base: 10, coefficient: 1.05 },
      { type: 'status_effect', effect: 'knockdown', duration: 2.5 },
    ],
  },

  // --- Schild --------------------------------------------------------------
  'ability.taunt': {
    name: 'Verhöhnen', glyph: '‼', targeting: 'self', radius: 9, cooldown: 20, mana: 8,
    animation: 'swing', element: 'physical',
    description: 'Schlägt den Schild gegen die Waffe — alles in der Nähe greift dich an.',
    components: [{ type: 'taunt', radius: 9, duration: 6 }],
  },

  'ability.shieldthrow': {
    name: 'Schildwurf', glyph: '⟳', targeting: 'target', range: 15, cooldown: 10, mana: 8,
    animation: 'swing', element: 'physical', hideWeapon: false,
    description: 'Der Schild fliegt wie eine Wurfscheibe und kehrt zurück.',
    components: [{
      type: 'projectile', speed: 24, model: 'shield', lifetime: 3, returns: true,
      bounces: 1, bounceRange: 7, falloff: 0.8,
      onHit: [
        { type: 'damage', school: 'physical', base: 9, coefficient: 0.95 },
        { type: 'status_effect', effect: 'knockback' },
      ],
    }],
  },

  'ability.groundslam': {
    name: 'Bodenstoß', glyph: '⌷', targeting: 'ground', range: 10, radius: 3.5, cooldown: 24, mana: 18,
    animation: 'swing', element: 'physical',
    description: 'Rammt den Schild in den Boden und stellt eine Barriere auf.',
    components: [
      {
        type: 'aoe', at: 'point', radius: 3.5, vfx: 'physical',
        components: [{ type: 'damage', school: 'physical', base: 8, coefficient: 0.7 }],
      },
      { type: 'barrier', at: 'point', width: 7, thickness: 0.7, segments: 6, duration: 10 },
    ],
  },

  'ability.protection': {
    name: 'Schutzbund', glyph: '✧', targeting: 'target', range: 14, cooldown: 22, mana: 14,
    animation: 'cast', element: 'holy',
    description: 'Bindet dich an einen Verbündeten und nimmt ihm Schaden ab.',
    components: [
      { type: 'tether', ally: true, maxDistance: 16, duration: 12, vfx: 'holy' },
      { type: 'status_effect', effect: 'protected', at: 'target', duration: 12 },
    ],
  },

  // --- Schwert -------------------------------------------------------------
  'ability.thrust': {
    name: 'Stich', glyph: '↦', targeting: 'target', range: 3, cooldown: 3, mana: 0,
    animation: 'thrust', element: 'physical',
    description: 'Schneller Vorwärtsstoß.',
    components: [{ type: 'damage', school: 'physical', base: 9, coefficient: 1.1 }],
  },

  'ability.swordcombo': {
    name: 'Fünfschlag', glyph: '⁙', targeting: 'target', range: 3, cooldown: 8, mana: 6,
    animation: 'swing', element: 'physical',
    description: 'Fünf schnelle Schläge nacheinander.',
    components: [{
      type: 'repeat', times: 5, interval: 0.14,
      components: [{ type: 'damage', school: 'physical', base: 4, coefficient: 0.5 }],
    }],
  },

  'ability.cripple': {
    name: 'Lähmen', glyph: '↧', targeting: 'target', range: 3, cooldown: 9, mana: 6,
    animation: 'swing', element: 'physical',
    description: 'Schlag auf die Beine: das Ziel kommt kaum noch vom Fleck.',
    components: [
      { type: 'damage', school: 'physical', base: 6, coefficient: 0.7 },
      { type: 'status_effect', effect: 'slow', duration: 6, magnitude: 0.55 },
      { type: 'status_effect', effect: 'root', duration: 1 },
    ],
  },

  'ability.knockdownstrike': {
    name: 'Niederschlag', glyph: '⇩', targeting: 'target', range: 3, cooldown: 12, mana: 8,
    animation: 'swing', element: 'physical',
    description: 'Wuchtiger Schlag von oben, der das Ziel zu Boden gehen lässt.',
    components: [
      { type: 'damage', school: 'physical', base: 11, coefficient: 1.1 },
      { type: 'status_effect', effect: 'knockdown', duration: 2.2 },
    ],
  },

  'ability.airblade': {
    name: 'Luftklingen', glyph: '≋', targeting: 'target', range: 14, cooldown: 11, mana: 14,
    animation: 'swing', element: 'physical',
    description: 'Vier sichelförmige Klingen fliegen nacheinander zum Ziel.',
    components: [{
      type: 'sequence',
      steps: [0, 0.12, 0.12, 0.12].map((delay) => ({
        delay,
        components: [{
          type: 'projectile', speed: 26, model: 'blade', lifetime: 2,
          onHit: [{ type: 'damage', school: 'physical', base: 5, coefficient: 0.6 }],
        }],
      })),
    }],
  },

  'ability.finishingstab': {
    name: 'Todesstoß', glyph: '✖', targeting: 'target', range: 2.8, cooldown: 14, mana: 10,
    animation: 'thrust', element: 'physical',
    requires: { targetStatus: 'knockdown', label: 'niedergeschlagene Ziele' },
    description: 'Nur gegen liegende Gegner: drei schnelle, tiefe Stiche.',
    components: [{
      type: 'repeat', times: 3, interval: 0.16,
      components: [{ type: 'damage', school: 'physical', base: 14, coefficient: 1.3, critBonus: 0.2 }],
    }],
  },

  'ability.swordblock': {
    name: 'Deckung', glyph: '⊓', targeting: 'self', cooldown: 16, mana: 0,
    animation: 'cast', element: 'physical',
    description: 'Klinge vor den Körper: deutlich weniger Schaden, dafür langsam.',
    components: [{ type: 'status_effect', effect: 'block', at: 'self', duration: 4 }],
  },

  'ability.swordjump': {
    name: 'Klingensprung', glyph: '⤒', targeting: 'target', range: 10, cooldown: 13, mana: 12,
    animation: 'swing', element: 'physical',
    description: 'Sprung zum Ziel, der Schlag kommt bei der Landung.',
    components: [
      { type: 'movement', mode: 'leap', toward: 'target', distance: 10, duration: 0.34 },
      {
        type: 'sequence',
        steps: [{
          delay: 0.34,
          components: [{
            type: 'aoe', at: 'self', radius: 3, vfx: 'slash',
            components: [
              { type: 'damage', school: 'physical', base: 12, coefficient: 1.2 },
              { type: 'status_effect', effect: 'knockback' },
            ],
          }],
        }],
      },
    ],
  },

  'ability.swordthrow': {
    name: 'Klingenwurf', glyph: '⟲', targeting: 'target', range: 16, cooldown: 12, mana: 10,
    animation: 'swing', element: 'physical', hideWeapon: true,
    description: 'Das Schwert fliegt rotierend zum Ziel und kehrt zurück.',
    components: [{
      type: 'projectile', speed: 22, model: 'sword', lifetime: 3, returns: true,
      onHit: [{ type: 'damage', school: 'physical', base: 13, coefficient: 1.35 }],
    }],
  },

  'ability.swordspin': {
    name: 'Klingenwirbel', glyph: '⊛', targeting: 'self', radius: 3.4, cooldown: 20, mana: 18,
    animation: 'swing', element: 'physical',
    description: 'Drehung um die eigene Achse — unverwundbar, während es läuft.',
    components: [
      { type: 'status_effect', effect: 'invulnerable', at: 'self', duration: 1.1 },
      {
        type: 'repeat', times: 4, interval: 0.28,
        components: [{
          type: 'aoe', at: 'self', radius: 3.4, vfx: 'slash',
          components: [{ type: 'damage', school: 'physical', base: 6, coefficient: 0.6 }],
        }],
      },
    ],
  },

  'ability.swordpull': {
    name: 'Klingenzug', glyph: '⇤', targeting: 'ground', range: 14, radius: 3, cooldown: 18, mana: 16,
    animation: 'swing', element: 'physical', hideWeapon: true,
    description: 'Das Schwert fährt in den Boden und reißt alles in der Nähe zu dir.',
    components: [{
      type: 'projectile', speed: 24, model: 'sword', lifetime: 4,
      onHit: [{
        type: 'aoe', at: 'point', radius: 3, vfx: 'physical',
        components: [
          { type: 'damage', school: 'physical', base: 7, coefficient: 0.7 },
          { type: 'movement', at: 'target', mode: 'pull', toward: 'caster', duration: 0.35 },
        ],
      }],
    }],
  },

  // --- Bogen ---------------------------------------------------------------
  'ability.chargedshot': {
    name: 'Geladener Schuss', glyph: '➸', targeting: 'target', range: 24, cooldown: 6, mana: 8,
    animation: 'shoot', element: 'physical', castTime: 1,
    description: 'Aufgeladener Pfeil: mehr Schaden und deutlich höhere Kritchance.',
    components: [{
      type: 'projectile', speed: 46, model: 'arrow', lifetime: 3,
      onHit: [{ type: 'damage', school: 'physical', base: 12, coefficient: 1.6, critBonus: 0.25 }],
    }],
  },

  'ability.goldenshot': {
    name: 'Goldener Schuss', glyph: '✸', targeting: 'target', range: 28, cooldown: 18, mana: 20,
    animation: 'shoot', element: 'holy', castTime: 2,
    description: 'Lange Ladezeit, sehr hoher Schaden.',
    components: [{
      type: 'projectile', speed: 52, model: 'arrow.golden', lifetime: 3,
      onHit: [{ type: 'damage', school: 'physical', base: 30, coefficient: 2.6, critBonus: 0.15 }],
    }],
  },

  'ability.fanshot': {
    name: 'Fächerschuss', glyph: '⋔', targeting: 'target', range: 18, cooldown: 9, mana: 12,
    animation: 'shoot', element: 'physical',
    description: 'Fünf Pfeile im Fächer — trifft alles, was im Weg steht.',
    components: [{
      type: 'projectile', count: 5, spread: 0.17, speed: 34, model: 'arrow', lifetime: 1.4,
      onHit: [{ type: 'damage', school: 'physical', base: 5, coefficient: 0.75 }],
    }],
  },

  'ability.bounceshot': {
    name: 'Sprungschuss', glyph: '⤳', targeting: 'target', range: 20, cooldown: 10, mana: 14,
    animation: 'shoot', element: 'physical',
    description: 'Ein Pfeil, der von Gegner zu Gegner weiterspringt.',
    components: [{
      type: 'projectile', speed: 30, model: 'arrow', lifetime: 3,
      bounces: 2, bounceRange: 9, falloff: 0.8,
      onHit: [{ type: 'damage', school: 'physical', base: 8, coefficient: 1.05 }],
    }],
  },

  'ability.knockbackshot': {
    name: 'Wuchtschuss', glyph: '➾', targeting: 'target', range: 18, cooldown: 8, mana: 10,
    animation: 'shoot', element: 'physical',
    description: 'Schwerer Pfeil, der zurückstößt und das Ziel verwundbar macht.',
    components: [{
      type: 'projectile', speed: 26, model: 'arrow.heavy', lifetime: 3, radius: 0.7,
      onHit: [
        { type: 'damage', school: 'physical', base: 9, coefficient: 1.1 },
        { type: 'status_effect', effect: 'knockback' },
        { type: 'status_effect', effect: 'vulnerable', duration: 6 },
      ],
    }],
  },

  'ability.explosionshot': {
    name: 'Sprengpfeil', glyph: '✺', targeting: 'ground', range: 18, radius: 4, cooldown: 12, mana: 18,
    animation: 'shoot', element: 'fire',
    description: 'Pfeil auf einen Bodenpunkt, der dort explodiert.',
    components: [{
      type: 'projectile', speed: 26, model: 'arrow', lifetime: 4,
      onHit: [{
        type: 'aoe', at: 'point', radius: 4, vfx: 'fire',
        components: [
          { type: 'damage', school: 'physical', base: 12, coefficient: 1.25 },
          { type: 'status_effect', effect: 'burn', duration: 4, chance: 0.6 },
        ],
      }],
    }],
  },

  'ability.nailshot': {
    name: 'Nagelschuss', glyph: '⚿', targeting: 'ground', range: 16, radius: 3, cooldown: 16, mana: 14,
    animation: 'shoot', element: 'physical',
    description: 'Nagelt alles im Zielbereich für einige Sekunden am Boden fest.',
    components: [{
      type: 'projectile', speed: 30, model: 'arrow.heavy', lifetime: 4,
      onHit: [
        {
          type: 'aoe', at: 'point', radius: 3, vfx: 'physical',
          components: [{ type: 'damage', school: 'physical', base: 6, coefficient: 0.6 }],
        },
        {
          type: 'hazard', at: 'point', radius: 3, duration: 4, interval: 0.5, model: 'nails', vfx: 'physical',
          components: [{ type: 'status_effect', effect: 'root', duration: 0.8 }],
        },
      ],
    }],
  },

  'ability.arrowtornado': {
    name: 'Pfeilwirbel', glyph: '🌀', targeting: 'self', radius: 2.6, cooldown: 20, mana: 24,
    animation: 'shoot', element: 'physical',
    description: 'Ein Wirbel aus Pfeilen zieht vor dir her und trifft wiederholt.',
    components: [{
      type: 'hazard', at: 'self', radius: 2.6, duration: 4, interval: 0.4,
      speed: 6, model: 'tornado', vfx: 'physical',
      components: [{ type: 'damage', school: 'physical', base: 5, coefficient: 0.45 }],
    }],
  },

  'ability.chainshot': {
    name: 'Fesselkette', glyph: '⛓', targeting: 'target', range: 18, cooldown: 18, mana: 16,
    animation: 'shoot', element: 'physical',
    description: 'Bindet ein Ziel an eine Kette — weiter als acht Meter kommt es nicht.',
    components: [{
      type: 'projectile', speed: 32, model: 'arrow', lifetime: 3,
      onHit: [
        { type: 'damage', school: 'physical', base: 6, coefficient: 0.8 },
        { type: 'tether', maxDistance: 8, duration: 8 },
      ],
    }],
  },

  'ability.arrowjump': {
    name: 'Sprungschuss rückwärts', glyph: '⤺', targeting: 'target', range: 16, cooldown: 10, mana: 10,
    animation: 'shoot', element: 'physical',
    description: 'Satz nach hinten, aus der Luft ein Schuss auf das Ziel.',
    components: [
      { type: 'movement', mode: 'leap', toward: 'away', distance: 7, duration: 0.3 },
      {
        type: 'sequence',
        steps: [{
          delay: 0.12,
          components: [{
            type: 'projectile', speed: 36, model: 'arrow', lifetime: 3,
            onHit: [{ type: 'damage', school: 'physical', base: 7, coefficient: 1 }],
          }],
        }],
      },
    ],
  },

  'ability.bowstrike': {
    name: 'Bogenschlag', glyph: '⌒', targeting: 'target', range: 2.6, cooldown: 4, mana: 0,
    animation: 'swing', element: 'physical',
    description: 'Notwehr aus nächster Nähe — ein Schlag mit dem Bogen selbst.',
    components: [
      { type: 'damage', school: 'physical', base: 7, coefficient: 0.8 },
      { type: 'status_effect', effect: 'knockback' },
    ],
  },

  'ability.shot': {
    name: 'Schuss', glyph: '➹', targeting: 'target', range: 20, cooldown: 1, mana: 4,
    animation: 'shoot',
    description: 'Gezielter Pfeil auf ein Ziel.',
    components: [
      {
        type: 'projectile', speed: 34, model: 'arrow', lifetime: 3,
        onHit: [{ type: 'damage', school: 'physical', base: 4, coefficient: 1.15 }],
      },
    ],
  },

  'ability.firestorm': {
    name: 'Feuersturm', glyph: '✹', targeting: 'ground', range: 14, radius: 3.6, cooldown: 8, mana: 22,
    animation: 'cast',
    element: 'fire',
    description: 'Flächenschaden auf einem markierten Bodenpunkt.',
    components: [
      {
        type: 'aoe', at: 'point', radius: 3.6, vfx: 'fire',
        components: [
          { type: 'damage', school: 'magic', base: 14, coefficient: 1.4 },
          { type: 'status_effect', effect: 'burn', duration: 5 },
        ],
      },
    ],
  },

  'ability.frostnova': {
    name: 'Frostnova', glyph: '❄', targeting: 'self', radius: 5, cooldown: 12, mana: 18,
    animation: 'cast',
    element: 'ice',
    description: 'Eisstoß rund um dich, verlangsamt Getroffene.',
    components: [
      {
        type: 'aoe', at: 'self', radius: 5, vfx: 'frost',
        components: [
          { type: 'damage', school: 'magic', base: 8, coefficient: 0.7 },
          { type: 'status_effect', effect: 'slow', duration: 4, magnitude: 0.4 },
        ],
      },
    ],
  },

  'ability.thunderclap': {
    name: 'Donnerschlag', glyph: '✷', targeting: 'self', radius: 6, cooldown: 18, mana: 16,
    animation: 'swing',
    description: 'Stößt alles im Umkreis zurück und betäubt es kurz.',
    components: [
      {
        type: 'aoe', at: 'self', radius: 6, vfx: 'slash',
        components: [
          { type: 'damage', school: 'physical', base: 10, coefficient: 0.8 },
          { type: 'status_effect', effect: 'knockback' },
          { type: 'status_effect', effect: 'stun', duration: 1.6 },
        ],
      },
    ],
  },

  'ability.heal': {
    name: 'Heilstrom', glyph: '✚', targeting: 'self', cooldown: 10, mana: 20,
    animation: 'cast',
    element: 'holy',
    description: 'Stellt sofort Leben wieder her.',
    components: [
      { type: 'resource', resource: 'health', at: 'self', base: 18, coefficient: 0.9 },
    ],
  },

  'ability.warcry': {
    name: 'Kampfschrei', glyph: '⚑', targeting: 'self', radius: 8, cooldown: 25, mana: 10,
    animation: 'cast',
    description: 'Stärkt dich kurzzeitig.',
    components: [
      { type: 'status_effect', effect: 'haste', at: 'self', duration: 8, magnitude: 0.25 },
    ],
  },

  'ability.imbue.fire': {
    name: 'Feuerbann', glyph: '☄', targeting: 'self', cooldown: 30, mana: 25,
    animation: 'cast',
    element: 'fire',
    description: 'Verzaubert die Waffe zeitweise mit Feuerschaden.',
    components: [
      { type: 'status_effect', effect: 'imbue.fire', at: 'self', duration: 30 },
    ],
  },

  'ability.chainlightning': {
    name: 'Kettenblitz', glyph: '⚡', targeting: 'target', range: 16, cooldown: 9, mana: 20,
    animation: 'cast',
    element: 'lightning',
    description: 'Blitz, der auf bis zu drei weitere Gegner überspringt.',
    components: [
      {
        type: 'chain', jumps: 3, range: 7, falloff: 0.75,
        components: [{ type: 'damage', school: 'magic', base: 9, coefficient: 1 }],
      },
    ],
  },

  'ability.curse': {
    name: 'Fluch', glyph: '☾', targeting: 'target', range: 14, cooldown: 14, mana: 14,
    animation: 'cast',
    element: 'dark',
    description: 'Macht ein Ziel verwundbar und schwächt seine Angriffe.',
    components: [
      { type: 'status_effect', effect: 'vulnerable', duration: 10 },
      { type: 'status_effect', effect: 'weaken', duration: 10 },
    ],
  },

  // --- Skills der bislang leeren Masteries --------------------------------
  'ability.shadowstep': {
    name: 'Schattenschritt', glyph: '↯', targeting: 'target', range: 9, cooldown: 12, mana: 8,
    animation: 'thrust',
    description: 'Setzt zum Ziel über und trifft es aus der Bewegung.',
    components: [
      { type: 'movement', mode: 'leap', toward: 'target', distance: 9, duration: 0.32 },
      { type: 'damage', school: 'physical', base: 8, coefficient: 1.15 },
      { type: 'status_effect', effect: 'bleed', duration: 6 },
    ],
  },

  'ability.impale': {
    name: 'Aufspießen', glyph: '➶', targeting: 'target', range: 4, cooldown: 7, mana: 6,
    animation: 'thrust',
    description: 'Tiefer Stoß, der eine blutende Wunde hinterlässt.',
    components: [
      { type: 'damage', school: 'physical', base: 12, coefficient: 1.3 },
      { type: 'status_effect', effect: 'bleed', duration: 8, stacks: 2 },
    ],
  },

  'ability.bulwark': {
    name: 'Schildwall', glyph: '🛡', targeting: 'self', cooldown: 25, mana: 10,
    animation: 'cast',
    description: 'Nimmt deutlich weniger Schaden, dafür langsamer.',
    components: [
      { type: 'status_effect', effect: 'bulwark', at: 'self', duration: 8 },
    ],
  },

  'ability.arcanepulse': {
    name: 'Arkanstoß', glyph: '◎', targeting: 'self', radius: 6, cooldown: 16, mana: 22,
    animation: 'cast',
    element: 'arcane',
    description: 'Druckwelle rundum, die Zauberer kurz verstummen lässt.',
    components: [
      {
        type: 'aoe', at: 'self', radius: 6, vfx: 'lightning',
        components: [
          { type: 'damage', school: 'magic', base: 11, coefficient: 1.1 },
          { type: 'status_effect', effect: 'silence', duration: 3 },
        ],
      },
    ],
  },

  'ability.dodge': {
    name: 'Ausweichen', glyph: '»', targeting: 'self', cooldown: 0, charges: 2, chargeTime: 7, mana: 0,
    basic: true,
    animation: 'dash', global: false,
    description: 'Kurzer Ausweichschritt mit kurzer Unverwundbarkeit. Zwei Ladungen.',
    components: [
      { type: 'movement', mode: 'dash', distance: 5.2, duration: 0.28 },
      { type: 'status_effect', effect: 'invulnerable', at: 'self', duration: 0.4 },
    ],
  },

  // --- Autoattacks pro Waffentyp ------------------------------------------
  'attack.unarmed': {
    name: 'Faustschlag', glyph: '✊', targeting: 'target', range: 2.2, cooldown: 1.1, mana: 0,
    animation: 'swing', hidden: true,
    components: [{ type: 'damage', school: 'physical', base: 2, coefficient: 0.5 }],
  },
  'attack.sword': {
    name: 'Schwerthieb', glyph: '⚔', targeting: 'target', range: 2.8, cooldown: 1.1, mana: 0,
    animation: 'swing', hidden: true,
    components: [{ type: 'damage', school: 'physical', base: 4, coefficient: 0.85 }],
  },
  'attack.dagger': {
    name: 'Dolchstich', glyph: '🗡', targeting: 'target', range: 2.2, cooldown: 0.65, mana: 0,
    animation: 'thrust', hidden: true,
    components: [{ type: 'damage', school: 'physical', base: 2, coefficient: 0.55 }],
  },
  'attack.greatsword': {
    name: 'Weiter Schwung', glyph: '⚔', targeting: 'target', range: 3.4, cooldown: 1.9, mana: 0,
    animation: 'swing', hidden: true,
    components: [
      {
        type: 'aoe', at: 'target', radius: 2.2, vfx: 'slash',
        components: [{ type: 'damage', school: 'physical', base: 7, coefficient: 1.15 }],
      },
    ],
  },
  'attack.spear': {
    name: 'Stoß', glyph: '➶', targeting: 'target', range: 3.8, cooldown: 1.3, mana: 0,
    animation: 'thrust', hidden: true,
    components: [{ type: 'damage', school: 'physical', base: 5, coefficient: 0.95 }],
  },
  'attack.bow': {
    name: 'Pfeilschuss', glyph: '➹', targeting: 'target', range: 22, cooldown: 1.25, mana: 0,
    animation: 'shoot', hidden: true,
    components: [{
      type: 'projectile', speed: 34, model: 'arrow', lifetime: 3,
      onHit: [{ type: 'damage', school: 'physical', base: 3, coefficient: 0.9 }],
    }],
  },
  'attack.bite': {
    name: 'Biss', glyph: '𝕎', targeting: 'target', range: 2.4, cooldown: 1.7, mana: 0,
    animation: 'swing', hidden: true,
    components: [
      { type: 'damage', school: 'physical', base: 3, coefficient: 0.5 },
      { type: 'status_effect', effect: 'bleed', duration: 5, chance: 0.3 },
    ],
  },
  // --- Fähigkeiten der Monster --------------------------------------------
  'attack.pounce': {
    name: 'Satz', glyph: '↯', targeting: 'target', range: 10, cooldown: 9, mana: 0,
    animation: 'swing', hidden: true,
    components: [
      { type: 'movement', mode: 'leap', toward: 'target', distance: 10, duration: 0.38 },
      { type: 'damage', school: 'physical', base: 5, coefficient: 0.7 },
      { type: 'status_effect', effect: 'bleed', duration: 5, chance: 0.5 },
    ],
  },

  'attack.shieldbash': {
    name: 'Schildstoß', glyph: '🛡', targeting: 'target', range: 3, cooldown: 11, mana: 0,
    animation: 'thrust', hidden: true,
    components: [
      { type: 'damage', school: 'physical', base: 6, coefficient: 0.6 },
      { type: 'status_effect', effect: 'stun', duration: 1.3 },
      { type: 'status_effect', effect: 'knockback' },
    ],
  },

  'attack.frostbolt': {
    name: 'Frostpfeil', glyph: '❄', targeting: 'target', range: 16, cooldown: 6, mana: 8,
    animation: 'cast', hidden: true,
    components: [{
      type: 'projectile', speed: 20, model: 'bolt', lifetime: 4,
      onHit: [
        { type: 'damage', school: 'magic', base: 6, coefficient: 0.9 },
        { type: 'status_effect', effect: 'slow', duration: 4, magnitude: 0.35 },
      ],
    }],
  },

  'attack.crippleshot': {
    name: 'Fesselschuss', glyph: '⛓', targeting: 'target', range: 20, cooldown: 13, mana: 0,
    animation: 'shoot', hidden: true,
    components: [{
      type: 'projectile', speed: 30, model: 'arrow', lifetime: 3,
      onHit: [
        { type: 'damage', school: 'physical', base: 4, coefficient: 0.8 },
        { type: 'status_effect', effect: 'root', duration: 2.5 },
      ],
    }],
  },

  'attack.slam': {
    name: 'Pranke', glyph: '✷', targeting: 'target', range: 4, cooldown: 10, mana: 0,
    animation: 'swing', hidden: true,
    components: [{
      type: 'aoe', at: 'self', radius: 5, vfx: 'slash',
      components: [
        { type: 'damage', school: 'physical', base: 10, coefficient: 0.85 },
        { type: 'status_effect', effect: 'knockback' },
        { type: 'status_effect', effect: 'knockdown', duration: 1.2, chance: 0.5 },
      ],
    }],
  },

  'attack.maul': {
    name: 'Prankenhieb', glyph: '𝕎', targeting: 'target', range: 3.2, cooldown: 2.1, mana: 0,
    animation: 'swing', hidden: true,
    components: [{ type: 'damage', school: 'physical', base: 6, coefficient: 0.75 }],
  },

  'attack.staff': {
    name: 'Magiegeschoss', glyph: '✳', targeting: 'target', range: 18, cooldown: 1.4, mana: 2,
    animation: 'cast', hidden: true,
    components: [{
      type: 'projectile', speed: 22, model: 'bolt', lifetime: 4,
      onHit: [{ type: 'damage', school: 'magic', base: 4, coefficient: 0.95 }],
    }],
  },
});

/** Standardbelegung, bis Drag & Drop dazukommt. */
export const DEFAULT_ACTION_BARS = [
  ['ability.strike', 'ability.shot', 'ability.firestorm', 'ability.frostnova', 'ability.heal', 'ability.thunderclap', null, 'ability.dodge'],
  ['ability.warcry', 'ability.imbue.fire', 'ability.chainlightning', 'ability.curse', null, null, null, null],
];

/**
 * Nukes: sechs Bauformen pro Element.
 *
 * Die Form bestimmt Verhalten und Optik (Geschoss, geladene Lanze, Nova um
 * den Wirker, stehendes Feld, Kettenblitz, Einschlag aus dem Himmel), das
 * Element die Farbe und den Zusatzeffekt. So unterscheiden sich die sechs
 * deutlich voneinander — und nicht nur im Namen.
 */
const NUKE_ELEMENTS = {
  fire: {
    proc: { effect: 'burn', duration: 4, chance: 0.5 },
    names: ['Feuerpfeil', 'Flammenlanze', 'Feuernova', 'Flammensturm', 'Funkensprung', 'Meteorschlag'],
  },
  ice: {
    proc: { effect: 'slow', duration: 3, magnitude: 0.4, chance: 0.6 },
    names: ['Eissplitter', 'Frostlanze', 'Eisnova', 'Frostfeld', 'Eiskette', 'Gletschersturz'],
  },
  lightning: {
    proc: { effect: 'static', duration: 4, chance: 0.45 },
    names: ['Blitzschlag', 'Donnerlanze', 'Entladung', 'Sturmfeld', 'Funkenkette', 'Himmelszorn'],
  },
};

const NUKE_SHAPES = [
  {
    key: 'bolt', glyph: '•', requires: 1,
    build: (element, proc) => ({
      targeting: 'target', range: 20, cooldown: 3, mana: 8, animation: 'cast',
      description: 'Schnelles Einzelziel-Geschoss.',
      components: [{
        type: 'projectile', speed: 30, lifetime: 3,
        onHit: [{ type: 'damage', school: 'magic', base: 10, coefficient: 1.1 }, { type: 'status_effect', ...proc }],
      }],
    }),
  },
  {
    key: 'lance', glyph: '↑', requires: 3,
    build: (element, proc) => ({
      targeting: 'target', range: 24, cooldown: 11, mana: 22, animation: 'cast', castTime: 1.3,
      description: 'Aufgeladene Lanze mit hohem Einzelschaden.',
      components: [{
        type: 'projectile', speed: 42, lifetime: 3, radius: 0.8,
        onHit: [{ type: 'damage', school: 'magic', base: 26, coefficient: 2, critBonus: 0.1 }, { type: 'status_effect', ...proc }],
      }],
    }),
  },
  {
    key: 'nova', glyph: '◎', requires: 4,
    build: () => ({
      targeting: 'self', radius: 6, cooldown: 15, mana: 20, animation: 'cast',
      description: 'Entladung rund um dich.',
      components: [{
        type: 'aoe', at: 'self', radius: 6, elementProc: true,
        components: [{ type: 'damage', school: 'magic', base: 16, coefficient: 1.3 }],
      }],
    }),
  },
  {
    key: 'storm', glyph: '▦', requires: 6,
    build: () => ({
      targeting: 'ground', range: 16, radius: 4.5, cooldown: 21, mana: 26, animation: 'cast',
      description: 'Ein Feld, das einige Sekunden stehen bleibt.',
      components: [{
        type: 'hazard', at: 'point', radius: 4.5, duration: 5, interval: 0.7,
        components: [{ type: 'damage', school: 'magic', base: 7, coefficient: 0.6 }],
      }],
    }),
  },
  {
    key: 'arc', glyph: '⤳', requires: 7,
    build: (element, proc) => ({
      targeting: 'target', range: 18, cooldown: 13, mana: 20, animation: 'cast',
      description: 'Springt von Gegner zu Gegner weiter.',
      components: [{
        type: 'projectile', speed: 28, lifetime: 3, bounces: 3, bounceRange: 8, falloff: 0.8,
        onHit: [{ type: 'damage', school: 'magic', base: 12, coefficient: 1.15 }, { type: 'status_effect', ...proc }],
      }],
    }),
  },
  {
    key: 'cataclysm', glyph: '☄', requires: 10,
    build: () => ({
      targeting: 'ground', range: 20, radius: 6, cooldown: 32, mana: 42, animation: 'cast', castTime: 1.8,
      description: 'Der schwerste Schlag der Schule — mit Ansage und Flugzeit.',
      components: [{
        type: 'falling', delay: 1.2, radius: 6, model: 'meteor',
        components: [{
          type: 'aoe', at: 'point', radius: 6, elementProc: true,
          components: [
            { type: 'damage', school: 'magic', base: 40, coefficient: 3 },
            { type: 'status_effect', effect: 'knockdown', duration: 1.5 },
          ],
        }],
      }],
    }),
  },
];

export const NUKES = {};

for (const [element, flavour] of Object.entries(NUKE_ELEMENTS)) {
  NUKES[element] = [];

  NUKE_SHAPES.forEach((shape, index) => {
    const id = `ability.${element}.${shape.key}`;
    const definition = shape.build(element, flavour.proc);

    abilities.register(id, {
      ...definition,
      name: flavour.names[index],
      glyph: shape.glyph,
      element,
    });
    NUKES[element].push({ ability: id, requires: shape.requires });
  });
}
