import { Registry } from '../../core/Registry.js';

/**
 * Masteries und Synergien als Daten.
 *
 * Kein linearer Skilltree: das Mastery-Level schaltet Fähigkeiten frei,
 * Skillpunkte ranken sie hoch. Beides zahlt aus EINEM gemeinsamen Punkte-Pool
 * — der Spieler entscheidet zwischen "breit" (viele Masteries) und "tief"
 * (hohe Ränge).
 *
 * Felder:
 *   skills   [{ ability, requires }] — ab welchem Mastery-Level verfügbar
 *   bonuses  [{ stat, perLevel }]    — passiver Zugewinn pro Mastery-Level
 */
export const masteries = new Registry('masteries');

masteries.registerAll({
  // --- Waffen -------------------------------------------------------------
  'mastery.sword': {
    name: 'Schwert', category: 'weapon', glyph: '⚔', maxLevel: 20,
    skills: [{ ability: 'ability.strike', requires: 1 }],
    bonuses: [{ stat: 'physicalPower', perLevel: 1.1 }],
  },
  'mastery.greatsword': {
    name: 'Großschwert', category: 'weapon', glyph: '🗡', maxLevel: 20,
    skills: [{ ability: 'ability.thunderclap', requires: 2 }],
    bonuses: [{ stat: 'physicalPower', perLevel: 1.4 }, { stat: 'armor', perLevel: 0.4 }],
  },
  'mastery.bow': {
    name: 'Bogen', category: 'weapon', glyph: '➹', maxLevel: 20,
    skills: [{ ability: 'ability.shot', requires: 1 }],
    bonuses: [{ stat: 'critChance', perLevel: 0.004 }, { stat: 'physicalPower', perLevel: 0.9 }],
  },
  'mastery.dagger': {
    name: 'Dolche', category: 'weapon', glyph: '†', maxLevel: 20,
    skills: [{ ability: 'ability.shadowstep', requires: 1 }],
    bonuses: [{ stat: 'critChance', perLevel: 0.006 }, { stat: 'critDamage', perLevel: 0.02 }],
  },
  'mastery.spear': {
    name: 'Speer', category: 'weapon', glyph: '➶', maxLevel: 20,
    skills: [{ ability: 'ability.impale', requires: 1 }],
    bonuses: [{ stat: 'physicalPower', perLevel: 1.2 }],
  },
  'mastery.shield': {
    name: 'Schild', category: 'weapon', glyph: '🛡', maxLevel: 20,
    skills: [{ ability: 'ability.bulwark', requires: 1 }],
    bonuses: [{ stat: 'armor', perLevel: 1.6 }, { stat: 'maxHealth', perLevel: 4 }],
  },
  'mastery.staff': {
    name: 'Stab', category: 'weapon', glyph: '⚕', maxLevel: 20,
    skills: [{ ability: 'ability.arcanepulse', requires: 2 }],
    bonuses: [{ stat: 'magicPower', perLevel: 1.1 }, { stat: 'maxMana', perLevel: 3 }],
  },

  // --- Magie ---------------------------------------------------------------
  'mastery.fire': {
    name: 'Feuer', category: 'magic', glyph: '✹', maxLevel: 20,
    skills: [
      { ability: 'ability.firestorm', requires: 1 },
      { ability: 'ability.imbue.fire', requires: 3 },
    ],
    bonuses: [{ stat: 'magicPower', perLevel: 1.3 }],
  },
  'mastery.ice': {
    name: 'Eis', category: 'magic', glyph: '❄', maxLevel: 20,
    skills: [{ ability: 'ability.frostnova', requires: 1 }],
    bonuses: [{ stat: 'magicPower', perLevel: 1.1 }, { stat: 'magicResist', perLevel: 0.5 }],
  },
  'mastery.lightning': {
    name: 'Elektro', category: 'magic', glyph: '⚡', maxLevel: 20,
    skills: [{ ability: 'ability.chainlightning', requires: 1 }],
    bonuses: [{ stat: 'magicPower', perLevel: 1.2 }, { stat: 'critChance', perLevel: 0.003 }],
  },
  'mastery.dark': {
    name: 'Dunkle Magie', category: 'magic', glyph: '☾', maxLevel: 20,
    skills: [{ ability: 'ability.curse', requires: 1 }],
    bonuses: [{ stat: 'magicPower', perLevel: 1 }],
  },
  'mastery.holy': {
    name: 'Heilige Magie', category: 'magic', glyph: '✚', maxLevel: 20,
    skills: [
      { ability: 'ability.heal', requires: 1 },
      { ability: 'ability.warcry', requires: 2 },
    ],
    bonuses: [{ stat: 'healthRegen', perLevel: 0.08 }, { stat: 'magicPower', perLevel: 0.9 }],
  },
});

/**
 * Synergien zwischen zwei Masteries geben echte, spielbare Boni.
 * "effects" wird generisch ausgewertet — kein Sonderfall im Code:
 *   { type: 'stat',    stat, add }        -> fließt in die abgeleiteten Werte
 *   { type: 'ability', ability, damage }  -> Schadensbonus für eine Fähigkeit
 */
export const synergies = new Registry('synergies');

synergies.registerAll({
  'synergy.stormarcher': {
    name: 'Sturmschütze', requires: { 'mastery.bow': 5, 'mastery.lightning': 5 },
    description: 'Bogen und Elektro: mehr Kritchance, stärkerer Schuss.',
    effects: [
      { type: 'stat', stat: 'critChance', add: 0.05 },
      { type: 'ability', ability: 'ability.shot', damage: 0.15 },
    ],
  },
  'synergy.emberblade': {
    name: 'Glutklinge', requires: { 'mastery.sword': 5, 'mastery.fire': 5 },
    description: 'Schwert und Feuer: der Waffenbann brennt heißer.',
    effects: [
      { type: 'stat', stat: 'physicalPower', add: 6 },
      { type: 'ability', ability: 'ability.imbue.fire', damage: 0.2 },
    ],
  },
  'synergy.ironwall': {
    name: 'Eisenwall', requires: { 'mastery.shield': 5, 'mastery.greatsword': 5 },
    description: 'Schild und Großschwert: härtere Deckung, wuchtigerer Donnerschlag.',
    effects: [
      { type: 'stat', stat: 'armor', add: 10 },
      { type: 'ability', ability: 'ability.thunderclap', damage: 0.2 },
    ],
  },
  'synergy.nightblade': {
    name: 'Nachtklinge', requires: { 'mastery.dagger': 5, 'mastery.dark': 5 },
    description: 'Dolche und Dunkle Magie: tödlichere Kritische, stärkerer Schattenschritt.',
    effects: [
      { type: 'stat', stat: 'critDamage', add: 0.25 },
      { type: 'ability', ability: 'ability.shadowstep', damage: 0.2 },
    ],
  },
  'synergy.hoarfrost': {
    name: 'Rauhreif', requires: { 'mastery.ice': 5, 'mastery.dark': 5 },
    description: 'Eis und Dunkle Magie: härtere Frostnova, mehr Magieschaden.',
    effects: [
      { type: 'stat', stat: 'magicPower', add: 8 },
      { type: 'ability', ability: 'ability.frostnova', damage: 0.2 },
    ],
  },
});

/** Umkehr-Index Fähigkeit -> Mastery, einmal berechnet. */
const abilityIndex = new Map();
for (const id of masteries.ids()) {
  for (const entry of masteries.get(id).skills) {
    abilityIndex.set(entry.ability, { mastery: id, requires: entry.requires });
  }
}

export function masteryOfAbility(abilityId) {
  return abilityIndex.get(abilityId) ?? null;
}
