import { Registry } from '../../core/Registry.js';

/**
 * Gegenstände als Registry-Daten mit additiven Stat-Boni.
 *
 * Felder:
 *   slot       mainHand | offHand | head | chest | hands | legs | feet
 *   grip       one_hand | two_hand | off_hand  (nur Waffen)
 *   dualWield  darf zusätzlich in die Nebenhand
 *   model      Anhang aus der AssetRegistry — fehlt er, ist das Item unsichtbar
 *   stats      additive Boni, die in deriveStats einfließen
 *   level      Mindeststufe
 */
export const items = new Registry('items');

export const EQUIPMENT_SLOTS = ['mainHand', 'offHand', 'head', 'chest', 'hands', 'legs', 'feet'];

export const SLOT_LABELS = {
  mainHand: 'Haupthand',
  offHand: 'Nebenhand',
  head: 'Helm',
  chest: 'Brust',
  hands: 'Handschuhe',
  legs: 'Hose',
  feet: 'Schuhe',
};

items.registerAll({
  // --- Waffen --------------------------------------------------------------
  'item.sword.iron': {
    name: 'Eisenschwert', slot: 'mainHand', grip: 'one_hand', model: 'weapon.sword',
    level: 1, rarity: 'common', stats: { physicalPower: 6 },
  },
  'item.sword.jade': {
    name: 'Jadeklinge', slot: 'mainHand', grip: 'one_hand', model: 'weapon.sword',
    level: 4, rarity: 'rare', stats: { physicalPower: 11, magicPower: 5, critChance: 0.02 },
  },
  'item.dagger.swift': {
    name: 'Flinker Dolch', slot: 'mainHand', grip: 'one_hand', dualWield: true, model: 'weapon.dagger',
    level: 1, rarity: 'common', stats: { physicalPower: 3, critChance: 0.04, critDamage: 0.08 },
  },
  'item.greatsword.oak': {
    name: 'Eichenklinge', slot: 'mainHand', grip: 'two_hand', model: 'weapon.greatsword',
    level: 3, rarity: 'common', stats: { physicalPower: 14, armor: 3 },
  },
  'item.spear.guard': {
    name: 'Wachspeer', slot: 'mainHand', grip: 'two_hand', model: 'weapon.spear',
    level: 2, rarity: 'common', stats: { physicalPower: 10 },
  },
  'item.bow.hunter': {
    name: 'Jagdbogen', slot: 'mainHand', grip: 'two_hand', model: 'weapon.bow',
    level: 1, rarity: 'common', stats: { physicalPower: 8, critChance: 0.03 },
  },
  'item.staff.apprentice': {
    name: 'Lehrlingsstab', slot: 'mainHand', grip: 'two_hand', model: 'weapon.staff',
    level: 1, rarity: 'common', stats: { magicPower: 9, maxMana: 20, manaRegen: 0.3 },
  },
  'item.shield.round': {
    name: 'Rundschild', slot: 'offHand', grip: 'off_hand', model: 'shield.round',
    level: 1, rarity: 'common', stats: { armor: 8, maxHealth: 20 },
  },

  // --- Rüstung -------------------------------------------------------------
  'item.helm.leather': {
    name: 'Lederkappe', slot: 'head', model: 'armor.helm',
    level: 1, rarity: 'common', stats: { armor: 4, maxHealth: 8 },
  },
  'item.helm.iron': {
    name: 'Eisenhelm', slot: 'head', model: 'armor.helm.iron',
    level: 4, rarity: 'rare', stats: { armor: 9, maxHealth: 18, magicResist: 3 },
  },
  'item.chest.leather': {
    name: 'Lederwams', slot: 'chest', model: 'armor.chest',
    level: 1, rarity: 'common', stats: { armor: 7, maxHealth: 15 },
  },
  'item.chest.iron': {
    name: 'Eisenpanzer', slot: 'chest', model: 'armor.chest.iron',
    level: 5, rarity: 'rare', stats: { armor: 16, maxHealth: 35, moveSpeed: 0 },
  },
  'item.gloves.leather': {
    name: 'Lederhandschuhe', slot: 'hands',
    level: 1, rarity: 'common', stats: { armor: 2, critDamage: 0.05 },
  },
  'item.legs.leather': {
    name: 'Lederhose', slot: 'legs',
    level: 1, rarity: 'common', stats: { armor: 5, maxHealth: 10 },
  },
  'item.boots.leather': {
    name: 'Lederstiefel', slot: 'feet',
    level: 1, rarity: 'common', stats: { armor: 3, healthRegen: 0.2 },
  },
  'item.boots.swift': {
    name: 'Windläufer', slot: 'feet',
    level: 3, rarity: 'rare', stats: { armor: 2, healthRegen: 0.15, critChance: 0.02 },
  },
});

/** Welcher Anhang gehört zu diesem Item — die Brücke zur Anzeige. */
export function modelOfItem(itemId) {
  return itemId ? (items.find(itemId)?.model ?? null) : null;
}

export function labelOfItem(itemId) {
  return itemId ? (items.find(itemId)?.name ?? itemId) : null;
}
