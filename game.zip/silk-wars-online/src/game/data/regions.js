import { Registry } from '../../core/Registry.js';

/**
 * Gebiete als Daten: Mittelpunkt, Ausdehnung, Besatz und Wahrzeichen.
 *
 * Ein neues Gebiet ist ein Eintrag hier — die Welt setzt sich beim Start
 * daraus zusammen, und die Umgebung hält die Mittelpunkte frei, damit weder
 * Bäume im Lagerfeuer stehen noch Gegner im Felsen aufwachen.
 */
export const regions = new Registry('regions');

regions.registerAll({
  'region.clearing': {
    name: 'Die Lichtung',
    center: { x: 0, z: 0 },
    radius: 26,
    clearing: 11,
    landmark: null,
    levelRange: [1, 4],
    spawns: [
      { template: 'npc.villager', count: 1, near: { x: -7, z: 3 } },
      { template: 'npc.warrior', count: 1, near: { x: 6.5, z: 4 } },
      { template: 'npc.archer', count: 1, near: { x: -4, z: -7 } },
      { template: 'npc.mage', count: 1, near: { x: 4.5, z: -8 } },
      { template: 'beast.wolf', count: 4, minDistance: 13 },
    ],
  },

  'region.camp': {
    name: 'Verfallenes Lager',
    center: { x: -58, z: -46 },
    radius: 21,
    clearing: 9,
    landmark: 'camp',
    levelRange: [5, 8],
    spawns: [
      { template: 'npc.bandit', count: 3, minDistance: 6 },
      { template: 'beast.direwolf', count: 3, minDistance: 10 },
      { template: 'beast.bear', count: 1, minDistance: 12 },
    ],
  },
});

/** Freizuhaltende Flächen für die Umgebungsgenerierung. */
export function clearingsOf() {
  return regions.all().map((region) => ({
    x: region.center.x,
    z: region.center.z,
    radius: region.clearing ?? 8,
  }));
}
