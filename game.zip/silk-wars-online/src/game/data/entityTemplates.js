import { Registry } from '../../core/Registry.js';

/**
 * Wer in der Welt existieren kann — als Daten.
 *
 * "model" verweist in die AssetRegistry, "behavior" wird ab Phase 7 von der
 * KI-Zustandsmaschine gelesen. Ein neues Monster ist ein Eintrag hier plus
 * ein Körper-Template, kein neuer Code.
 */
export const entityTemplates = new Registry('entities');

entityTemplates.registerAll({
  'player': {
    name: 'Wanderer',
    model: 'character.player',
    faction: 'player',
  },
  'npc.villager': {
    name: 'Dorfbewohner',
    experience: 6,
    model: 'character.villager',
    faction: 'neutral',
    respawn: 30,
    attributes: { strength: 4, dexterity: 5, intelligence: 4, vitality: 6 },
    ai: {
      behavior: 'passive', fleeOnDamage: true, fleeDuration: 6,
      aggroRadius: 0, leashRange: 28, wanderRadius: 7, moveSpeed: 3.4,
    },
  },
  'npc.warrior': {
    name: 'Wachsoldatin',
    experience: 70,
    model: 'character.warrior',
    faction: 'neutral',
    level: 4,
    respawn: 35,
    attributes: { strength: 11, dexterity: 6, intelligence: 4, vitality: 10 },
    equipment: { mainHand: 'item.greatsword.oak', head: 'item.helm.iron' },
    loot: [{ item: 'item.greatsword.oak', chance: 0.5 }, { item: 'item.helm.iron', chance: 0.3 }],
    ai: {
      behavior: 'neutral', attack: 'attack.greatsword',
      abilities: [{ ability: 'attack.shieldbash', maxRange: 3, chance: 0.7 }],
      aggroRadius: 0, leashRange: 20, chaseRange: 24, wanderRadius: 3, moveSpeed: 4.6,
    },
  },
  'npc.archer': {
    name: 'Jäger',
    experience: 55,
    model: 'character.archer',
    faction: 'neutral',
    level: 3,
    respawn: 35,
    attributes: { strength: 6, dexterity: 12, intelligence: 5, vitality: 6 },
    equipment: { mainHand: 'item.bow.hunter', chest: 'item.chest.leather' },
    loot: [{ item: 'item.bow.hunter', chance: 0.4 }, { item: 'item.boots.swift', chance: 0.25 }],
    ai: {
      behavior: 'neutral', attack: 'attack.bow',
      abilities: [{ ability: 'attack.crippleshot', minRange: 5, maxRange: 20, chance: 0.6 }],
      aggroRadius: 0, leashRange: 24, chaseRange: 28, wanderRadius: 3, moveSpeed: 4.8,
    },
  },
  'npc.mage': {
    name: 'Magierin',
    experience: 50,
    model: 'character.mage',
    faction: 'neutral',
    level: 3,
    respawn: 35,
    attributes: { strength: 3, dexterity: 6, intelligence: 13, vitality: 5 },
    equipment: { mainHand: 'item.staff.apprentice' },
    loot: [{ item: 'item.staff.apprentice', chance: 0.4 }, { item: 'item.sword.jade', chance: 0.15 }],
    ai: {
      behavior: 'passive', fleeOnDamage: true, fleeDuration: 5,
      aggroRadius: 0, leashRange: 26, wanderRadius: 4, moveSpeed: 3.8,
      abilities: [{ ability: 'attack.frostbolt', minRange: 4, maxRange: 16, chance: 0.8 }],
    },
  },
  'beast.wolf': {
    name: 'Waldwolf',
    experience: 30,
    model: 'beast.wolf',
    faction: 'hostile',
    level: 2,
    respawn: 20,
    masteryPoints: 0,   // Bosse setzen hier später einen Wert
    loot: [{ item: 'item.dagger.swift', chance: 0.12 }, { item: 'item.boots.leather', chance: 0.2 }],
    attributes: { strength: 8, dexterity: 9, intelligence: 2, vitality: 7 },
    ai: {
      behavior: 'aggressive', attack: 'attack.bite',
      // Der Satz überbrückt die Lücke: er greift nur aus mittlerer Entfernung.
      abilities: [{ ability: 'attack.pounce', minRange: 4.5, maxRange: 10, chance: 0.7 }],
      aggroFactions: ['player'],
      aggroRadius: 12, leashRange: 24, chaseRange: 30, wanderRadius: 9, moveSpeed: 5.4,
    },
  },

  // --- Zweites Gebiet: das verfallene Lager -------------------------------
  'npc.bandit': {
    name: 'Wegelagerer',
    model: 'character.villager',
    modelOptions: { palette: { tunic: '#3c3830', trousers: '#2f2c27', hair: '#241c16', skin: '#b07f56' } },
    faction: 'hostile',
    level: 5,
    experience: 65,
    respawn: 30,
    attributes: { strength: 10, dexterity: 13, intelligence: 5, vitality: 9 },
    equipment: { mainHand: 'item.dagger.swift', offHand: 'item.dagger.swift', chest: 'item.chest.leather' },
    loot: [{ item: 'item.dagger.swift', chance: 0.35 }, { item: 'item.boots.swift', chance: 0.2 }, { item: 'item.sword.jade', chance: 0.08 }],
    ai: {
      behavior: 'aggressive', attack: 'attack.dagger',
      abilities: [{ ability: 'attack.shieldbash', maxRange: 3, chance: 0.4 }],
      aggroFactions: ['player'], aggroRadius: 13, leashRange: 26, chaseRange: 32,
      wanderRadius: 6, moveSpeed: 5.6,
    },
  },

  'beast.direwolf': {
    name: 'Schattenwolf',
    model: 'beast.wolf',
    modelOptions: { scale: 1.3, palette: { fur: '#484038', furDark: '#2d2823' } },
    faction: 'hostile',
    level: 6,
    experience: 80,
    respawn: 25,
    attributes: { strength: 14, dexterity: 12, intelligence: 3, vitality: 12 },
    loot: [{ item: 'item.boots.swift', chance: 0.25 }, { item: 'item.helm.iron', chance: 0.15 }],
    ai: {
      behavior: 'aggressive', attack: 'attack.bite',
      abilities: [{ ability: 'attack.pounce', minRange: 4.5, maxRange: 12, chance: 0.8 }],
      aggroFactions: ['player'], aggroRadius: 15, leashRange: 28, chaseRange: 34,
      wanderRadius: 11, moveSpeed: 6.2,
    },
  },

  'beast.bear': {
    name: 'Waldbär',
    model: 'beast.bear',
    faction: 'hostile',
    level: 8,
    experience: 160,
    masteryPoints: 1,   // ein zäher Gegner gibt zusätzlich einen Punkt
    respawn: 60,
    attributes: { strength: 18, dexterity: 8, intelligence: 3, vitality: 20 },
    loot: [{ item: 'item.chest.iron', chance: 0.35 }, { item: 'item.helm.iron', chance: 0.3 }],
    ai: {
      behavior: 'aggressive', attack: 'attack.maul',
      abilities: [{ ability: 'attack.slam', maxRange: 4.5, chance: 0.75 }],
      aggroFactions: ['player'], aggroRadius: 15, leashRange: 24, chaseRange: 28,
      wanderRadius: 7, moveSpeed: 4.6,
    },
  },
});
