import { Registry } from '../../core/Registry.js';

/**
 * Statuseffekte als Daten — nicht als Sonderlogik pro Skill.
 *
 * Felder:
 *   blocks      welche Gates gesperrt werden: 'move' | 'act' | 'cast'
 *   modifiers   moveSpeed / damageTaken / damageDealt, jeweils relativ
 *               (-0.4 = 40 % langsamer, +0.3 = 30 % mehr Schaden erlitten)
 *   dot         Schaden pro Sekunde, mit Schadensschule
 *   impulse     Rückstoß; wird beim Anwenden einmalig in Bewegung übersetzt
 *   invulnerable  hebt jeden Schaden auf
 *   imbue       Waffenverzauberung: Zusatzschaden und On-Hit-Effekt
 *   stacking    'refresh' (Dauer erneuern) | 'stack' (bis maxStacks)
 */
export const statusEffects = new Registry('statusEffects');

statusEffects.registerAll({
  slow: {
    name: 'Verlangsamt', glyph: '❆', category: 'debuff',
    modifiers: { moveSpeed: -0.4 }, stacking: 'refresh',
  },
  root: {
    name: 'Gefesselt', glyph: '⛓', category: 'debuff',
    blocks: ['move'], stacking: 'refresh',
  },
  stun: {
    name: 'Betäubt', glyph: '✷', category: 'debuff',
    blocks: ['move', 'act', 'cast'], stacking: 'refresh',
  },
  freeze: {
    name: 'Eingefroren', glyph: '❄', category: 'debuff',
    blocks: ['move', 'act', 'cast'], modifiers: { damageTaken: 0.2 }, stacking: 'refresh',
  },
  knockdown: {
    name: 'Niedergeschlagen', glyph: '↓', category: 'debuff',
    blocks: ['move', 'act', 'cast'], stacking: 'refresh',
  },
  knockback: {
    name: 'Zurückgestoßen', glyph: '↗', category: 'debuff',
    impulse: { distance: 4.5, duration: 0.25 }, stacking: 'refresh',
  },
  silence: {
    name: 'Verstummt', glyph: '⊘', category: 'debuff',
    blocks: ['cast'], stacking: 'refresh',
  },
  burn: {
    name: 'Brennt', glyph: '🔥', category: 'debuff',
    dot: { school: 'magic', amount: 4 }, stacking: 'stack', maxStacks: 3,
  },
  poison: {
    name: 'Vergiftet', glyph: '☠', category: 'debuff',
    dot: { school: 'magic', amount: 3 }, stacking: 'stack', maxStacks: 5,
  },
  bleed: {
    name: 'Blutet', glyph: '≈', category: 'debuff',
    dot: { school: 'physical', amount: 3.5 }, stacking: 'stack', maxStacks: 4,
  },
  vulnerable: {
    name: 'Verwundbar', glyph: '◈', category: 'debuff',
    modifiers: { damageTaken: 0.3 }, stacking: 'refresh',
  },
  weaken: {
    name: 'Geschwächt', glyph: '▽', category: 'debuff',
    modifiers: { damageDealt: -0.3 }, stacking: 'refresh',
  },
  invulnerable: {
    name: 'Unverwundbar', glyph: '◇', category: 'buff',
    invulnerable: true, stacking: 'refresh',
  },
  block: {
    name: 'Deckung', glyph: '⊓', category: 'buff',
    modifiers: { damageTaken: -0.6, moveSpeed: -0.4 }, stacking: 'refresh',
  },
  conceal: {
    name: 'Verschleiert', glyph: '☁', category: 'buff',
    // Weniger Schaden, dafür sieht einen niemand: die KI übergeht Verschleierte.
    modifiers: { damageDealt: -0.35 }, hidden: true, stacking: 'refresh',
  },
  protected: {
    name: 'Beschützt', glyph: '✧', category: 'buff',
    modifiers: { damageTaken: -0.3 }, stacking: 'refresh',
  },
  taunted: {
    name: 'Verhöhnt', glyph: '‼', category: 'debuff', stacking: 'refresh',
  },
  bulwark: {
    name: 'Schildwall', glyph: '🛡', category: 'buff',
    modifiers: { damageTaken: -0.35, moveSpeed: -0.15 }, stacking: 'refresh',
  },
  haste: {
    name: 'Hast', glyph: '⏵', category: 'buff',
    modifiers: { moveSpeed: 0.25, damageDealt: 0.1 }, stacking: 'refresh',
  },
  blind: {
    name: 'Geblendet', glyph: '◌', category: 'debuff',
    modifiers: { damageDealt: -0.6 }, stacking: 'refresh',
  },
  static: {
    name: 'Aufgeladen', glyph: '⚡', category: 'debuff',
    modifiers: { damageTaken: 0.1 }, stacking: 'refresh',
  },
  iceshield: {
    name: 'Eisschild', glyph: '❅', category: 'buff',
    modifiers: { damageTaken: -0.35 }, stacking: 'refresh',
  },
  lightningspeed: {
    name: 'Blitzschnell', glyph: '⏵', category: 'buff',
    modifiers: { moveSpeed: 0.45 }, stacking: 'refresh',
  },
  'imbue.fire': {
    name: 'Feuerbann', glyph: '☄', category: 'buff', stacking: 'refresh',
    // Zusatzschaden auf Waffentreffer. Der Anteil hängt vom Verhältnis
    // STR:INT ab — ein reiner Krieger holt daraus wenig, ein Hybrid viel.
    // Dazu Prozente aus der Skill-Liste: 30 % Brand, 5 % Blenden.
    imbue: {
      element: 'fire', school: 'magic', coefficient: 0.85,
      onHit: [
        { effect: 'burn', duration: 3, chance: 0.3 },
        { effect: 'blind', duration: 1, chance: 0.05 },
      ],
    },
  },

  'imbue.ice': {
    name: 'Eisbann', glyph: '❄', category: 'buff', stacking: 'refresh',
    imbue: {
      element: 'ice', school: 'magic', coefficient: 0.75,
      onHit: [
        { effect: 'slow', duration: 2, magnitude: 0.4, chance: 0.3 },
        { effect: 'freeze', duration: 1, chance: 0.05 },
      ],
    },
  },

  'imbue.lightning': {
    name: 'Blitzbann', glyph: '⚡', category: 'buff', stacking: 'refresh',
    imbue: {
      element: 'lightning', school: 'magic', coefficient: 0.8,
      onHit: [
        // Static überträgt den Schlag auf einen weiteren Gegner in der Nähe.
        {
          effect: 'static', duration: 4, chance: 0.3,
          components: [{
            type: 'chain', jumps: 1, range: 6, falloff: 0.5,
            components: [{ type: 'damage', school: 'magic', base: 3, coefficient: 0.35 }],
          }],
        },
        { effect: 'stun', duration: 1.5, chance: 0.05 },
      ],
    },
  },
});
