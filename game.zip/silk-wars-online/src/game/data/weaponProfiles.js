import { Registry } from '../../core/Registry.js';

/**
 * Welche Autoattack zu welcher Waffe gehört — als Daten, nicht als
 * Fallunterscheidung. Der Schlüssel ist die Ausrüstungs-ID aus der
 * AssetRegistry; "unarmed" greift, wenn die Haupthand leer ist.
 */
export const weaponProfiles = new Registry('weaponProfiles');

weaponProfiles.registerAll({
  'unarmed': { ability: 'attack.unarmed' },
  'weapon.sword': { ability: 'attack.sword' },
  'weapon.dagger': { ability: 'attack.dagger' },
  'weapon.greatsword': { ability: 'attack.greatsword' },
  'weapon.spear': { ability: 'attack.spear' },
  'weapon.bow': { ability: 'attack.bow' },
  'weapon.staff': { ability: 'attack.staff' },
});

export function autoAttackFor(itemId) {
  return weaponProfiles.find(itemId ?? 'unarmed') ?? weaponProfiles.get('unarmed');
}
