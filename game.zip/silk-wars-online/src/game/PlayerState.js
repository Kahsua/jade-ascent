import { CONFIG } from '../core/Config.js';
import { EntityState } from './entities/EntityState.js';
import { DEFAULT_ACTION_BARS } from './data/abilities.js';

/**
 * Spielerzustand: EntityState plus alles, was nur der Spieler hat.
 *
 * Persistenz-Vorbereitung: toJSON() liefert exakt das Dokument, das in
 * Phase 10 nach Firestore geht. Neue Systeme hängen sich hier an, statt
 * eigenen Zustand irgendwo zu verstreuen.
 */
export class PlayerState extends EntityState {
  constructor(init = {}) {
    super({ id: 'player', name: 'Wanderer', ...init });

    this.experience = init.experience ?? 0;
    this.unspentAttributePoints = init.unspentAttributePoints ?? CONFIG.progression.startPool;
    this.masteryPoints = init.masteryPoints ?? CONFIG.progression.startMasteryPoints;

    // Ab Phase 8/9 gefüllt, hier schon vorhanden, damit das Format steht.
    this.masteries = init.masteries ?? {};
    this.skillRanks = init.skillRanks ?? {};
    this.equipment = init.equipment ?? { mainHand: 'item.sword.iron' };
    this.inventory = init.inventory ?? [
      'item.bow.hunter', 'item.staff.apprentice',
      'item.dagger.swift', 'item.dagger.swift',
      'item.shield.round', 'item.helm.leather', 'item.chest.leather',
      'item.boots.leather',
    ];
    this.actionBars = init.actionBars ?? DEFAULT_ACTION_BARS.map((bar) => [...bar]);
  }

  toJSON() {
    return {
      version: 2,
      ...super.toJSON(),
      experience: this.experience,
      unspentAttributePoints: this.unspentAttributePoints,
      masteryPoints: this.masteryPoints,
      masteries: { ...this.masteries },
      skillRanks: { ...this.skillRanks },
      equipment: { ...this.equipment },
      inventory: [...this.inventory],
      actionBars: this.actionBars.map((bar) => [...bar]),
    };
  }

  static fromJSON(data) {
    return new PlayerState(data ?? {});
  }
}
