import { masteries, masteryOfAbility, synergies } from '../data/masteries.js';
import { abilities } from '../data/abilities.js';

const MAX_RANK = 10;

/**
 * Masteries, Skill-Ränge und der gemeinsame Punkte-Pool — eine Komponente
 * pro Entity, die auf dem serialisierbaren Zustand arbeitet.
 *
 * Regeln:
 *   - Mastery-Level kostet 1 Punkt, Skill-Rang kostet 1 Punkt: gleicher Pool.
 *   - Ein Skill ist ab dem im Mastery hinterlegten Level verfügbar.
 *   - Ein Skill-Rang kann das Mastery-Level nie übersteigen (Obergrenze 10).
 *     Daraus entsteht die Entscheidung zwischen breit und tief.
 */
export class SkillProgression {
  constructor({ state, onChange = null }) {
    this.state = state;
    this.onChange = onChange;
  }

  get points() {
    return this.state.masteryPoints;
  }

  masteryLevel(masteryId) {
    return this.state.masteries[masteryId] ?? 0;
  }

  rankOf(abilityId) {
    return this.state.skillRanks[abilityId] ?? 0;
  }

  /** Grundfähigkeiten (Ausweichen, Autoattacks) hängen an keiner Mastery. */
  isUnlocked(abilityId) {
    const definition = abilities.find(abilityId);
    if (!definition) return false;
    if (definition.basic || definition.hidden) return true;
    return this.rankOf(abilityId) > 0;
  }

  // --- Punkte ausgeben ------------------------------------------------------

  masteryCost() { return 1; }
  skillCost() { return 1; }

  canLevelMastery(masteryId) {
    const definition = masteries.find(masteryId);
    if (!definition) return false;
    if (this.masteryLevel(masteryId) >= definition.maxLevel) return false;
    return this.points >= this.masteryCost();
  }

  levelMastery(masteryId) {
    if (!this.canLevelMastery(masteryId)) return false;
    this.state.masteryPoints -= this.masteryCost();
    this.state.masteries[masteryId] = this.masteryLevel(masteryId) + 1;
    this.onChange?.(this, { type: 'mastery', id: masteryId, level: this.state.masteries[masteryId] });
    return true;
  }

  canRankSkill(abilityId) {
    const link = masteryOfAbility(abilityId);
    if (!link) return false;

    const masteryLevel = this.masteryLevel(link.mastery);
    if (masteryLevel < link.requires) return false;

    const rank = this.rankOf(abilityId);
    if (rank >= Math.min(MAX_RANK, masteryLevel)) return false;
    return this.points >= this.skillCost();
  }

  rankSkill(abilityId) {
    if (!this.canRankSkill(abilityId)) return false;
    this.state.masteryPoints -= this.skillCost();
    this.state.skillRanks[abilityId] = this.rankOf(abilityId) + 1;
    this.onChange?.(this, { type: 'skill', id: abilityId, rank: this.state.skillRanks[abilityId] });
    return true;
  }

  /**
   * Generischer Weg, Punkte zu vergeben — von Level-Ups, aber genauso von
   * Bosskills oder Quests, auch nach Erreichen des Maximallevels.
   */
  grantPoints(amount, source = 'unknown') {
    if (amount <= 0) return this.points;
    this.state.masteryPoints += amount;
    this.onChange?.(this, { type: 'points', amount, source });
    return this.points;
  }

  // --- Abgeleitete Wirkung --------------------------------------------------

  activeSynergies() {
    return synergies.ids()
      .map((id) => ({ id, ...synergies.get(id) }))
      .filter((synergy) => Object.entries(synergy.requires)
        .every(([masteryId, level]) => this.masteryLevel(masteryId) >= level));
  }

  /** Passive Werte aus Mastery-Leveln und aktiven Synergien, additiv. */
  statBonuses() {
    const bonuses = {};
    const add = (stat, value) => { bonuses[stat] = (bonuses[stat] ?? 0) + value; };

    for (const masteryId of Object.keys(this.state.masteries)) {
      const definition = masteries.find(masteryId);
      const level = this.masteryLevel(masteryId);
      if (!definition || level <= 0) continue;
      for (const bonus of definition.bonuses ?? []) add(bonus.stat, bonus.perLevel * level);
    }

    for (const synergy of this.activeSynergies()) {
      for (const effect of synergy.effects) {
        if (effect.type === 'stat') add(effect.stat, effect.add);
      }
    }

    return bonuses;
  }

  /** Schadensbonus für eine einzelne Fähigkeit aus Synergien. */
  abilityBonus(abilityId) {
    let bonus = 0;
    for (const synergy of this.activeSynergies()) {
      for (const effect of synergy.effects) {
        if (effect.type === 'ability' && effect.ability === abilityId) bonus += effect.damage ?? 0;
      }
    }
    return bonus;
  }

  /** Überblick für das Skillfenster. */
  overview() {
    return masteries.ids().map((masteryId) => {
      const definition = masteries.get(masteryId);
      const level = this.masteryLevel(masteryId);

      return {
        id: masteryId,
        name: definition.name,
        glyph: definition.glyph,
        category: definition.category,
        level,
        maxLevel: definition.maxLevel,
        canLevel: this.canLevelMastery(masteryId),
        skills: definition.skills.map((entry) => {
          const ability = abilities.get(entry.ability);
          const rank = this.rankOf(entry.ability);
          return {
            ability: entry.ability,
            name: ability.name,
            glyph: ability.glyph,
            requires: entry.requires,
            available: level >= entry.requires,
            rank,
            maxRank: Math.min(MAX_RANK, Math.max(level, 1)),
            canRank: this.canRankSkill(entry.ability),
          };
        }),
      };
    });
  }
}
