import { CONFIG } from '../../core/Config.js';
import { experienceForLevel } from '../stats/deriveStats.js';
import { labelOfItem } from '../data/items.js';

/**
 * Erfahrung, Level-Ups, Attribut- und Masterypunkte.
 *
 * Wichtig aus dem Auftrag: Punktevergabe hängt NICHT nur an Level-Ups.
 * grantMasteryPoints(amount, source) ist der generische Weg — Bosskills,
 * Quests oder Ereignisse rufen dieselbe Methode auf, auch nach Erreichen des
 * Maximallevels, ohne dass am Levelsystem etwas geändert werden muss.
 */
export class ProgressionSystem {
  constructor({ entities, bus, playerId = 'player' }) {
    this.entities = entities;
    this.bus = bus;
    this.playerId = playerId;

    bus.on('entity:died', ({ id, source }) => {
      if (!source || source !== this.playerId || id === this.playerId) return;
      this.awardKill(id);
    });
  }

  get player() {
    return this.entities.get(this.playerId);
  }

  awardKill(victimId) {
    const victim = this.entities.get(victimId);
    if (!victim) return 0;

    const reward = victim.template.experience ?? 0;
    if (reward > 0) {
      this.grantExperience(reward, `kill:${victim.template.id}`);
      this.bus.emit('ui:notice', { text: `+${reward} Erfahrung (${victim.state.name})`, tone: 'hint' });
    }

    this.#rollLoot(victim);

    // Beispiel für die zweite Quelle: besondere Gegner geben zusätzlich Punkte.
    if (victim.template.masteryPoints) {
      this.grantMasteryPoints(victim.template.masteryPoints, `kill:${victim.template.id}`);
    }
    return reward;
  }

  /** Beutetabelle des Templates auswerten — Daten, keine Fallunterscheidung. */
  #rollLoot(victim) {
    const player = this.player;
    if (!player?.equipment) return;

    for (const entry of victim.template.loot ?? []) {
      if (Math.random() > (entry.chance ?? 0)) continue;
      player.equipment.addToInventory(entry.item);
      this.bus.emit('ui:notice', { text: `Beute: ${labelOfItem(entry.item)}`, tone: 'hint' });
    }
  }

  grantExperience(amount, source = 'unknown') {
    const player = this.player;
    if (!player || amount <= 0) return;

    const state = player.state;
    state.experience += amount;

    while (state.level < CONFIG.progression.maxLevel && state.experience >= experienceForLevel(state.level)) {
      state.experience -= experienceForLevel(state.level);
      this.#levelUp(player);
    }

    this.bus.emit('entity:experience', {
      id: player.id, experience: state.experience, level: state.level, source,
    });
  }

  /** Generisch — von Level-Ups, Bosskills, Quests, jederzeit aufrufbar. */
  grantMasteryPoints(amount, source = 'unknown') {
    const player = this.player;
    if (!player?.skills || amount <= 0) return 0;

    const total = player.skills.grantPoints(amount, source);
    this.bus.emit('progression:changed', { id: player.id, reason: 'points', amount, source });
    return total;
  }

  spendAttributePoint(attribute) {
    const player = this.player;
    if (!player) return false;

    const state = player.state;
    if (state.unspentAttributePoints <= 0) return false;
    if (!(attribute in state.attributes)) return false;

    state.attributes[attribute] += 1;
    state.unspentAttributePoints -= 1;
    player.recalculate();
    this.bus.emit('progression:changed', { id: player.id, reason: 'attribute', attribute });
    return true;
  }

  #levelUp(player) {
    const state = player.state;
    state.level += 1;
    state.unspentAttributePoints += CONFIG.progression.attributePointsPerLevel;

    player.recalculate();
    player.resources.revive();

    if (player.skills) player.skills.grantPoints(CONFIG.progression.masteryPointsPerLevel, 'levelup');

    this.bus.emit('entity:levelup', {
      id: player.id,
      level: state.level,
      attributePoints: state.unspentAttributePoints,
      masteryPoints: state.masteryPoints,
    });
    this.bus.emit('ui:notice', { text: `Stufe ${state.level} erreicht!`, tone: 'hint' });
  }
}
