/**
 * Rang-abhängige Skalierung einer Fähigkeit.
 *
 * Rang 1 bis 10; jeder Rang darüber hinaus verstärkt Schaden und Heilung,
 * verkürzt die Abklingzeit leicht und vergrößert Radius und Reichweite.
 * Die Werte stehen pro Fähigkeit in "scaling", sonst greift der Standard.
 *
 * Wichtig: Die Funktion verändert die Registry-Daten NICHT, sie liefert eine
 * skalierte Kopie. Sonst würde ein Rangaufstieg die Definition dauerhaft
 * verbiegen.
 */
const DEFAULT_SCALING = { damage: 0.12, cooldown: -0.015, radius: 0.015, range: 0.01, duration: 0.04 };

function scaleComponents(components, factor, scaling, steps) {
  return components.map((component) => {
    const copy = { ...component };

    if (component.base !== undefined) copy.base = component.base * factor;
    if (component.coefficient !== undefined) copy.coefficient = component.coefficient * factor;
    if (component.radius !== undefined) copy.radius = component.radius * (1 + scaling.radius * steps);
    if (component.duration !== undefined) copy.duration = component.duration * (1 + scaling.duration * steps);
    if (component.components) copy.components = scaleComponents(component.components, factor, scaling, steps);
    if (component.onHit) copy.onHit = scaleComponents(component.onHit, factor, scaling, steps);

    return copy;
  });
}

export function scaleAbility(ability, rank = 1, abilityBonus = 0) {
  const steps = Math.max(0, (rank ?? 1) - 1);
  if (steps === 0 && !abilityBonus) return ability;

  const scaling = { ...DEFAULT_SCALING, ...(ability.scaling ?? {}) };
  const factor = (1 + scaling.damage * steps) * (1 + abilityBonus);

  return {
    ...ability,
    rank,
    cooldown: ability.cooldown ? ability.cooldown * (1 + scaling.cooldown * steps) : ability.cooldown,
    range: ability.range ? ability.range * (1 + scaling.range * steps) : ability.range,
    radius: ability.radius ? ability.radius * (1 + scaling.radius * steps) : ability.radius,
    components: scaleComponents(ability.components ?? [], factor, scaling, steps),
  };
}
