/**
 * Taktet alle KI-Komponenten und schiebt ihre Laufabsicht durch dieselbe
 * Bewegung wie den Spieler — inklusive Kollision, Terrainhöhe, Rückstoß und
 * der Gates aus dem StatusEffectController.
 */
export class AiSystem {
  constructor({ entities, bus, movement, playerId = 'player' }) {
    this.entities = entities;
    this.bus = bus;
    this.movement = movement;
    this.playerId = playerId;

    bus.on('entity:damaged', ({ id, source }) => {
      this.entities.get(id)?.ai?.onDamaged(source);
    });
  }

  update(dt) {
    for (const entity of this.entities.all()) {
      if (entity.id === this.playerId) continue;

      const intent = entity.isAlive ? (entity.ai?.update(dt) ?? null) : null;
      this.movement.update(entity.state, dt, intent, entity.status);
    }
  }
}
