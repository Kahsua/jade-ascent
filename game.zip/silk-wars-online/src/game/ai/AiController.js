import { abilities } from '../data/abilities.js';
import { isHostile } from '../combat/factions.js';

/**
 * Zustandsmaschine pro Monster — eine Komponente wie ResourcePool oder
 * StatusEffectController, kein Sonderfall im Entity-Code.
 *
 *   wandern -> verfolgen -> angreifen -> zurückkehren (Leash)
 *
 * Drei Verhaltenstypen aus den Template-Daten:
 *   passiv      greift nie an
 *   neutral     wehrt sich erst nach einem Treffer
 *   aggressiv   greift von sich aus an, sobald jemand in den Aggro-Radius kommt
 *
 * Angriffe laufen über "ability:requested" — dieselbe Meldung, die auch die
 * Action-Bar des Spielers sendet. Kein Parallelsystem: Reichweite,
 * Abklingzeit, Mana, Schadensformel und Statuseffekte prüft derselbe
 * AbilityExecutor.
 */
export class AiController {
  constructor({ entity, entities, bus, profile }) {
    this.entity = entity;
    this.entities = entities;
    this.bus = bus;
    this.profile = profile;

    this.state = 'idle';
    this.targetId = null;
    this.moveIntent = null;
    this.timer = 0;
    this.scanTimer = Math.random() * 0.3;
    this.wanderPoint = null;
    this.forcedUntil = 0;

    // Zustandsmaschine als Tabelle statt als switch.
    this.states = {
      idle: (dt) => this.#idle(dt),
      wander: (dt) => this.#wander(dt),
      chase: (dt) => this.#chase(dt),
      attack: (dt) => this.#attack(dt),
      return: (dt) => this.#return(dt),
      flee: (dt) => this.#flee(dt),
    };
  }

  get position() { return this.entity.state.position; }
  get spawn() { return this.entity.state.spawnPoint; }
  get target() { return this.targetId ? this.entities.get(this.targetId) : null; }

  get attackAbility() {
    const id = this.profile.attack;
    return id ? { id, ...abilities.get(id) } : null;
  }

  /** Reichweite kommt aus den Fähigkeiten-Daten, nicht doppelt aus dem Profil. */
  get attackRange() {
    return this.attackAbility?.range ?? 2.5;
  }

  /** Spott: für eine Weile gibt es nur noch dieses eine Ziel. */
  forceTarget(targetId, duration = 5) {
    this.targetId = targetId;
    this.forcedUntil = duration;
    this.#enter('chase');
  }

  // --- Ereignisse ----------------------------------------------------------

  /** Wurde getroffen: Neutrale wehren sich, Passive nehmen Reißaus. */
  onDamaged(sourceId) {
    if (!sourceId || sourceId === this.entity.id) return;
    if (this.forcedUntil > 0) return;   // Spott geht vor
    const attacker = this.entities.get(sourceId);
    if (!attacker || !isHostile(this.entity, attacker)) return;

    if (this.profile.behavior === 'passive') {
      if (this.profile.fleeOnDamage) {
        this.targetId = sourceId;
        this.#enter('flee', this.profile.fleeDuration ?? 5);
      }
      return;
    }

    if (this.state === 'return') return;   // auf dem Rückweg ist Ruhe
    this.#engage(sourceId);
  }

  // --- Takt ----------------------------------------------------------------

  update(dt) {
    this.moveIntent = null;
    if (this.forcedUntil > 0) this.forcedUntil -= dt;
    const status = this.entity.status;

    // Betäubt, gefesselt, eingefroren: die Gates entscheiden, nicht die KI.
    if (!status.canMove() && !status.canAct()) return null;

    if (this.state !== 'return' && this.#distanceTo(this.spawn) > this.profile.leashRange) {
      this.#enter('return');
    }

    this.states[this.state](dt);
    return status.canMove() ? this.moveIntent : null;
  }

  // --- Zustände ------------------------------------------------------------

  #idle(dt) {
    this.timer -= dt;
    // Hat der Scan ein Ziel gefunden, ist der Zustand schon gewechselt —
    // dann hier nicht weiterlaufen und ihn wieder überschreiben.
    if (this.#scan(dt)) return;
    if (this.timer > 0) return;

    if (this.profile.wanderRadius > 0) {
      const angle = Math.random() * Math.PI * 2;
      const distance = Math.random() * this.profile.wanderRadius;
      this.wanderPoint = {
        x: this.spawn.x + Math.cos(angle) * distance,
        z: this.spawn.z + Math.sin(angle) * distance,
      };
      this.#enter('wander', 6);
    } else {
      this.timer = 2;
    }
  }

  #wander(dt) {
    this.timer -= dt;
    if (this.#scan(dt)) return;

    if (!this.wanderPoint || this.timer <= 0 || this.#distanceTo(this.wanderPoint) < 0.6) {
      return this.#enter('idle', 1.5 + Math.random() * 3);
    }
    this.moveIntent = this.#directionTo(this.wanderPoint, this.profile.wanderSpeed ?? 0.45);
  }

  #chase() {
    const target = this.target;
    if (!target?.isAlive) return this.#enter('return');

    const distance = this.#distanceTo(target.position);

    // Lückenschließer wie der Satz werden schon im Verfolgen eingesetzt.
    if (this.entity.status.canAct() && this.#useAbility(target, distance)) return;
    if (distance <= this.attackRange * 0.92) return this.#enter('attack');
    if (distance > (this.profile.chaseRange ?? this.profile.aggroRadius * 2.2)) return this.#enter('return');

    this.moveIntent = this.#directionTo(target.position);
  }

  #attack() {
    const target = this.target;
    if (!target?.isAlive) return this.#enter('return');

    const distance = this.#distanceTo(target.position);
    if (distance > this.attackRange * 1.1) return this.#enter('chase');

    // Im Kampf zum Ziel drehen, auch wenn man stehen bleibt.
    this.entity.state.facing = Math.atan2(
      target.position.x - this.position.x,
      target.position.z - this.position.z,
    );

    if (!this.entity.status.canAct()) return;

    // Erst die Sonderfähigkeiten, dann der normale Angriff.
    if (this.#useAbility(target, distance)) return;

    // Abklingzeit der Angriffsfähigkeit IST die Angriffsgeschwindigkeit.
    const ability = this.attackAbility;
    if (!ability || !this.entity.cooldowns.isReady(ability)) return;

    this.bus.emit('ability:requested', {
      abilityId: ability.id,
      casterId: this.entity.id,
      targetId: target.id,
      point: null,
    });
  }

  /**
   * Sonderfähigkeiten aus dem Profil durchgehen. Reichweiten und Chancen sind
   * Daten; ob genug Mana da ist und ob die Abklingzeit steht, prüft ohnehin
   * der Executor.
   * @returns {boolean} ob eine Fähigkeit ausgelöst wurde
   */
  #useAbility(target, distance) {
    for (const entry of this.profile.abilities ?? []) {
      const definition = abilities.find(entry.ability);
      if (!definition) continue;

      const ability = { id: entry.ability, ...definition };
      if (!this.entity.cooldowns.isReady(ability)) continue;

      const min = entry.minRange ?? 0;
      const max = entry.maxRange ?? ability.range ?? this.attackRange;
      if (distance < min || distance > max) continue;
      if (entry.chance !== undefined && Math.random() > entry.chance) continue;

      this.entity.state.facing = Math.atan2(
        target.position.x - this.position.x,
        target.position.z - this.position.z,
      );
      this.bus.emit('ability:requested', {
        abilityId: ability.id, casterId: this.entity.id, targetId: target.id, point: null,
      });
      return true;
    }
    return false;
  }

  #return() {
    const distance = this.#distanceTo(this.spawn);
    this.targetId = null;

    if (distance < 0.8) {
      // Zurück am Spawn: auffüllen und beruhigen, wie in klassischen MMOs.
      this.entity.resources.revive();
      this.entity.status.clear();
      return this.#enter('idle', 1 + Math.random() * 2);
    }
    this.moveIntent = this.#directionTo(this.spawn, 1.15);
  }

  #flee(dt) {
    this.timer -= dt;
    const threat = this.target;

    if (this.timer <= 0 || !threat?.isAlive) {
      this.targetId = null;
      return this.#enter('return');
    }

    const away = this.#directionTo(threat.position, 1.2);
    this.moveIntent = away ? { x: -away.x, z: -away.z } : null;
  }

  // --- Hilfen --------------------------------------------------------------

  /**
   * Aggressive Monster suchen selbstständig nach Zielen.
   * @returns {boolean} true, wenn dabei ein Ziel aufgenommen wurde
   */
  #scan(dt) {
    if (this.profile.behavior !== 'aggressive') return false;
    this.scanTimer -= dt;
    if (this.scanTimer > 0) return false;
    this.scanTimer = 0.3;

    const factions = this.profile.aggroFactions ?? ['player'];
    let closest = null;
    let closestDistance = this.profile.aggroRadius;

    for (const candidate of this.entities.all()) {
      if (!candidate.isAlive || candidate.id === this.entity.id) continue;
      if (!factions.includes(candidate.template.faction)) continue;
      if (candidate.status.has('conceal')) continue;   // Verschleierte sieht niemand

      const distance = this.#distanceTo(candidate.position);
      if (distance < closestDistance) {
        closest = candidate;
        closestDistance = distance;
      }
    }

    if (!closest) return false;
    this.#engage(closest.id);
    return true;
  }

  #engage(targetId) {
    this.targetId = targetId;
    this.#enter('chase');
    this.bus.emit('ai:aggro', { id: this.entity.id, targetId });
  }

  #enter(state, timer = 0) {
    if (this.state !== state) this.bus.emit('ai:state', { id: this.entity.id, state });
    this.state = state;
    this.timer = timer;
  }

  #distanceTo(point) {
    return Math.hypot(point.x - this.position.x, point.z - this.position.z);
  }

  #directionTo(point, scale = 1) {
    const dx = point.x - this.position.x;
    const dz = point.z - this.position.z;
    const length = Math.hypot(dx, dz);
    if (length < 0.001) return null;
    return { x: (dx / length) * scale, z: (dz / length) * scale };
  }
}
