import { CONFIG } from '../core/Config.js';
import { smoothstep } from '../core/math.js';

/**
 * Die Weltform als reine Mathematik — kein three-Import.
 *
 * Wichtig für die Architektur: Sowohl das Terrain-Mesh (Anzeige) als auch die
 * Bewegung (Logik) lesen dieselbe Funktion. Die Logik braucht also keinen
 * Raycast gegen ein Mesh, um zu wissen, wie hoch der Boden ist — sie könnte
 * ohne Renderer laufen. Raycasting bleibt für das reserviert, wofür es
 * wirklich nötig ist: Maus -> Weltpunkt (Phase 4) und Kamera-Kollision.
 */

const { size, hillHeight, spawnFlatRadius, edgeMargin } = CONFIG.world;

export const WORLD_SIZE = size;
export const WORLD_HALF = size / 2 - edgeMargin;

function hash2(ix, iz) {
  let h = Math.imul(ix, 374761393) ^ Math.imul(iz, 668265263);
  h = Math.imul(h ^ (h >>> 13), 1274126177);
  return ((h ^ (h >>> 16)) >>> 0) / 4294967296;
}

function valueNoise(x, z) {
  const xi = Math.floor(x);
  const zi = Math.floor(z);
  const xf = x - xi;
  const zf = z - zi;
  const u = xf * xf * (3 - 2 * xf);
  const v = zf * zf * (3 - 2 * zf);

  const a = hash2(xi, zi);
  const b = hash2(xi + 1, zi);
  const c = hash2(xi, zi + 1);
  const d = hash2(xi + 1, zi + 1);

  return (a * (1 - u) + b * u) * (1 - v) + (c * (1 - u) + d * u) * v;
}

/** Bodenhöhe an einer Weltposition. */
export function heightAt(x, z) {
  const hills = valueNoise(x * 0.017, z * 0.017) - 0.5;
  const ridges = valueNoise(x * 0.042 + 31.7, z * 0.042 - 12.3) - 0.5;
  const bumps = valueNoise(x * 0.11, z * 0.11) - 0.5;

  let height = hills * 2 * hillHeight + ridges * 2.6 + bumps * 0.7;

  // Startlichtung glattziehen, damit der Spawn nie in einem Hang liegt.
  const distance = Math.hypot(x, z);
  height *= smoothstep(spawnFlatRadius * 0.5, spawnFlatRadius * 2.2, distance);

  return height;
}

/** Steigung (0 = eben) — für Objektplatzierung und später Laufkosten. */
export function slopeAt(x, z, epsilon = 0.8) {
  const dx = heightAt(x + epsilon, z) - heightAt(x - epsilon, z);
  const dz = heightAt(x, z + epsilon) - heightAt(x, z - epsilon);
  return Math.hypot(dx, dz) / (2 * epsilon);
}

/** Bodennormale — ab Phase 2 für die Ausrichtung von Objekten am Hang. */
export function normalAt(x, z, epsilon = 0.8) {
  const dx = heightAt(x + epsilon, z) - heightAt(x - epsilon, z);
  const dz = heightAt(x, z + epsilon) - heightAt(x, z - epsilon);
  const length = Math.hypot(dx, 2 * epsilon, dz);
  return { x: -dx / length, y: (2 * epsilon) / length, z: -dz / length };
}

export function isInsideWorld(x, z) {
  return Math.abs(x) <= WORLD_HALF && Math.abs(z) <= WORLD_HALF;
}
