import { heightAt } from '../Heightfield.js';

/**
 * Zeitweilige Mauern.
 *
 * Eine Barriere ist eine Reihe runder Kollider — dieselbe Form, die auch
 * Bäume und Felsen benutzen. Dadurch muss die Bewegung nichts Neues lernen:
 * sie fragt zusätzlich zu den festen Hindernissen die beweglichen ab.
 */
export class BarrierSystem {
  #barriers = new Map();
  #nextId = 1;

  constructor({ bus }) {
    this.bus = bus;
  }

  /**
   * @param origin   Mittelpunkt der Mauer
   * @param facing   Blickrichtung des Wirkers; die Mauer steht quer dazu
   * @param width    Gesamtbreite in Metern
   */
  spawn({ casterId, origin, facing = 0, width = 6, thickness = 0.6, duration = 8, segments = 5, style = 'physical' }) {
    const id = `barrier_${this.#nextId += 1}`;

    // Quer zur Blickrichtung: die Mauer stellt sich dem Gegner in den Weg.
    const across = { x: Math.cos(facing), z: -Math.sin(facing) };
    const radius = Math.max(thickness, width / segments / 2);
    const colliders = [];

    for (let i = 0; i < segments; i += 1) {
      const offset = (i - (segments - 1) / 2) * (width / segments);
      const x = origin.x + across.x * offset;
      const z = origin.z + across.z * offset;
      colliders.push({ x, z, radius, y: heightAt(x, z) });
    }

    const barrier = { id, casterId, colliders, remaining: duration, duration, facing, style, width };
    this.#barriers.set(id, barrier);
    this.bus.emit('barrier:spawned', barrier);
    return barrier;
  }

  all() {
    return [...this.#barriers.values()];
  }

  /** Von der Bewegung abgefragt — deshalb eine flache Liste. */
  colliders() {
    const all = [];
    for (const barrier of this.#barriers.values()) all.push(...barrier.colliders);
    return all;
  }

  update(dt) {
    for (const barrier of this.#barriers.values()) {
      barrier.remaining -= dt;
      if (barrier.remaining > 0) continue;

      this.#barriers.delete(barrier.id);
      this.bus.emit('barrier:removed', { id: barrier.id });
    }
  }
}
