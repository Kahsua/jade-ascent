import { heightAt } from '../Heightfield.js';
import { isHostile } from './factions.js';

/**
 * Bodeneffekte: stehende Felder und wandernde Wirbel.
 *
 * Ein Hazard ist eine Fläche, die für eine Weile bestehen bleibt und in
 * festen Abständen ihre Komponenten auf alles anwendet, was darin steht —
 * über denselben Executor wie jede andere Fähigkeit. Damit sind Nagelfeld,
 * Pfeiltornado und später Lavaflächen und Elementarspuren derselbe Mechanismus.
 *
 * Bewegung: entweder feststehend, in eine Richtung wandernd (speed/direction)
 * oder an eine Entity geheftet (follow).
 */
export class HazardSystem {
  #hazards = new Map();
  #nextId = 1;

  constructor({ entities, bus }) {
    this.entities = entities;
    this.bus = bus;
    this.onTick = null; // wird vom AbilityExecutor gesetzt
  }

  spawn({
    casterId, abilityId, position, radius = 3, duration = 4, interval = 0.5,
    components = [], speed = 0, direction = null, follow = null,
    style = 'physical', model = 'field', maxTargets = Infinity, firstTickImmediately = true,
  }) {
    const id = `hazard_${this.#nextId += 1}`;
    const hazard = {
      id, casterId, abilityId, radius, duration, remaining: duration, interval,
      components, speed, direction, follow, style, model, maxTargets,
      position: { x: position.x, y: heightAt(position.x, position.z), z: position.z },
      timer: firstTickImmediately ? 0 : interval,
      age: 0,
    };

    this.#hazards.set(id, hazard);
    this.bus.emit('hazard:spawned', hazard);
    return hazard;
  }

  all() {
    return [...this.#hazards.values()];
  }

  removeFor(entityId) {
    for (const hazard of [...this.#hazards.values()]) {
      if (hazard.follow === entityId) this.#remove(hazard);
    }
  }

  update(dt) {
    for (const hazard of this.#hazards.values()) {
      hazard.age += dt;
      hazard.remaining -= dt;

      if (hazard.follow) {
        const host = this.entities.get(hazard.follow);
        if (!host?.isAlive) {
          this.#remove(hazard);
          continue;
        }
        hazard.position.x = host.position.x;
        hazard.position.z = host.position.z;
      } else if (hazard.speed && hazard.direction) {
        hazard.position.x += hazard.direction.x * hazard.speed * dt;
        hazard.position.z += hazard.direction.z * hazard.speed * dt;
      }
      hazard.position.y = heightAt(hazard.position.x, hazard.position.z);

      hazard.timer -= dt;
      if (hazard.timer <= 0) {
        hazard.timer += hazard.interval;
        this.#tick(hazard);
      }

      if (hazard.remaining <= 0) this.#remove(hazard);
    }
  }

  #tick(hazard) {
    const caster = this.entities.get(hazard.casterId);
    if (!caster || !this.onTick) return;

    let hits = 0;
    for (const entity of this.entities.all()) {
      if (hits >= hazard.maxTargets) break;
      if (!entity.isAlive || !isHostile(caster, entity)) continue;

      const distance = Math.hypot(entity.position.x - hazard.position.x, entity.position.z - hazard.position.z);
      if (distance > hazard.radius) continue;

      hits += 1;
      this.onTick({ caster, target: entity, hazard, components: hazard.components });
    }
  }

  #remove(hazard) {
    this.#hazards.delete(hazard.id);
    this.bus.emit('hazard:removed', { id: hazard.id });
  }
}
