import { autoAttackFor } from '../data/weaponProfiles.js';
import { modelOfItem } from '../data/items.js';
import { abilities } from '../data/abilities.js';

/**
 * Autoattack pro Waffentyp: Bogen schießt einen Pfeil, Schwert schlägt zu,
 * Stab wirkt ein Magiegeschoss.
 *
 * Das System sucht sich die Fähigkeit aus der ausgerüsteten Waffe und schickt
 * sie durch denselben Executor wie jeden anderen Skill. Die Abklingzeit der
 * Angriffsfähigkeit IST die Angriffsgeschwindigkeit — dafür braucht es keinen
 * eigenen Timer.
 */
export class AutoAttackSystem {
  constructor({ entities, bus, targeting, ownerId = 'player' }) {
    this.entities = entities;
    this.bus = bus;
    this.targeting = targeting;
    this.ownerId = ownerId;
    this.enabled = false;

    bus.on('target:changed', ({ id }) => {
      if (!id) this.setEnabled(false);
    });
  }

  get owner() {
    return this.entities.get(this.ownerId);
  }

  currentAbility() {
    const owner = this.owner;
    // Item -> Modell -> Waffenprofil: der Bogen schießt, das Schwert schlägt.
    const profile = autoAttackFor(modelOfItem(owner?.state.equipment?.mainHand));
    return { id: profile.ability, ...abilities.get(profile.ability) };
  }

  setEnabled(enabled) {
    if (this.enabled === enabled) return;
    this.enabled = enabled;
    this.bus.emit('autoattack:changed', { enabled, ability: enabled ? this.currentAbility().name : null });
  }

  toggle() {
    if (!this.enabled && !this.targeting.target) {
      this.bus.emit('ui:notice', { text: 'Autoattack: kein Ziel', tone: 'warn' });
      return;
    }
    this.setEnabled(!this.enabled);
  }

  update() {
    if (!this.enabled) return;

    const owner = this.owner;
    const target = this.targeting.target;
    if (!owner?.isAlive || !target?.isAlive) return this.setEnabled(false);

    const ability = this.currentAbility();
    if (!owner.cooldowns.isReady(ability)) return;

    const distance = this.targeting.distanceToTarget();
    if (distance > ability.range) return; // still warten, bis man nah genug ist

    this.bus.emit('ability:requested', {
      abilityId: ability.id,
      casterId: owner.id,
      targetId: target.id,
      point: null,
    });
  }
}
