import { lerpAngle } from '../../core/math.js';
import { heightAt } from '../Heightfield.js';
import { isHostile } from './factions.js';

/**
 * Geschosse als reine Logik: Position, Richtung, Ziel, Restzeit.
 *
 * Ein Geschoss trägt seine eigenen onHit-Komponenten mit sich und gibt sie
 * beim Einschlag an denselben Executor zurück — ein Pfeil nimmt damit exakt
 * denselben Schadenspfad wie ein Schwerthieb.
 *
 * Varianten (alles Datenfelder der projectile-Komponente):
 *   homing    verfolgt sein Ziel; ohne Ziel fliegt es geradeaus und trifft,
 *             was ihm in die Quere kommt (Fächerschuss)
 *   bounces   springt nach dem Treffer zum nächsten Gegner weiter
 *   returns   kehrt danach zum Werfer zurück (Waffenwurf)
 */
export class ProjectileSystem {
  #projectiles = new Map();
  #nextId = 1;

  constructor({ entities, bus }) {
    this.entities = entities;
    this.bus = bus;
    this.onHit = null; // wird vom AbilityExecutor gesetzt
  }

  spawn({
    casterId, targetId, origin, direction, speed = 24, lifetime = 3, radius = 0.55,
    model = 'bolt', element = 'physical', abilityId, components = [],
    homing = true, bounces = 0, bounceRange = 8, falloff = 0.85, returns = false,
    destination = null,
  }) {
    const id = `projectile_${this.#nextId += 1}`;
    const projectile = {
      id, casterId, targetId, abilityId, model, element, speed, radius,
      position: { x: origin.x, y: origin.y, z: origin.z },
      direction: { x: direction.x, z: direction.z },
      remaining: lifetime,
      components,
      homing: homing && Boolean(targetId),
      bounces, bounceRange, falloff, returns, destination,
      factor: 1,
      struck: new Set(),
      phase: 'travel',
    };
    this.#projectiles.set(id, projectile);
    this.bus.emit('projectile:spawned', projectile);
    return projectile;
  }

  all() {
    return [...this.#projectiles.values()];
  }

  update(dt) {
    for (const projectile of this.#projectiles.values()) {
      const caster = this.entities.get(projectile.casterId);
      if (projectile.destination) projectile.homing = false;
      const chasing = projectile.phase === 'return'
        ? caster
        : (projectile.homing && projectile.targetId ? this.entities.get(projectile.targetId) : null);

      if (chasing && (projectile.phase === 'return' || chasing.isAlive)) {
        // Auf dem Rückweg dreht die Waffe entschlossener bei.
        this.#steer(projectile, chasing.position, dt, projectile.phase === 'return' ? 14 : 9);
      }

      projectile.position.x += projectile.direction.x * projectile.speed * dt;
      projectile.position.z += projectile.direction.z * projectile.speed * dt;
      projectile.position.y = heightAt(projectile.position.x, projectile.position.z) + 1.1;
      projectile.remaining -= dt;

      if (projectile.phase === 'return') {
        const distance = caster
          ? Math.hypot(caster.position.x - projectile.position.x, caster.position.z - projectile.position.z)
          : 0;
        if (!caster || distance <= 1) this.#remove(projectile, false);
        else if (projectile.remaining <= -3) this.#remove(projectile, false);
        continue;
      }

      // Ein Pfeil auf einen Bodenpunkt fliegt an Gegnern vorbei und
      // detoniert erst am Ziel.
      if (projectile.destination) {
        const distance = Math.hypot(
          projectile.destination.x - projectile.position.x,
          projectile.destination.z - projectile.position.z,
        );
        if (distance <= Math.max(0.8, projectile.speed * dt * 1.2) || projectile.remaining <= 0) {
          this.#detonate(projectile, caster);
        }
        continue;
      }

      const victim = this.#findVictim(projectile, caster);
      if (victim) {
        this.#resolve(projectile, victim, caster);
        continue;
      }

      if (projectile.remaining <= 0) this.#finish(projectile);
    }
  }

  /** Einschlag auf dem Boden statt an einem Gegner. */
  #detonate(projectile, caster) {
    if (caster && this.onHit) {
      this.onHit({
        caster, target: null, projectile,
        components: projectile.components,
        factor: projectile.factor,
        point: { x: projectile.destination.x, z: projectile.destination.z },
      });
    }
    this.bus.emit('vfx:impact', { position: { ...projectile.position }, model: projectile.model, element: projectile.element });
    this.#remove(projectile, true);
  }

  /**
   * Lenkung über den WINKEL, nicht über den Richtungsvektor.
   *
   * Vektoren zu mischen und danach zu normalisieren scheitert bei einer
   * Kehrtwende: (1,0) und (-1,0) heben sich unterwegs auf, das Ergebnis wird
   * wieder auf die alte Richtung normiert — ein zurückkehrendes Schwert flog
   * dadurch endlos geradeaus weiter.
   */
  #steer(projectile, target, dt, rate = 9) {
    const desired = Math.atan2(target.x - projectile.position.x, target.z - projectile.position.z);
    const current = Math.atan2(projectile.direction.x, projectile.direction.z);
    const angle = lerpAngle(current, desired, Math.min(1, dt * rate));

    projectile.direction.x = Math.sin(angle);
    projectile.direction.z = Math.cos(angle);
  }

  /** Verfolgtes Ziel oder — beim geraden Flug — der Erste, der im Weg steht. */
  #findVictim(projectile, caster) {
    const reach = projectile.radius + 0.45;

    if (projectile.homing && projectile.targetId) {
      const target = this.entities.get(projectile.targetId);
      if (!target?.isAlive) return null;
      const distance = Math.hypot(target.position.x - projectile.position.x, target.position.z - projectile.position.z);
      return distance <= reach ? target : null;
    }

    if (!caster) return null;
    for (const entity of this.entities.all()) {
      if (!entity.isAlive || projectile.struck.has(entity.id) || !isHostile(caster, entity)) continue;
      const distance = Math.hypot(entity.position.x - projectile.position.x, entity.position.z - projectile.position.z);
      if (distance <= reach) return entity;
    }
    return null;
  }

  #resolve(projectile, target, caster) {
    projectile.struck.add(target.id);

    if (caster && this.onHit) {
      this.onHit({
        caster, target, projectile,
        components: projectile.components,
        factor: projectile.factor,
      });
    }
    this.bus.emit('vfx:impact', { position: { ...projectile.position }, model: projectile.model, element: projectile.element });

    // Weiterspringen, solange Sprünge übrig sind und jemand in Reichweite ist.
    if (projectile.bounces > 0) {
      const next = this.#nextBounce(projectile, caster, target);
      if (next) {
        projectile.bounces -= 1;
        projectile.factor *= projectile.falloff;
        projectile.targetId = next.id;
        projectile.homing = true;
        projectile.remaining = Math.max(projectile.remaining, 1.5);
        this.bus.emit('projectile:bounced', { id: projectile.id, from: target.id, to: next.id });
        return;
      }
    }

    this.#finish(projectile);
  }

  #nextBounce(projectile, caster, from) {
    let best = null;
    let bestDistance = projectile.bounceRange;

    for (const entity of this.entities.all()) {
      if (!entity.isAlive || projectile.struck.has(entity.id)) continue;
      if (!caster || !isHostile(caster, entity)) continue;

      const distance = Math.hypot(entity.position.x - from.position.x, entity.position.z - from.position.z);
      if (distance < bestDistance) {
        best = entity;
        bestDistance = distance;
      }
    }
    return best;
  }

  /** Ende der Reise: entweder zurück zum Werfer oder weg. */
  #finish(projectile) {
    if (!projectile.returns) return this.#remove(projectile, true);

    projectile.phase = 'return';
    projectile.homing = true;
    projectile.remaining = 0;
    this.bus.emit('projectile:returning', { id: projectile.id });
  }

  #remove(projectile, hit) {
    this.#projectiles.delete(projectile.id);
    this.bus.emit('projectile:removed', { id: projectile.id, hit, casterId: projectile.casterId, abilityId: projectile.abilityId });
  }
}
