import { statusEffects } from '../data/statusEffects.js';

/**
 * Welches Element gerade auf der Waffe liegt.
 *
 * Die Dolch- und Stab-Fähigkeiten aus der Skill-Liste ändern Optik und
 * Wirkung je nach aktivem Bann. Statt das in jeder Fähigkeit auszuformulieren,
 * tragen ihre Komponenten `element: 'imbue'` — aufgelöst wird zur Laufzeit.
 */
export function imbueElementOf(entity) {
  const active = entity?.status?.imbue?.();
  return active?.element ?? null;
}

export function resolveElement(value, context) {
  if (value !== 'imbue') return value;
  return imbueElementOf(context.caster) ?? 'physical';
}

/** Zusatzeffekt, den ein Element bei Flächen- und Sonderfähigkeiten mitbringt. */
export function elementProc(element) {
  const table = {
    fire: { effect: 'burn', duration: 4, chance: 0.5 },
    ice: { effect: 'slow', duration: 3, magnitude: 0.4, chance: 0.6 },
    lightning: { effect: 'static', duration: 4, chance: 0.4 },
  };
  const entry = table[element];
  return entry && statusEffects.has(entry.effect) ? entry : null;
}
