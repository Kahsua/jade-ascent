/**
 * Verbindungen zwischen zwei Entities.
 *
 * Die Kette aus dem Fesselschuss bindet ein Ziel an eine Höchstentfernung:
 * läuft es weiter, wird es am Ende der Kette gehalten. Dieselbe Mechanik
 * trägt später den Schutzstrahl des Schilds und den Schwertzug.
 */
export class TetherSystem {
  #tethers = new Map();
  #nextId = 1;

  constructor({ entities, bus }) {
    this.entities = entities;
    this.bus = bus;
  }

  create({ sourceId, targetId, maxDistance = 8, duration = 6, abilityId = null, style = 'physical' }) {
    // Pro Paar nur eine Kette — ein zweiter Schuss erneuert sie.
    for (const tether of this.#tethers.values()) {
      if (tether.sourceId === sourceId && tether.targetId === targetId) {
        tether.remaining = duration;
        tether.maxDistance = maxDistance;
        return tether;
      }
    }

    const id = `tether_${this.#nextId += 1}`;
    const tether = { id, sourceId, targetId, maxDistance, duration, remaining: duration, abilityId, style };
    this.#tethers.set(id, tether);
    this.bus.emit('tether:created', tether);
    return tether;
  }

  all() {
    return [...this.#tethers.values()];
  }

  releaseFor(entityId) {
    for (const tether of [...this.#tethers.values()]) {
      if (tether.sourceId === entityId || tether.targetId === entityId) this.#remove(tether);
    }
  }

  update(dt) {
    for (const tether of this.#tethers.values()) {
      const source = this.entities.get(tether.sourceId);
      const target = this.entities.get(tether.targetId);

      if (!source?.isAlive || !target?.isAlive) {
        this.#remove(tether);
        continue;
      }

      const dx = target.position.x - source.position.x;
      const dz = target.position.z - source.position.z;
      const distance = Math.hypot(dx, dz);

      if (distance > tether.maxDistance) {
        // Am Ende der Kette festhalten, statt zu ziehen: das Ziel läuft
        // sichtbar gegen eine unsichtbare Grenze.
        const scale = tether.maxDistance / distance;
        target.state.position.x = source.position.x + dx * scale;
        target.state.position.z = source.position.z + dz * scale;
        target.state.velocity.x *= 0.2;
        target.state.velocity.z *= 0.2;
      }

      tether.remaining -= dt;
      if (tether.remaining <= 0) this.#remove(tether);
    }
  }

  #remove(tether) {
    this.#tethers.delete(tether.id);
    this.bus.emit('tether:removed', { id: tether.id });
  }
}
