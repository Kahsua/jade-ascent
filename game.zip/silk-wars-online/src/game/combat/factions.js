/** Wer darf wen treffen. Bewusst schlicht: gleiche Fraktion = kein Ziel. */
export function isHostile(caster, target) {
  if (!caster || !target || caster.id === target.id) return false;
  return caster.template.faction !== target.template.faction;
}

export function isFriendly(caster, target) {
  return Boolean(caster && target) && caster.template.faction === target.template.faction;
}

/**
 * Wem man helfen darf. Bewusst weiter gefasst als "gleiche Fraktion": der
 * Spieler kann auch die Dorfbewohner und Wachen schützen.
 */
const ALLIES = {
  player: ['player', 'neutral'],
  neutral: ['neutral', 'player'],
  hostile: ['hostile'],
};

export function isAlly(caster, target) {
  if (!caster || !target) return false;
  if (caster.id === target.id) return true;
  return (ALLIES[caster.template.faction] ?? []).includes(target.template.faction);
}
