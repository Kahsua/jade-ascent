import { CONFIG } from '../../core/Config.js';

/**
 * Ziel-Auswahl — reine Logik, kein three, kein DOM.
 *
 * Das 3D-Zielschema aus dem Auftrag hat zwei getrennte Hälften:
 *  1. ein ausgewähltes Ziel (Klick oder Tab), das bestehen bleibt, während
 *     man sich frei bewegt — wie in GW2 oder Silkroad,
 *  2. davon unabhängig das Boden-Zielen für Flächenfähigkeiten.
 * Diese Klasse hält Hälfte 1 und den Modus für Hälfte 2. Wo die Maus
 * hinzeigt, weiß nur die Renderschicht; sie meldet den Weltpunkt herein.
 */
export class TargetingSystem {
  constructor({ entities, bus, ownerId = 'player', maxRange = CONFIG.targeting.maxSelectRange }) {
    this.entities = entities;
    this.bus = bus;
    this.ownerId = ownerId;
    this.maxRange = maxRange;

    this.targetId = null;
    /** Aktive Boden-Zielsuche: { abilityId, range, radius } oder null. */
    this.pending = null;

    bus.on('entity:died', ({ id }) => {
      if (id === this.targetId) this.#emit();
    });
    bus.on('entity:removed', (entity) => {
      if (entity.id === this.targetId) this.clear();
    });
  }

  get target() {
    return this.targetId ? this.entities.get(this.targetId) : null;
  }

  get owner() {
    return this.entities.get(this.ownerId);
  }

  select(id) {
    if (!id || id === this.ownerId) return this.clear();
    const entity = this.entities.get(id);
    if (!entity) return this.clear();
    if (this.targetId === id) return entity;

    this.targetId = id;
    this.#emit();
    return entity;
  }

  clear() {
    if (this.targetId === null) return null;
    this.targetId = null;
    this.#emit();
    return null;
  }

  /** Tab: reihum durch die erreichbaren Ziele, nach Entfernung sortiert. */
  cycle() {
    const owner = this.owner;
    if (!owner) return null;

    const candidates = this.entities.all()
      .filter((entity) => entity.id !== this.ownerId && entity.isAlive)
      .map((entity) => ({
        entity,
        distance: Math.hypot(entity.position.x - owner.position.x, entity.position.z - owner.position.z),
      }))
      .filter((candidate) => candidate.distance <= this.maxRange)
      .sort((a, b) => a.distance - b.distance);

    if (candidates.length === 0) return this.clear();

    const index = candidates.findIndex((candidate) => candidate.entity.id === this.targetId);
    const next = candidates[(index + 1) % candidates.length];
    return this.select(next.entity.id);
  }

  /** Entfernung Besitzer -> Ziel, oder null. */
  distanceToTarget() {
    const owner = this.owner;
    const target = this.target;
    if (!owner || !target) return null;
    return Math.hypot(target.position.x - owner.position.x, target.position.z - owner.position.z);
  }

  // --- Boden-Zielen --------------------------------------------------------

  beginGroundTargeting({ abilityId, range, radius }) {
    this.pending = { abilityId, range, radius };
    this.bus.emit('targeting:ground', { active: true, ...this.pending });
    return this.pending;
  }

  cancelGroundTargeting() {
    if (!this.pending) return false;
    this.pending = null;
    this.bus.emit('targeting:ground', { active: false });
    return true;
  }

  /**
   * Rohen Mauspunkt auf die erlaubte Reichweite stutzen. Der Indikator darf
   * die Maximalreichweite nie überschreiten — er rutscht an ihren Rand.
   */
  clampToRange(point) {
    const owner = this.owner;
    if (!owner || !this.pending) return point;

    const dx = point.x - owner.position.x;
    const dz = point.z - owner.position.z;
    const distance = Math.hypot(dx, dz);
    if (distance <= this.pending.range || distance === 0) return { x: point.x, z: point.z, clamped: false };

    const scale = this.pending.range / distance;
    return { x: owner.position.x + dx * scale, z: owner.position.z + dz * scale, clamped: true };
  }

  /** Klick bei aktivem Boden-Zielen: Fähigkeit anfordern. */
  confirmGroundTargeting(point) {
    if (!this.pending) return null;
    const request = {
      abilityId: this.pending.abilityId,
      casterId: this.ownerId,
      targetId: null,
      point: { x: point.x, z: point.z },
    };
    this.cancelGroundTargeting();
    this.bus.emit('ability:requested', request);
    return request;
  }

  /** Ziel verlieren, wenn es zu weit weg ist. */
  update() {
    if (!this.targetId) return;
    const distance = this.distanceToTarget();
    if (distance !== null && distance > CONFIG.targeting.dropRange) this.clear();
  }

  #emit() {
    const target = this.target;
    this.bus.emit('target:changed', {
      id: this.targetId,
      entity: target,
      name: target?.state.name ?? null,
      level: target?.state.level ?? null,
      faction: target?.template.faction ?? null,
    });
  }
}
