import { createSave } from './SaveGame.js';

/**
 * Speichert von selbst: in festen Abständen, sobald sich etwas Wichtiges
 * geändert hat, und auf Zuruf.
 *
 * Es speichert bewusst NICHT bei jedem Ereignis, sondern merkt sich nur, dass
 * etwas offen ist — sonst würde ein Kampf Dutzende Schreibvorgänge auslösen.
 */
const DIRTY_EVENTS = [
  'entity:levelup',
  'entity:equipment',
  'entity:inventory',
  'progression:changed',
  'actionbar:changed',
  'entity:experience',
];

export class SaveSystem {
  constructor({ entities, bus, storage, playerId = 'player', slot = 'player', interval = 25, delay = 3 }) {
    this.entities = entities;
    this.bus = bus;
    this.storage = storage;
    this.playerId = playerId;
    this.slot = slot;
    this.interval = interval;
    this.delay = delay;

    this.dirty = false;
    this.timer = 0;
    this.saving = false;
    this.lastSavedAt = null;

    for (const event of DIRTY_EVENTS) bus.on(event, () => this.markDirty());
    bus.on('entity:died', ({ id }) => { if (id === playerId) this.markDirty(); });
  }

  get player() {
    return this.entities.get(this.playerId);
  }

  markDirty() {
    this.dirty = true;
    this.timer = Math.min(this.timer, this.delay);
  }

  update(dt) {
    this.timer -= dt;
    if (this.timer > 0) return;

    this.timer = this.interval;
    if (this.dirty) this.saveNow('automatisch');
  }

  async saveNow(reason = 'manuell') {
    const player = this.player;
    if (!player || this.saving) return false;

    this.saving = true;
    this.dirty = false;
    this.bus.emit('save:started', { reason });

    try {
      await this.storage.save(this.slot, createSave(player));
      this.lastSavedAt = new Date();
      this.bus.emit('save:done', { reason, at: this.lastSavedAt, storage: this.storage.name });
      return true;
    } catch (error) {
      console.error('[Speicher] Schreiben fehlgeschlagen:', error);
      this.dirty = true; // beim nächsten Durchlauf erneut versuchen
      this.bus.emit('save:failed', { reason, error: String(error) });
      return false;
    } finally {
      this.saving = false;
    }
  }

  async load() {
    try {
      return await this.storage.load(this.slot);
    } catch (error) {
      console.error('[Speicher] Laden fehlgeschlagen:', error);
      this.bus.emit('save:failed', { reason: 'laden', error: String(error) });
      return null;
    }
  }

  async reset() {
    await this.storage.remove(this.slot);
    this.dirty = false;
    this.bus.emit('save:removed', {});
  }
}
