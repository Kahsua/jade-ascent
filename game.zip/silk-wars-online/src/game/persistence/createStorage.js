import { FIREBASE_CONFIG } from '../../config/firebase.js';
import { FirebaseAdapter } from './adapters/FirebaseAdapter.js';
import { LocalStorageAdapter } from './adapters/LocalStorageAdapter.js';
import { MemoryAdapter } from './adapters/MemoryAdapter.js';

/**
 * Wählt die Ablage. Alle drei erfüllen dieselbe Schnittstelle:
 *   load(slot) -> Dokument | null
 *   save(slot, dokument)
 *   remove(slot)
 *
 * Deshalb kennt weder das Spiel noch das SaveSystem den Unterschied zwischen
 * Browser-Speicher und Firestore.
 */
export function createStorage() {
  if (FIREBASE_CONFIG?.apiKey) return new FirebaseAdapter(FIREBASE_CONFIG);
  if (LocalStorageAdapter.isAvailable()) return new LocalStorageAdapter();

  console.warn('[Speicher] Kein dauerhafter Speicher verfügbar — Fortschritt geht beim Schließen verloren.');
  return new MemoryAdapter();
}
