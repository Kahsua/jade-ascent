import { PlayerState } from '../PlayerState.js';

/**
 * Das Speicherformat — die Ernte aus neun Phasen Vorarbeit.
 *
 * Weil der gesamte Spielerzustand seit Phase 1 an EINER Stelle liegt und
 * toJSON() vollständig ist, besteht das Speichern aus einem Aufruf. Es gab
 * hier nichts umzubauen.
 */
export const SAVE_VERSION = 1;

export function createSave(playerEntity, extra = {}) {
  return {
    version: SAVE_VERSION,
    savedAt: new Date().toISOString(),
    player: playerEntity.state.toJSON(),
    resources: playerEntity.resources.toJSON(),
    ...extra,
  };
}

/**
 * Ältere Stände auf das aktuelle Format heben. Solange es nur eine Version
 * gibt, ist das ein Durchreicher — der Haken existiert, damit ein späteres
 * Feld keinen Speicherstand unbrauchbar macht.
 */
export function migrate(save) {
  if (!save || typeof save !== 'object') return null;
  let migrated = { ...save };

  if (!migrated.version) migrated.version = 1;
  // if (migrated.version === 1) { ...; migrated.version = 2; }

  return migrated.version === SAVE_VERSION ? migrated : null;
}

/** Aus einem Speicherstand einen Spielerzustand bauen. */
export function stateFromSave(save, fallback = {}) {
  const migrated = migrate(save);
  if (!migrated?.player) return new PlayerState(fallback);
  return PlayerState.fromJSON(migrated.player);
}

/** Leben und Mana nach dem Erzeugen der Entity wiederherstellen. */
export function restoreResources(playerEntity, save) {
  const migrated = migrate(save);
  if (!migrated?.resources) return false;
  playerEntity.resources.restore(migrated.resources);
  return true;
}
