/**
 * Speicherstand im Browser. Kein Konto nötig, funktioniert offline und ist
 * die Standardablage, solange keine Firebase-Konfiguration hinterlegt ist.
 */
export class LocalStorageAdapter {
  constructor({ prefix = 'jade-ascent' } = {}) {
    this.prefix = prefix;
    this.name = 'lokal';
    this.persistent = true;
  }

  static isAvailable() {
    try {
      const probe = '__probe__';
      window.localStorage.setItem(probe, '1');
      window.localStorage.removeItem(probe);
      return true;
    } catch {
      return false;
    }
  }

  #key(slot) {
    return `${this.prefix}:${slot}`;
  }

  async load(slot) {
    const raw = window.localStorage.getItem(this.#key(slot));
    if (!raw) return null;
    try {
      return JSON.parse(raw);
    } catch (error) {
      console.error('[Speicher] Beschädigter Speicherstand:', error);
      return null;
    }
  }

  async save(slot, document) {
    window.localStorage.setItem(this.#key(slot), JSON.stringify(document));
  }

  async remove(slot) {
    window.localStorage.removeItem(this.#key(slot));
  }
}
