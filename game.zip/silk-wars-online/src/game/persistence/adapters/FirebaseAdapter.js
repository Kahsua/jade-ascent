/**
 * Firebase Authentication + Firestore.
 *
 * Wird erst geladen, wenn eine Konfiguration hinterlegt ist — die
 * Firebase-Module kommen per dynamischem Import, damit ein Spiel ohne Konto
 * gar nichts davon herunterlädt.
 *
 * Ablage: players/{uid}/saves/{slot}
 *
 * Passende Firestore-Regeln (jeder liest und schreibt nur sein eigenes Feld):
 *   match /players/{uid}/saves/{slot} {
 *     allow read, write: if request.auth != null && request.auth.uid == uid;
 *   }
 */
const SDK = 'https://www.gstatic.com/firebasejs/10.12.2';

export class FirebaseAdapter {
  #db = null;
  #firestore = null;

  constructor(config, { anonymous = true } = {}) {
    this.config = config;
    this.anonymous = anonymous;
    this.name = 'firebase';
    this.persistent = true;
    this.uid = null;
  }

  async connect() {
    if (this.#db) return this;

    const [app, auth, firestore] = await Promise.all([
      import(`${SDK}/firebase-app.js`),
      import(`${SDK}/firebase-auth.js`),
      import(`${SDK}/firebase-firestore.js`),
    ]);

    const instance = app.initializeApp(this.config);
    const authentication = auth.getAuth(instance);

    const user = authentication.currentUser
      ?? (this.anonymous ? (await auth.signInAnonymously(authentication)).user : null);
    if (!user) throw new Error('Firebase: keine Anmeldung');

    this.uid = user.uid;
    this.#firestore = firestore;
    this.#db = firestore.getFirestore(instance);
    return this;
  }

  #ref(slot) {
    return this.#firestore.doc(this.#db, 'players', this.uid, 'saves', slot);
  }

  async load(slot) {
    await this.connect();
    const snapshot = await this.#firestore.getDoc(this.#ref(slot));
    return snapshot.exists() ? snapshot.data() : null;
  }

  async save(slot, document) {
    await this.connect();
    await this.#firestore.setDoc(this.#ref(slot), document);
  }

  async remove(slot) {
    await this.connect();
    await this.#firestore.deleteDoc(this.#ref(slot));
  }
}
