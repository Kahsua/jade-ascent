/**
 * Speicher im Arbeitsspeicher — Rückfallebene, wenn der Browser nichts
 * ablegen darf (privater Modus), und Prüfstand für Tests.
 */
export class MemoryAdapter {
  #slots = new Map();

  constructor() {
    this.name = 'memory';
    this.persistent = false;
  }

  async load(slot) {
    return this.#slots.get(slot) ?? null;
  }

  async save(slot, document) {
    this.#slots.set(slot, JSON.parse(JSON.stringify(document)));
  }

  async remove(slot) {
    this.#slots.delete(slot);
  }
}
