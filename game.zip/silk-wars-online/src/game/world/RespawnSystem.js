/**
 * Gefallene kommen zurück: Monster nach der Zeit aus ihrem Template, der
 * Spieler an seinem Ausgangspunkt.
 *
 * Damit fallen die Testtasten aus den Phasen 3 bis 6 weg — die Welt setzt
 * sich von selbst zurück.
 */
export class RespawnSystem {
  #pending = [];

  constructor({ entities, bus, playerDelay = 6, spawnProtection = 2.5 }) {
    this.entities = entities;
    this.bus = bus;
    this.playerDelay = playerDelay;
    this.spawnProtection = spawnProtection;

    bus.on('entity:died', ({ id }) => this.#schedule(id));
  }

  /** Läuft für diese Entity schon ein Wiedereinstieg? */
  isPending(id) {
    return this.#pending.some((entry) => entry.id === id);
  }

  #schedule(id) {
    const entity = this.entities.get(id);
    if (!entity) return;

    const isPlayer = entity.template.faction === 'player';
    const delay = isPlayer ? this.playerDelay : (entity.template.respawn ?? 25);
    if (delay <= 0) return;

    this.#pending.push({ id, remaining: delay, isPlayer });
    this.bus.emit('entity:defeated', { id, delay, isPlayer, name: entity.state.name });
  }

  update(dt) {
    // Sicherheitsnetz: wer tot ist und aus irgendeinem Grund keinen
    // Wiedereinstieg eingeplant hat, bekommt ihn hier. Ein Ereignis, das
    // verlorengeht, darf niemanden dauerhaft liegen lassen.
    for (const entity of this.entities.all()) {
      if (entity.isAlive || this.isPending(entity.id)) continue;
      console.warn(`[Respawn] ${entity.id} lag ohne geplanten Wiedereinstieg — wird nachgeholt.`);
      this.#schedule(entity.id);
    }

    for (let i = this.#pending.length - 1; i >= 0; i -= 1) {
      const entry = this.#pending[i];
      entry.remaining -= dt;
      if (entry.remaining > 0) continue;

      this.#pending.splice(i, 1);
      const entity = this.entities.get(entry.id);
      if (!entity) continue;

      const spawn = entity.state.spawnPoint;
      entity.state.position.x = spawn.x;
      entity.state.position.y = spawn.y;
      entity.state.position.z = spawn.z;
      entity.state.velocity.x = 0;
      entity.state.velocity.z = 0;
      entity.state.dash = null;
      entity.state.speed = 0;
      entity.status.clear();
      entity.resources.revive();
      entity.cooldowns.update(0);

      if (entity.ai) {
        entity.ai.targetId = null;
        entity.ai.state = 'idle';
        entity.ai.forcedUntil = 0;
      }

      // Kurze Unverwundbarkeit nach dem Wiedereinstieg: sonst steht man
      // sofort wieder in einer Flächenwirkung, die noch läuft.
      if (this.spawnProtection > 0) {
        entity.status.apply('invulnerable', { duration: this.spawnProtection, source: 'respawn' });
      }

      this.bus.emit('entity:revived', { id: entity.id, atSpawn: true });
    }
  }
}
