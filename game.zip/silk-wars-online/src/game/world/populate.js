import { mulberry32 } from '../../core/math.js';
import { regions } from '../data/regions.js';
import { heightAt, slopeAt } from '../Heightfield.js';

/**
 * Setzt die Welt aus den Gebietsdaten zusammen.
 *
 * Deterministisch über einen Seed: dieselbe Welt bei jedem Start, damit
 * Spawn- und Rückkehrpunkte über Sitzungen hinweg gleich bleiben.
 */
export function populateWorld(entities, { seed = 20260913 } = {}) {
  const random = mulberry32(seed);
  const created = [];

  for (const regionId of regions.ids()) {
    const region = regions.get(regionId);

    for (const group of region.spawns) {
      for (let i = 0; i < group.count; i += 1) {
        const spot = (group.near && i === 0)
          ? { x: region.center.x + group.near.x, z: region.center.z + group.near.z }
          : findSpot(region, group, random);

        if (!spot) continue;

        const entity = entities.spawn(group.template, {
          position: { x: spot.x, y: heightAt(spot.x, spot.z), z: spot.z },
          facing: random() * Math.PI * 2,
        });
        entity.state.region = regionId;
        created.push(entity);
      }
    }
  }

  return created;
}

function findSpot(region, group, random) {
  const minDistance = group.minDistance ?? 0;

  for (let attempt = 0; attempt < 30; attempt += 1) {
    const angle = random() * Math.PI * 2;
    const distance = minDistance + random() * Math.max(0.1, region.radius - minDistance);
    const x = region.center.x + Math.cos(angle) * distance;
    const z = region.center.z + Math.sin(angle) * distance;

    if (slopeAt(x, z) > 0.6) continue;   // keine Steilhänge
    return { x, z };
  }
  return null;
}
