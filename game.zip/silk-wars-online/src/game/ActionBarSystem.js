import { abilities } from './data/abilities.js';

/**
 * Zwei Action-Bars, jeder Slot nur eine Ability-ID — ohne feste Kategorie.
 * Skill, Buff, Imbue und Ausweichen sind gleichberechtigt zuweisbar.
 *
 * Das System entscheidet nur, WAS die Eingabe noch braucht (ein Ziel, einen
 * Bodenpunkt oder nichts), und meldet dann "ability:requested". Was daraus
 * wird, ist Sache des AbilityExecutors in Phase 5 — der hängt sich an
 * dasselbe Ereignis, ohne dass hier etwas geändert werden muss.
 */
export class ActionBarSystem {
  constructor({ state, bus, targeting }) {
    this.state = state;
    this.bus = bus;
    this.targeting = targeting;
  }

  get bars() {
    return this.state.actionBars;
  }

  assign(bar, index, abilityId) {
    if (abilityId && !abilities.has(abilityId)) throw new Error(`Unbekannte Fähigkeit: ${abilityId}`);
    this.bars[bar][index] = abilityId;
    this.bus.emit('actionbar:changed', { bar, index, abilityId });
  }

  definition(bar, index) {
    const id = this.bars[bar]?.[index];
    return id ? { id, ...abilities.get(id) } : null;
  }

  /** Tastendruck auf einen Slot. */
  activate(bar, index) {
    const entry = this.definition(bar, index);
    if (!entry) return null;

    if (entry.targeting === 'ground') {
      this.targeting.beginGroundTargeting({ abilityId: entry.id, range: entry.range, radius: entry.radius });
      this.bus.emit('ui:notice', { text: `${entry.name}: Bodenpunkt wählen (Rechtsklick oder Esc bricht ab)`, tone: 'hint' });
      return entry;
    }

    if (entry.targeting === 'target') {
      const target = this.targeting.target;
      if (!target || !target.isAlive) {
        this.bus.emit('ui:notice', { text: `${entry.name}: kein gültiges Ziel`, tone: 'warn' });
        return null;
      }
      const distance = this.targeting.distanceToTarget();
      if (entry.range && distance > entry.range) {
        this.bus.emit('ui:notice', { text: `${entry.name}: außer Reichweite (${distance.toFixed(1)} m von ${entry.range} m)`, tone: 'warn' });
        return null;
      }
      this.bus.emit('ability:requested', { abilityId: entry.id, casterId: this.state.id, targetId: target.id, point: null });
      return entry;
    }

    this.bus.emit('ability:requested', { abilityId: entry.id, casterId: this.state.id, targetId: null, point: null });
    return entry;
  }
}
