import { CONFIG } from '../../core/Config.js';
import { heightAt } from '../Heightfield.js';

/**
 * Serialisierbarer Kernzustand jeder Entity — Spieler wie Monster.
 *
 * Alles, was gespeichert werden muss, steht hier. Laufzeitwerte (Tempo,
 * Geschwindigkeit) leben zwar auf demselben Objekt, gehen aber bewusst nicht
 * in toJSON().
 */
export class EntityState {
  constructor(init = {}) {
    const base = CONFIG.progression.baseAttribute;

    this.id = init.id ?? `entity_${Math.random().toString(36).slice(2, 9)}`;
    this.name = init.name ?? 'Unbekannt';
    this.level = init.level ?? 1;

    this.attributes = {
      strength: base,
      dexterity: base,
      intelligence: base,
      vitality: base,
      ...(init.attributes ?? {}),
    };

    const position = init.position ?? { x: 0, z: 0 };
    this.position = {
      x: position.x ?? 0,
      y: position.y ?? heightAt(position.x ?? 0, position.z ?? 0),
      z: position.z ?? 0,
    };
    this.facing = init.facing ?? 0;
    this.moveSpeed = init.moveSpeed ?? CONFIG.player.walkSpeed;

    // Rückkehrpunkt für die KI (Leash) und für Wiedereinstieg nach dem Tod.
    this.spawnPoint = init.spawnPoint
      ? { ...init.spawnPoint }
      : { x: this.position.x, y: this.position.y, z: this.position.z };

    // Laufzeit, nicht Teil des Speicherstands.
    this.velocity = { x: 0, z: 0 };
    this.speed = 0;
  }

  toJSON() {
    return {
      id: this.id,
      name: this.name,
      level: this.level,
      attributes: { ...this.attributes },
      position: { x: this.position.x, y: this.position.y, z: this.position.z },
      spawnPoint: { ...this.spawnPoint },
      facing: this.facing,
    };
  }
}
