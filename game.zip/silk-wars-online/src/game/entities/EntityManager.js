import { AiController } from '../ai/AiController.js';
import { Entity } from './Entity.js';
import { EntityState } from './EntityState.js';
import { entityTemplates } from '../data/entityTemplates.js';

/**
 * Erzeugt, verwaltet und taktet alle Entities.
 *
 * Spawnen meldet "entity:spawned" auf den Bus — die Renderschicht baut daraus
 * selbstständig ein Modell. Deshalb muss ab Phase 7 kein Monster-Code wissen,
 * dass es überhaupt eine Anzeige gibt.
 */
export class EntityManager {
  #entities = new Map();
  #counters = new Map();

  constructor({ bus }) {
    this.bus = bus;
  }

  spawn(templateId, overrides = {}) {
    const template = entityTemplates.get(templateId);
    const count = (this.#counters.get(templateId) ?? 0) + 1;
    this.#counters.set(templateId, count);

    const state = overrides.state ?? new EntityState({
      id: overrides.id ?? (templateId === 'player' ? 'player' : `${templateId}#${count}`),
      name: overrides.name ?? template.name,
      level: overrides.level ?? template.level ?? 1,
      attributes: { ...(template.attributes ?? {}), ...(overrides.attributes ?? {}) },
      position: overrides.position,
      facing: overrides.facing,
      moveSpeed: overrides.moveSpeed ?? template.ai?.moveSpeed,
    });

    if (template.equipment && !state.equipment) state.equipment = { ...template.equipment };

    const entity = new Entity({ state, template: { id: templateId, ...template }, bus: this.bus });

    // Verhalten steht im Template — wer eines hat, bekommt eine KI-Komponente.
    if (template.ai) {
      entity.ai = new AiController({ entity, entities: this, bus: this.bus, profile: template.ai });
    }

    this.#entities.set(entity.id, entity);
    this.bus.emit('entity:spawned', entity);
    return entity;
  }

  remove(id) {
    const entity = this.#entities.get(id);
    if (!entity) return;
    this.#entities.delete(id);
    this.bus.emit('entity:removed', entity);
  }

  get(id) {
    return this.#entities.get(id) ?? null;
  }

  all() {
    return [...this.#entities.values()];
  }

  /** Nächste Entity zu einem Punkt — Grundlage für Ziel-Auswahl in Phase 4. */
  nearest(position, { maxDistance = Infinity, exclude = null, filter = null } = {}) {
    let best = null;
    let bestDistance = maxDistance;

    for (const entity of this.#entities.values()) {
      if (entity.id === exclude) continue;
      if (filter && !filter(entity)) continue;
      const distance = Math.hypot(entity.position.x - position.x, entity.position.z - position.z);
      if (distance < bestDistance) {
        best = entity;
        bestDistance = distance;
      }
    }
    return best ? { entity: best, distance: bestDistance } : null;
  }

  update(dt) {
    for (const entity of this.#entities.values()) entity.update(dt);
  }
}
