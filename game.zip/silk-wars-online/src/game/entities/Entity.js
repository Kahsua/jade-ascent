import { CooldownController } from '../abilities/CooldownController.js';
import { ResourcePool } from '../components/ResourcePool.js';
import { StatusEffectController } from '../components/StatusEffectController.js';
import { SkillProgression } from '../progression/SkillProgression.js';
import { Equipment } from '../components/Equipment.js';
import { mitigate } from '../combat/damage.js';
import { deriveStats } from '../stats/deriveStats.js';

/**
 * Entity = Zustand + Komponenten. Keine Gott-Klasse.
 *
 * Heute: ResourcePool, CooldownController und StatusEffectController,
 * ab Phase 7 der AiController — jeweils als eigenes Feld, nicht als weitere
 * Methoden hier drin.
 *
 * Die Entity ist die einzige Stelle, die Komponenten-Änderungen auf den
 * EventBus übersetzt. Die Komponenten selbst kennen den Bus nicht.
 */
export class Entity {
  constructor({ state, template, bus }) {
    this.id = state.id;
    this.state = state;
    this.template = template;
    this.bus = bus;

    /** Freie Zusatzwerte (Skripte, Weltbuffs) — Ausrüstung hat ihre eigene Komponente. */
    this.bonuses = {};

    this.equipment = state.equipment
      ? new Equipment({
        state,
        onChange: ({ slot, itemId, inventory }) => {
          if (!inventory) {
            this.recalculate();
            this.bus?.emit('entity:equipment', { id: this.id, slot, itemId });
          } else {
            this.bus?.emit('entity:inventory', { id: this.id, itemId });
          }
        },
      })
      : null;

    // Wer Masteries im Zustand hat, bekommt die Progressions-Komponente.
    this.skills = state.masteries
      ? new SkillProgression({ state, onChange: () => this.recalculate() })
      : null;

    this.stats = deriveStats(state.attributes, state.level, this.#totalBonuses());

    this.cooldowns = new CooldownController();

    this.status = new StatusEffectController({
      onChange: (controller) => this.bus?.emit('entity:status', { id: this.id, effects: controller.list() }),
      onTick: (effect, amount, school) => {
        // Auch Schaden über Zeit wird mitigiert — sonst wäre Rüstung gegen
        // Gift wertlos.
        const defense = school === 'magic' ? this.stats.magicResist : this.stats.armor;
        this.applyDamage(mitigate(amount, defense), { source: effect.source, type: school, overTime: true });
      },
      onImpulse: (impulse, source) => this.bus?.emit('entity:impulse', { id: this.id, impulse, source }),
    });

    this.resources = new ResourcePool({
      ...this.stats,
      onChange: (pool) => this.bus?.emit('entity:resources', {
        id: this.id,
        health: pool.health,
        maxHealth: pool.maxHealth,
        mana: pool.mana,
        maxMana: pool.maxMana,
        healthRatio: pool.healthRatio,
        manaRatio: pool.manaRatio,
      }),
    });
  }

  get position() { return this.state.position; }
  get facing() { return this.state.facing; }
  get isAlive() { return this.resources.isAlive; }

  /** Ausrüstung, Masteries und Synergien addieren sich zu einem Bonus-Satz. */
  #totalBonuses() {
    const totals = { ...this.bonuses };
    for (const source of [this.equipment?.bonuses(), this.skills?.statBonuses()]) {
      for (const [stat, value] of Object.entries(source ?? {})) {
        totals[stat] = (totals[stat] ?? 0) + value;
      }
    }
    return totals;
  }

  /** Nach Attribut-, Level-, Mastery- oder Ausrüstungsänderung aufrufen. */
  recalculate() {
    this.stats = deriveStats(this.state.attributes, this.state.level, this.#totalBonuses());
    this.resources.applyStats(this.stats);
    this.bus?.emit('entity:stats', { id: this.id, stats: this.stats });
    return this.stats;
  }

  update(dt) {
    this.cooldowns.update(dt);
    if (!this.isAlive) return;
    this.status.update(dt);
    this.resources.update(dt);
  }

  /**
   * Fertig berechneter Schaden. Die Formel selbst steht in combat/damage.js;
   * hier wird nur noch Unverwundbarkeit geprüft und gemeldet.
   */
  applyDamage(amount, { source = null, type = 'physical', critical = false, overTime = false, abilityId = null } = {}) {
    if (!this.isAlive) return 0;

    if (this.gm?.god || this.status.isInvulnerable) {
      this.bus?.emit('entity:immune', { id: this.id, source, amount });
      return 0;
    }

    const applied = this.resources.damage(amount);
    this.bus?.emit('entity:damaged', { id: this.id, amount: applied, source, type, critical, overTime, abilityId });

    if (!this.resources.isAlive) {
      this.bus?.emit('entity:died', { id: this.id, source });
    }
    return applied;
  }

  applyHealing(amount, { source = null } = {}) {
    const applied = this.resources.heal(amount);
    if (applied > 0) this.bus?.emit('entity:healed', { id: this.id, amount: applied, source });
    return applied;
  }

  toJSON() {
    return { ...this.state.toJSON(), resources: this.resources.toJSON(), status: this.status.toJSON() };
  }
}
