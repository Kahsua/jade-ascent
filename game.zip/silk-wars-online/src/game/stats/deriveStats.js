import { CONFIG } from '../../core/Config.js';

/**
 * Primärattribute -> Kampfwerte. Reine Funktion, keine Seiteneffekte.
 *
 * Die Koeffizienten stehen in CONFIG.stats, nicht hier — Balancing ist Daten.
 * "bonuses" sind additive Zusatzwerte; ab Phase 9 füllt die Ausrüstung sie,
 * ab Phase 6 auch Buffs. Die Signatur muss sich dafür nicht ändern.
 */
export function deriveStats(attributes, level = 1, bonuses = {}) {
  const c = CONFIG.stats;
  const { strength = 0, dexterity = 0, intelligence = 0, vitality = 0 } = attributes;

  const stats = {
    maxHealth: c.health.base + vitality * c.health.perVitality + (level - 1) * c.health.perLevel,
    maxMana: c.mana.base + intelligence * c.mana.perIntelligence + (level - 1) * c.mana.perLevel,
    healthRegen: c.healthRegen.base + vitality * c.healthRegen.perVitality,
    manaRegen: c.manaRegen.base + intelligence * c.manaRegen.perIntelligence,
    armor: c.armor.base + vitality * c.armor.perVitality,
    magicResist: c.magicResist.base + vitality * c.magicResist.perVitality,
    physicalPower: c.physicalPower.base + strength * c.physicalPower.perStrength,
    magicPower: c.magicPower.base + intelligence * c.magicPower.perIntelligence,
    critChance: c.critChance.base + dexterity * c.critChance.perDexterity,
    critDamage: c.critDamage.base + dexterity * c.critDamage.perDexterity,
  };

  for (const [key, value] of Object.entries(bonuses)) {
    if (key in stats) stats[key] += value;
  }

  stats.critChance = Math.min(stats.critChance, c.critChance.max);
  return stats;
}

/** Erfahrung bis zum nächsten Level. Das Levelsystem selbst kommt in Phase 8. */
export function experienceForLevel(level) {
  const { base, exponent } = CONFIG.progression.experienceCurve;
  return Math.round(base * level ** exponent);
}
