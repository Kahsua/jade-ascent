import { CONFIG } from '../core/Config.js';
import { masteries } from './data/masteries.js';
import { items } from './data/items.js';

/**
 * Testmodus: alles freigeschaltet, alles im Gepäck.
 *
 * Bewusst ein eigener Speicherplatz (siehe main.js) — der normale Spielstand
 * bleibt unberührt, egal was hier ausprobiert wird.
 */
export function enableGameMaster(player, { bus, level = 20, rank = 5 } = {}) {
  const state = player.state;
  state.level = Math.min(level, CONFIG.progression.maxLevel);
  state.name = 'Gamemaster';

  // Attribute auf ein Niveau, auf dem sich Fähigkeiten spürbar anfühlen.
  for (const key of Object.keys(state.attributes)) state.attributes[key] = 40;
  state.unspentAttributePoints = 20;

  // Alle Masteries auf Maximum, danach jeden Skill auf einen mittleren Rang.
  player.skills.grantPoints(5000, 'gamemaster');
  for (const masteryId of masteries.ids()) {
    const definition = masteries.get(masteryId);
    for (let i = state.masteries[masteryId] ?? 0; i < definition.maxLevel; i += 1) {
      player.skills.levelMastery(masteryId);
    }
    for (const entry of definition.skills) {
      for (let r = player.skills.rankOf(entry.ability); r < rank; r += 1) {
        player.skills.rankSkill(entry.ability);
      }
    }
  }

  // Jede Waffe und jedes Rüstungsteil zweifach ins Gepäck — zweifach, damit
  // sich Dual-Wield ausprobieren lässt.
  state.inventory = [];
  for (const itemId of items.ids()) {
    state.inventory.push(itemId, itemId);
  }

  player.recalculate();
  player.resources.revive();

  /** Schalter, die der Executor und der Schadenspfad abfragen. */
  player.gm = { freeCasts: true, god: false };

  bus.emit('ui:notice', { text: `Gamemaster: Stufe ${state.level}, alle Skills auf Rang ${rank}, ${state.inventory.length} Gegenstände`, tone: 'hint' });
  bus.emit('progression:changed', { id: player.id, reason: 'gamemaster' });
  return player.gm;
}

export function toggleGameMasterFlag(player, flag, bus) {
  if (!player?.gm) return null;
  player.gm[flag] = !player.gm[flag];

  const labels = { freeCasts: 'Keine Kosten', god: 'Unverwundbar' };
  bus.emit('ui:notice', {
    text: `${labels[flag] ?? flag}: ${player.gm[flag] ? 'an' : 'aus'}`,
    tone: 'hint',
  });
  return player.gm[flag];
}
