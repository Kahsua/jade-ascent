/**
 * Ladezeiten und Aufladen.
 *
 * Ein Skill mit castTime löst nicht sofort aus: der Charakter lädt sichtbar
 * auf, und erst am Ende laufen seine Komponenten. Unterbrochen wird durch
 * Loslaufen (außer die Fähigkeit erlaubt es), Betäubung, Tod oder Abbruch.
 *
 * Abklingzeit und Mana werden erst beim Auslösen verbraucht — ein
 * abgebrochener Zauber kostet nichts.
 */
export class CastSystem {
  #casts = new Map();

  constructor({ entities, bus }) {
    this.entities = entities;
    this.bus = bus;
    this.onComplete = null;

    bus.on('entity:died', ({ id }) => this.cancel(id, 'tot'));
    bus.on('input:command', ({ name }) => {
      if (name === 'cancel') this.cancel('player', 'abgebrochen');
    });
  }

  isCasting(entityId) {
    return this.#casts.has(entityId);
  }

  current(entityId) {
    return this.#casts.get(entityId) ?? null;
  }

  start(caster, ability, { targetId = null, point = null }) {
    const cast = {
      casterId: caster.id,
      ability,
      targetId,
      point,
      elapsed: 0,
      castTime: ability.castTime,
    };
    this.#casts.set(caster.id, cast);

    this.bus.emit('cast:started', {
      id: caster.id, abilityId: ability.id, name: ability.name,
      castTime: ability.castTime, element: ability.element ?? 'physical',
    });
    return cast;
  }

  cancel(entityId, reason = 'abgebrochen') {
    const cast = this.#casts.get(entityId);
    if (!cast) return false;

    this.#casts.delete(entityId);
    this.bus.emit('cast:cancelled', { id: entityId, abilityId: cast.ability.id, reason });
    return true;
  }

  update(dt) {
    for (const cast of [...this.#casts.values()]) {
      const caster = this.entities.get(cast.casterId);

      if (!caster?.isAlive) {
        this.cancel(cast.casterId, 'tot');
        continue;
      }
      if (!caster.status.canAct()) {
        this.cancel(cast.casterId, 'unterbrochen');
        continue;
      }
      if (!cast.ability.moveWhileCasting && caster.state.speed > 0.35) {
        this.cancel(cast.casterId, 'Bewegung');
        continue;
      }

      cast.elapsed += dt;
      this.bus.emit('cast:progress', {
        id: cast.casterId,
        progress: Math.min(1, cast.elapsed / cast.castTime),
      });

      if (cast.elapsed < cast.castTime) continue;

      this.#casts.delete(cast.casterId);
      this.bus.emit('cast:finished', { id: cast.casterId, abilityId: cast.ability.id });
      this.onComplete?.(cast);
    }
  }
}
