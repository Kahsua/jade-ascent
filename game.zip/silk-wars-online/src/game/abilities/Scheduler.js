/**
 * Verzögerte Ausführung im Spieltakt.
 *
 * Bewusst nicht setTimeout: Kampfabläufe müssen an den festen 60-Hz-Takt
 * gebunden sein, sonst laufen Kombos bei Bildratenschwankungen auseinander
 * oder feuern weiter, während das Spiel pausiert.
 */
export class Scheduler {
  #pending = [];

  after(delay, callback, owner = null) {
    this.#pending.push({ remaining: Math.max(0, delay), callback, owner });
  }

  /** Alles abbrechen, was zu einem Besitzer gehört (z.B. beim Tod). */
  cancelFor(owner) {
    this.#pending = this.#pending.filter((entry) => entry.owner !== owner);
  }

  get size() {
    return this.#pending.length;
  }

  update(dt) {
    if (this.#pending.length === 0) return;

    const due = [];
    for (let i = this.#pending.length - 1; i >= 0; i -= 1) {
      const entry = this.#pending[i];
      entry.remaining -= dt;
      if (entry.remaining > 0) continue;
      due.push(entry);
      this.#pending.splice(i, 1);
    }

    // Rückwärts eingesammelt, in ursprünglicher Reihenfolge ausführen.
    for (let i = due.length - 1; i >= 0; i -= 1) {
      try {
        due[i].callback();
      } catch (error) {
        console.error('[Scheduler] Schritt fehlgeschlagen:', error);
      }
    }
  }
}
