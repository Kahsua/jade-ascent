import { Registry } from '../../core/Registry.js';
import { resolveDamage } from '../combat/damage.js';
import { isHostile } from '../combat/factions.js';
import { statusEffects } from '../data/statusEffects.js';

/**
 * Ein Handler pro Komponententyp — wiederverwendbar über alle Fähigkeiten.
 *
 * Der Kontext, den jeder Handler bekommt:
 *   { executor, entities, bus, projectiles, ability, caster, target, point }
 *
 * Verschachtelung ist ausdrücklich erlaubt: der aoe-Handler ruft für jeden
 * Getroffenen wieder den Executor auf. Deshalb funktioniert "Fläche, die
 * Schaden UND einen Statuseffekt verteilt", ohne dass es dafür Code gibt.
 */
export const componentHandlers = new Registry('componentHandlers');

/** Wen meint diese Komponente? Standard ist das Ziel der Fähigkeit. */
function subject(context, component) {
  const at = component.at ?? 'target';
  if (at === 'self') return context.caster;
  if (at === 'target') return context.target ?? context.caster;
  return null;
}

componentHandlers.register('damage', (context, component) => {
  const target = subject(context, component);
  if (!target || !target.isAlive) return;
  if (target.id !== context.caster.id && !isHostile(context.caster, target)) return;

  const result = resolveDamage(context.caster, target, component);
  target.applyDamage(result.amount, {
    source: context.caster.id,
    type: result.school,
    critical: result.critical,
    abilityId: context.ability.id,
  });

  // Waffenverzauberung: der Bann bringt seinen eigenen On-Hit-Effekt mit.
  if (result.imbue?.onHit && target.isAlive) {
    target.status.apply(result.imbue.onHit.effect, {
      duration: result.imbue.onHit.duration ?? 4,
      source: context.caster.id,
    });
  }
});

componentHandlers.register('resource', (context, component) => {
  const target = subject(context, component);
  if (!target) return;

  const power = component.school === 'physical' ? context.caster.stats.physicalPower : context.caster.stats.magicPower;
  const amount = (component.base ?? 0) + power * (component.coefficient ?? 0);

  if (component.resource === 'mana') target.resources.mana = Math.min(target.resources.maxMana, target.resources.mana + amount);
  else target.applyHealing(amount, { source: context.caster.id, abilityId: context.ability.id });
});

componentHandlers.register('projectile', (context, component) => {
  const origin = {
    x: context.caster.position.x,
    y: context.caster.position.y + 1.2,
    z: context.caster.position.z,
  };

  const aim = context.target ?? null;
  const dx = aim ? aim.position.x - origin.x : Math.sin(context.caster.state.facing);
  const dz = aim ? aim.position.z - origin.z : Math.cos(context.caster.state.facing);
  const length = Math.hypot(dx, dz) || 1;

  context.projectiles.spawn({
    casterId: context.caster.id,
    targetId: aim?.id ?? null,
    abilityId: context.ability.id,
    origin,
    direction: { x: dx / length, z: dz / length },
    speed: component.speed,
    lifetime: component.lifetime,
    model: component.model,
    components: component.onHit ?? [],
  });
});

componentHandlers.register('aoe', (context, component) => {
  const center = component.at === 'self'
    ? context.caster.position
    : (component.at === 'target' ? context.target?.position : context.point);
  if (!center) return;

  const radius = component.radius ?? 3;
  context.bus.emit('vfx:aoe', { point: { x: center.x, z: center.z }, radius, style: component.vfx ?? 'fire' });

  const hits = context.entities.all().filter((entity) => {
    if (!entity.isAlive || !isHostile(context.caster, entity)) return false;
    return Math.hypot(entity.position.x - center.x, entity.position.z - center.z) <= radius;
  });

  // Verschachtelte Komponenten pro Getroffenem — über denselben Executor.
  for (const hit of hits) {
    context.executor.runComponents(component.components ?? [], { ...context, target: hit });
  }
});

componentHandlers.register('chain', (context, component) => {
  let current = context.target;
  if (!current?.isAlive) return;

  const jumps = component.jumps ?? 2;
  const range = component.range ?? 6;
  const falloff = component.falloff ?? 0.75;
  const struck = new Set();
  let factor = 1;
  let origin = { x: context.caster.position.x, y: context.caster.position.y + 1.3, z: context.caster.position.z };

  for (let jump = 0; jump <= jumps && current; jump += 1) {
    struck.add(current.id);

    const hitPoint = { x: current.position.x, y: current.position.y + 1.1, z: current.position.z };
    context.bus.emit('vfx:beam', { from: origin, to: hitPoint, style: 'lightning' });
    origin = hitPoint;

    // Abschwächung pro Sprung: dieselbe Komponentenliste, kleinere Werte.
    const scaled = (component.components ?? []).map((inner) => ({
      ...inner,
      base: inner.base !== undefined ? inner.base * factor : undefined,
      coefficient: inner.coefficient !== undefined ? inner.coefficient * factor : undefined,
    }));
    context.executor.runComponents(scaled, { ...context, target: current });
    context.bus.emit('vfx:aoe', { point: { x: current.position.x, z: current.position.z }, radius: 1.2, style: 'lightning' });

    const from = current;
    current = context.entities.all()
      .filter((entity) => entity.isAlive && !struck.has(entity.id) && isHostile(context.caster, entity))
      .map((entity) => ({ entity, distance: Math.hypot(entity.position.x - from.position.x, entity.position.z - from.position.z) }))
      .filter((candidate) => candidate.distance <= range)
      .sort((a, b) => a.distance - b.distance)[0]?.entity ?? null;

    factor *= falloff;
  }
});

componentHandlers.register('movement', (context, component) => {
  const state = context.caster.state;

  // Sprung auf ein Ziel: Richtung und Weite ergeben sich aus dem Abstand,
  // damit man nicht über den Gegner hinausschießt.
  if (component.mode === 'leap' && component.toward === 'target' && context.target) {
    const dx = context.target.position.x - state.position.x;
    const dz = context.target.position.z - state.position.z;
    const distance = Math.hypot(dx, dz) || 1;
    const reach = Math.max(0.5, Math.min(component.distance ?? distance, distance - 1.4));
    const duration = component.duration ?? 0.3;

    state.dash = {
      x: dx / distance,
      z: dz / distance,
      speed: reach / duration,
      remaining: duration,
    };
    state.facing = Math.atan2(dx, dz);
    context.bus.emit('entity:dash', { id: context.caster.id, duration, kind: 'leap' });
    return;
  }

  const moving = Math.hypot(state.velocity.x, state.velocity.z) > 0.2;

  // Ausweichen geht in Laufrichtung, im Stand nach hinten — kein Teleport,
  // sondern ein kurzer schneller Schritt, den die Bewegung ausführt.
  const dirX = moving ? state.velocity.x : -Math.sin(state.facing);
  const dirZ = moving ? state.velocity.z : -Math.cos(state.facing);
  const length = Math.hypot(dirX, dirZ) || 1;
  const duration = component.duration ?? 0.25;

  state.dash = {
    x: dirX / length,
    z: dirZ / length,
    speed: (component.distance ?? 5) / duration,
    remaining: duration,
  };
  context.bus.emit('entity:dash', { id: context.caster.id, duration });
});

componentHandlers.register('status_effect', (context, component) => {
  const target = subject(context, component);
  if (!target || !target.isAlive) return;

  const definition = statusEffects.find(component.effect);
  if (!definition) return;

  // Optionale Trefferchance, damit nicht jeder Biss sofort Blutung stapelt.
  if (component.chance !== undefined && Math.random() > component.chance) return;

  // Debuffs treffen nur Gegner, Buffs nur einen selbst oder Verbündete.
  const isSelf = target.id === context.caster.id;
  if (definition.category === 'debuff' && !isSelf && !isHostile(context.caster, target)) return;
  if (definition.category === 'buff' && !isSelf && isHostile(context.caster, target)) return;

  // Rückstoß ist kein Zustand, sondern ein Schubs: derselbe Mechanismus wie
  // beim Ausweichschritt, nur vom Verursacher weggerichtet.
  if (definition.impulse) {
    const dx = target.position.x - context.caster.position.x;
    const dz = target.position.z - context.caster.position.z;
    const length = Math.hypot(dx, dz) || 1;
    const duration = definition.impulse.duration ?? 0.25;
    target.state.dash = {
      x: dx / length,
      z: dz / length,
      speed: (component.magnitude ?? definition.impulse.distance) / duration,
      remaining: duration,
    };
    context.bus.emit('entity:dash', { id: target.id, duration, kind: 'knockback' });
    return;
  }

  target.status.apply(component.effect, {
    duration: component.duration ?? 3,
    magnitude: component.magnitude ?? null,
    source: context.caster.id,
  });
});
