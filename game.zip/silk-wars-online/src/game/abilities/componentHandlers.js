import { Registry } from '../../core/Registry.js';
import { resolveDamage } from '../combat/damage.js';
import { isAlly, isHostile } from '../combat/factions.js';
import { statusEffects } from '../data/statusEffects.js';
import { elementProc, resolveElement } from '../combat/imbue.js';

/**
 * Ein Handler pro Komponententyp — wiederverwendbar über alle Fähigkeiten.
 *
 * Der Kontext, den jeder Handler bekommt:
 *   { executor, entities, bus, projectiles, ability, caster, target, point }
 *
 * Verschachtelung ist ausdrücklich erlaubt: der aoe-Handler ruft für jeden
 * Getroffenen wieder den Executor auf. Deshalb funktioniert "Fläche, die
 * Schaden UND einen Statuseffekt verteilt", ohne dass es dafür Code gibt.
 */
export const componentHandlers = new Registry('componentHandlers');

/** Wen meint diese Komponente? Standard ist das Ziel der Fähigkeit. */
function subject(context, component) {
  const at = component.at ?? 'target';
  if (at === 'self') return context.caster;
  if (at === 'target') return context.target ?? context.caster;
  return null;
}

componentHandlers.register('damage', (context, component) => {
  const target = subject(context, component);
  if (!target || !target.isAlive) return;
  if (target.id !== context.caster.id && !isHostile(context.caster, target)) return;

  const result = resolveDamage(context.caster, target, component);
  target.applyDamage(result.amount, {
    source: context.caster.id,
    type: result.school,
    critical: result.critical,
    abilityId: context.ability.id,
  });

  // Waffenverzauberung: jeder Auslöser hat seine eigene Wahrscheinlichkeit.
  for (const proc of result.imbue?.procs ?? []) {
    if (!target.isAlive) break;
    if (proc.chance !== undefined && Math.random() > proc.chance) continue;

    if (proc.effect) {
      target.status.apply(proc.effect, {
        duration: proc.duration ?? 3,
        magnitude: proc.magnitude ?? null,
        source: context.caster.id,
      });
    }
    // Manche Auslöser tun mehr als einen Zustand zu setzen (Static springt weiter).
    if (proc.components) context.executor.runComponents(proc.components, context);
  }
});

componentHandlers.register('resource', (context, component) => {
  const target = subject(context, component);
  if (!target) return;

  const power = component.school === 'physical' ? context.caster.stats.physicalPower : context.caster.stats.magicPower;
  const amount = (component.base ?? 0) + power * (component.coefficient ?? 0);

  if (component.resource === 'mana') target.resources.mana = Math.min(target.resources.maxMana, target.resources.mana + amount);
  else target.applyHealing(amount, { source: context.caster.id, abilityId: context.ability.id });
});

componentHandlers.register('projectile', (context, component) => {
  const origin = {
    x: context.caster.position.x,
    y: context.caster.position.y + 1.2,
    z: context.caster.position.z,
  };

  // Bodenzielende Fähigkeiten schicken das Geschoss zum Punkt, nicht zum Gegner.
  const destination = (component.toPoint || context.ability.targeting === 'ground') && context.point
    ? { x: context.point.x, z: context.point.z }
    : null;

  const aim = destination ? null : (context.target ?? null);
  const dx = destination
    ? destination.x - origin.x
    : (aim ? aim.position.x - origin.x : Math.sin(context.caster.state.facing));
  const dz = destination
    ? destination.z - origin.z
    : (aim ? aim.position.z - origin.z : Math.cos(context.caster.state.facing));
  const length = Math.hypot(dx, dz) || 1;
  const baseAngle = Math.atan2(dx / length, dz / length);

  const count = component.count ?? 1;
  const spread = component.spread ?? 0;
  // Mehrere Geschosse fliegen gefächert und ohne Zielsuche — sonst landeten
  // alle fünf Pfeile im selben Gegner.
  const homing = component.homing ?? (count === 1);

  for (let i = 0; i < count; i += 1) {
    const offset = count === 1 ? 0 : (i - (count - 1) / 2) * spread;
    const angle = baseAngle + offset;

    context.projectiles.spawn({
      casterId: context.caster.id,
      targetId: homing ? (aim?.id ?? null) : null,
      abilityId: context.ability.id,
      origin: { ...origin },
      direction: { x: Math.sin(angle), z: Math.cos(angle) },
      speed: component.speed,
      lifetime: component.lifetime,
      radius: component.radius,
      model: component.model ?? resolveElement(context.ability.element ?? 'bolt', context),
      element: resolveElement(component.element ?? context.ability.element ?? 'physical', context),
      components: component.onHit ?? [],
      homing,
      bounces: component.bounces ?? 0,
      bounceRange: component.bounceRange ?? 8,
      falloff: component.falloff ?? 0.85,
      returns: component.returns ?? false,
      destination,
    });
  }
});

/** Abfolge mit Verzögerungen — die Grundlage aller Kombos. */
componentHandlers.register('sequence', (context, component) => {
  let time = 0;
  for (const step of component.steps ?? []) {
    time += step.delay ?? 0;
    const components = step.components ?? [];
    context.scheduler.after(time, () => {
      if (!context.caster.isAlive) return;
      context.executor.runComponents(components, context);
    }, context.caster.id);
  }
});

/** Dasselbe mehrfach im festen Takt — die kurze Schreibweise für Kombos. */
componentHandlers.register('repeat', (context, component) => {
  const times = component.times ?? 2;
  const interval = component.interval ?? 0.15;

  for (let i = 0; i < times; i += 1) {
    context.scheduler.after(i * interval, () => {
      if (!context.caster.isAlive) return;
      context.executor.runComponents(component.components ?? [], context);
    }, context.caster.id);
  }
});

componentHandlers.register('aoe', (context, component) => {
  const base = component.at === 'self'
    ? context.caster.position
    : (component.at === 'target' ? context.target?.position : context.point);
  if (!base) return;

  // Streuung: mehrere Einschläge in einem Gebiet sollen nicht übereinander liegen.
  const jitter = component.jitter ?? 0;
  const center = jitter
    ? { x: base.x + (Math.random() - 0.5) * jitter * 2, z: base.z + (Math.random() - 0.5) * jitter * 2 }
    : base;

  const radius = component.radius ?? 3;
  const style = resolveElement(component.vfx ?? context.ability.element ?? 'fire', context);
  const facing = context.caster.state.facing;
  const halfAngle = component.shape === 'cone' ? (component.angle ?? 1.2) / 2 : null;

  context.bus.emit('vfx:aoe', {
    point: { x: center.x, z: center.z }, radius, style,
    shape: component.shape ?? 'circle', angle: component.angle, facing,
  });

  const hits = context.entities.all().filter((entity) => {
    if (!entity.isAlive || !isHostile(context.caster, entity)) return false;

    const dx = entity.position.x - center.x;
    const dz = entity.position.z - center.z;
    if (Math.hypot(dx, dz) > radius) return false;

    // Kegel: zusätzlich muss das Ziel vor dem Wirker liegen.
    if (halfAngle === null) return true;
    let delta = Math.atan2(dx, dz) - facing;
    delta = Math.atan2(Math.sin(delta), Math.cos(delta));
    return Math.abs(delta) <= halfAngle;
  });

  // Elementtypische Zugabe, wenn die Fähigkeit sie anfordert.
  const proc = component.elementProc ? elementProc(style) : null;
  if (proc) {
    for (const hit of hits) {
      if (proc.chance !== undefined && Math.random() > proc.chance) continue;
      hit.status.apply(proc.effect, { duration: proc.duration, magnitude: proc.magnitude ?? null, source: context.caster.id });
    }
  }

  // Verschachtelte Komponenten pro Getroffenem — über denselben Executor.
  for (const hit of hits) {
    context.executor.runComponents(component.components ?? [], { ...context, target: hit });
  }
});

componentHandlers.register('chain', (context, component) => {
  let current = context.target;
  if (!current?.isAlive) return;

  const jumps = component.jumps ?? 2;
  const range = component.range ?? 6;
  const falloff = component.falloff ?? 0.75;
  const struck = new Set();
  let factor = 1;
  let origin = { x: context.caster.position.x, y: context.caster.position.y + 1.3, z: context.caster.position.z };

  for (let jump = 0; jump <= jumps && current; jump += 1) {
    struck.add(current.id);

    const hitPoint = { x: current.position.x, y: current.position.y + 1.1, z: current.position.z };
    context.bus.emit('vfx:beam', { from: origin, to: hitPoint, style: 'lightning' });
    origin = hitPoint;

    // Abschwächung pro Sprung: dieselbe Komponentenliste, kleinere Werte.
    const scaled = (component.components ?? []).map((inner) => ({
      ...inner,
      base: inner.base !== undefined ? inner.base * factor : undefined,
      coefficient: inner.coefficient !== undefined ? inner.coefficient * factor : undefined,
    }));
    context.executor.runComponents(scaled, { ...context, target: current });
    context.bus.emit('vfx:aoe', { point: { x: current.position.x, z: current.position.z }, radius: 1.2, style: 'lightning' });

    const from = current;
    current = context.entities.all()
      .filter((entity) => entity.isAlive && !struck.has(entity.id) && isHostile(context.caster, entity))
      .map((entity) => ({ entity, distance: Math.hypot(entity.position.x - from.position.x, entity.position.z - from.position.z) }))
      .filter((candidate) => candidate.distance <= range)
      .sort((a, b) => a.distance - b.distance)[0]?.entity ?? null;

    factor *= falloff;
  }
});

componentHandlers.register('movement', (context, component) => {
  // Wer bewegt wird: normalerweise der Wirker, beim Zug das Ziel.
  const mover = component.at === 'target' ? context.target : context.caster;
  if (!mover?.isAlive) return;
  const state = mover.state;

  const duration = component.duration ?? 0.3;
  const apply = (dx, dz, distance) => {
    const length = Math.hypot(dx, dz) || 1;
    state.dash = {
      x: dx / length,
      z: dz / length,
      speed: distance / duration,
      remaining: duration,
    };
    context.bus.emit('entity:dash', { id: mover.id, duration, kind: component.mode ?? 'dash' });
  };

  if (component.mode === 'leap' || component.mode === 'pull') {
    // Sprung auf einen Bodenpunkt (Wuchtsprung) — sonst auf eine Entity.
    if (component.toward === 'point' && context.point) {
      const dx = context.point.x - state.position.x;
      const dz = context.point.z - state.position.z;
      const distance = Math.hypot(dx, dz) || 1;
      apply(dx, dz, Math.min(component.distance ?? distance, distance));
      state.facing = Math.atan2(dx, dz);
      return;
    }

    const anchor = component.toward === 'caster' ? context.caster : context.target;

    // Sprung auf ein Ziel: Weite ergibt sich aus dem Abstand, damit niemand
    // über sein Ziel hinausschießt.
    if (anchor && component.toward !== 'away') {
      const dx = anchor.position.x - state.position.x;
      const dz = anchor.position.z - state.position.z;
      const distance = Math.hypot(dx, dz) || 1;
      const reach = Math.max(0.5, Math.min(component.distance ?? distance, distance - 1.4));
      apply(dx, dz, reach);
      state.facing = Math.atan2(dx, dz);
      return;
    }

    // Ansturm: geradeaus in Blickrichtung.
    if (component.toward === 'forward') {
      apply(Math.sin(state.facing), Math.cos(state.facing), component.distance ?? 8);
      return;
    }

    // Rückwärtssprung: vom Ziel weg, sonst entgegen der Blickrichtung.
    const from = context.target ?? null;
    const dx = from ? state.position.x - from.position.x : -Math.sin(state.facing);
    const dz = from ? state.position.z - from.position.z : -Math.cos(state.facing);
    apply(dx, dz, component.distance ?? 6);
    return;
  }

  // Ausweichschritt: in Laufrichtung, im Stand nach hinten.
  const moving = Math.hypot(state.velocity.x, state.velocity.z) > 0.2;
  const dirX = moving ? state.velocity.x : -Math.sin(state.facing);
  const dirZ = moving ? state.velocity.z : -Math.cos(state.facing);
  apply(dirX, dirZ, component.distance ?? 5);
});

/**
 * Einschlag aus der Höhe: die Wirkung kommt verzögert, die Anzeige lässt in
 * der Zwischenzeit sichtbar etwas herabfallen. Die Bewegung kennt keine
 * Y-Achse — das Fallen ist deshalb reine Anzeige, der Zeitpunkt aber echt.
 */
componentHandlers.register('falling', (context, component) => {
  const origin = component.at === 'self' ? context.caster.position : context.point;
  if (!origin) return;

  const delay = component.delay ?? 1.1;
  const style = resolveElement(component.vfx ?? context.ability.element ?? 'fire', context);
  const point = { x: origin.x, z: origin.z };

  context.bus.emit('vfx:falling', { point, delay, style, radius: component.radius ?? 3, model: component.model ?? 'meteor' });

  context.scheduler.after(delay, () => {
    if (!context.caster.isAlive) return;
    context.executor.runComponents(component.components ?? [], { ...context, point });
  }, context.caster.id);
});

/** Stehende oder wandernde Bodenfläche. */
componentHandlers.register('hazard', (context, component) => {
  const at = component.at ?? 'point';
  const origin = at === 'self'
    ? context.caster.position
    : (at === 'target' ? context.target?.position : context.point);
  if (!origin) return;

  const facing = context.caster.state.facing;
  const direction = component.speed ? { x: Math.sin(facing), z: Math.cos(facing) } : null;

  context.hazards.spawn({
    casterId: context.caster.id,
    abilityId: context.ability.id,
    position: { x: origin.x, z: origin.z },
    radius: component.radius,
    duration: component.duration,
    interval: component.interval,
    components: component.components ?? [],
    speed: component.speed ?? 0,
    direction,
    follow: component.follow === 'self' ? context.caster.id : null,
    style: resolveElement(component.vfx ?? context.ability.element ?? 'physical', context),
    model: component.model ?? 'field',
  });
});

/** Dauerhafte Verbindung zwischen Wirker und Ziel. */
componentHandlers.register('tether', (context, component) => {
  const target = subject(context, component);
  if (!target || target.id === context.caster.id || !target.isAlive) return;
  // Fesselketten fangen Gegner, Schutzbindungen nur Verbündete.
  if (component.ally && !isAlly(context.caster, target)) return;
  if (!component.ally && !isHostile(context.caster, target)) return;

  context.tethers.create({
    sourceId: context.caster.id,
    targetId: target.id,
    maxDistance: component.maxDistance ?? 8,
    duration: component.duration ?? 6,
    abilityId: context.ability.id,
    style: component.vfx ?? context.ability.element ?? 'physical',
  });
});

/** Zeitweilige Mauer quer zur Blickrichtung. */
componentHandlers.register('barrier', (context, component) => {
  const at = component.at ?? 'point';
  const origin = at === 'self' ? context.caster.position : context.point;
  if (!origin || !context.barriers) return;

  context.barriers.spawn({
    casterId: context.caster.id,
    origin: { x: origin.x, z: origin.z },
    facing: context.caster.state.facing,
    width: component.width,
    thickness: component.thickness,
    duration: component.duration,
    segments: component.segments,
    style: component.vfx ?? context.ability.element ?? 'physical',
  });
});

/** Spott: Gegner im Umkreis nehmen den Wirker ins Visier. */
componentHandlers.register('taunt', (context, component) => {
  const radius = component.radius ?? 8;
  let taunted = 0;

  for (const entity of context.entities.all()) {
    if (!entity.isAlive || !isHostile(context.caster, entity) || !entity.ai) continue;

    const distance = Math.hypot(entity.position.x - context.caster.position.x, entity.position.z - context.caster.position.z);
    if (distance > radius) continue;

    entity.ai.forceTarget(context.caster.id, component.duration ?? 5);
    entity.status.apply('taunted', { duration: component.duration ?? 5, source: context.caster.id });
    taunted += 1;
  }

  context.bus.emit('vfx:aoe', { point: { x: context.caster.position.x, z: context.caster.position.z }, radius, style: 'physical' });
  context.bus.emit('taunt:applied', { id: context.caster.id, count: taunted });
});

componentHandlers.register('status_effect', (context, component) => {
  const target = subject(context, component);
  if (!target || !target.isAlive) return;

  const definition = statusEffects.find(component.effect);
  if (!definition) return;

  // Optionale Trefferchance, damit nicht jeder Biss sofort Blutung stapelt.
  if (component.chance !== undefined && Math.random() > component.chance) return;

  // Debuffs treffen nur Gegner, Buffs nur einen selbst oder Verbündete.
  const isSelf = target.id === context.caster.id;
  if (definition.category === 'debuff' && !isSelf && !isHostile(context.caster, target)) return;
  if (definition.category === 'buff' && !isSelf && !isAlly(context.caster, target)) return;

  // Rückstoß ist kein Zustand, sondern ein Schubs: derselbe Mechanismus wie
  // beim Ausweichschritt, nur vom Verursacher weggerichtet.
  if (definition.impulse) {
    const dx = target.position.x - context.caster.position.x;
    const dz = target.position.z - context.caster.position.z;
    const length = Math.hypot(dx, dz) || 1;
    const duration = definition.impulse.duration ?? 0.25;
    target.state.dash = {
      x: dx / length,
      z: dz / length,
      speed: (component.magnitude ?? definition.impulse.distance) / duration,
      remaining: duration,
    };
    context.bus.emit('entity:dash', { id: target.id, duration, kind: 'knockback' });
    return;
  }

  target.status.apply(component.effect, {
    duration: component.duration ?? 3,
    magnitude: component.magnitude ?? null,
    source: context.caster.id,
  });
});
