import { abilities } from '../data/abilities.js';
import { componentHandlers } from './componentHandlers.js';
import { scaleAbility } from '../progression/scaling.js';

/** Abgeschwächte Kopie einer Komponentenliste (Geschosssprünge). */
function weaken(components, factor) {
  if (factor === 1) return components;
  return components.map((component) => ({
    ...component,
    base: component.base !== undefined ? component.base * factor : undefined,
    coefficient: component.coefficient !== undefined ? component.coefficient * factor : undefined,
  }));
}

/**
 * EIN Executor für alle Fähigkeiten. Es gibt keine Skill-Klassen.
 *
 * Ablauf: prüfen (lebt, erlernt, Abklingzeit, Gates, Ziel, Reichweite) — dann
 * entweder sofort auslösen oder, bei einer Ladezeit, den Ladevorgang starten
 * und erst an dessen Ende auslösen. Abklingzeit und Mana kostet nur das
 * tatsächliche Auslösen; ein abgebrochener Zauber ist umsonst gewesen.
 *
 * Jeder Komponententyp hat genau einen Handler, und Handler dürfen den
 * Executor rekursiv aufrufen (aoe, chain) oder ihn zeitversetzt einplanen
 * (sequence, repeat).
 */
export class AbilityExecutor {
  constructor({ entities, bus, projectiles, scheduler, casts = null, hazards = null, tethers = null, barriers = null }) {
    this.entities = entities;
    this.bus = bus;
    this.projectiles = projectiles;
    this.scheduler = scheduler;
    this.casts = casts;
    this.hazards = hazards;
    this.tethers = tethers;
    this.barriers = barriers;

    projectiles.onHit = ({ caster, target, projectile, components, factor = 1, point = null }) => {
      const definition = abilities.find(projectile.abilityId) ?? {};
      this.runComponents(weaken(components, factor), this.#context({
        ability: { id: projectile.abilityId, ...definition },
        caster,
        target,
        point,
      }));
    };

    // Ein Bodeneffekt wirkt über denselben Weg wie alles andere.
    if (hazards) {
      hazards.onTick = ({ caster, target, hazard, components }) => {
        const definition = abilities.find(hazard.abilityId) ?? {};
        this.runComponents(components, this.#context({
          ability: { id: hazard.abilityId, ...definition },
          caster,
          target,
          point: { x: hazard.position.x, z: hazard.position.z },
        }));
      };
    }

    if (this.casts) this.casts.onComplete = (cast) => this.#complete(cast);

    bus.on('ability:requested', (request) => this.request(request));
    bus.on('entity:died', ({ id }) => {
      this.scheduler.cancelFor(id);
      this.hazards?.removeFor(id);
      this.tethers?.releaseFor(id);
    });
  }

  /** @returns {boolean} ob die Fähigkeit ausgelöst oder das Laden begonnen hat */
  request({ abilityId, casterId, targetId = null, point = null }) {
    const caster = this.entities.get(casterId);
    if (!caster || !caster.isAlive) return false;

    const definition = abilities.find(abilityId);
    if (!definition) return this.#deny(caster, `Unbekannte Fähigkeit: ${abilityId}`);

    if (caster.skills && !caster.skills.isUnlocked(abilityId)) {
      return this.#deny(caster, `${definition.name}: noch nicht erlernt`);
    }
    if (this.casts?.isCasting(caster.id)) {
      return this.#deny(caster, `${definition.name}: lädt bereits`);
    }

    const ability = this.#resolve(caster, abilityId, definition);

    if (!caster.status.canAct()) return this.#deny(caster, `${ability.name}: handlungsunfähig`);
    if ((ability.mana ?? 0) > 0 && !caster.status.canCast()) return this.#deny(caster, `${ability.name}: verstummt`);

    const free = caster.gm?.freeCasts === true;

    if (!free && !caster.cooldowns.isReady(ability)) {
      const remaining = caster.cooldowns.remaining(abilityId);
      return this.#deny(caster, remaining > 0
        ? `${ability.name}: noch ${remaining.toFixed(1)} s`
        : `${ability.name}: keine Ladung frei`);
    }

    const target = targetId ? this.entities.get(targetId) : null;
    const problem = this.#checkTarget(ability, caster, target, point);
    if (problem) return this.#deny(caster, problem);

    if (!free && ability.mana > 0 && caster.resources.mana < ability.mana) {
      return this.#deny(caster, `${ability.name}: nicht genug Mana (${ability.mana} nötig)`);
    }

    if (ability.castTime > 0 && this.casts) {
      this.casts.start(caster, ability, { targetId: target?.id ?? null, point });
      return true;
    }

    return this.#launch(caster, ability, target, point);
  }

  /** Ende einer Ladezeit: noch einmal prüfen, dann auslösen. */
  #complete(cast) {
    const caster = this.entities.get(cast.casterId);
    if (!caster?.isAlive) return false;

    const target = cast.targetId ? this.entities.get(cast.targetId) : null;
    const problem = this.#checkTarget(cast.ability, caster, target, cast.point);
    if (problem) return this.#deny(caster, problem);

    return this.#launch(caster, cast.ability, target, cast.point);
  }

  #launch(caster, ability, target, point) {
    // Im Testmodus kosten Fähigkeiten weder Mana noch Abklingzeit.
    if (caster.gm?.freeCasts !== true) {
      if (ability.mana > 0 && !caster.resources.spendMana(ability.mana)) {
        return this.#deny(caster, `${ability.name}: nicht genug Mana (${ability.mana} nötig)`);
      }
      caster.cooldowns.consume(ability);
    }

    this.bus.emit('ability:cast', {
      casterId: caster.id, abilityId: ability.id, targetId: target?.id ?? null, point,
      animation: ability.animation ?? null, name: ability.name, element: ability.element ?? 'physical',
    });

    this.runComponents(ability.components ?? [], this.#context({ ability, caster, target, point }));
    return true;
  }

  #resolve(caster, abilityId, definition) {
    const rank = Math.max(1, caster.skills?.rankOf(abilityId) ?? 1);
    return scaleAbility(
      { id: abilityId, ...definition },
      rank,
      caster.skills?.abilityBonus(abilityId) ?? 0,
    );
  }

  #checkTarget(ability, caster, target, point) {
    if (ability.targeting === 'target') {
      if (!target || !target.isAlive) return `${ability.name}: kein gültiges Ziel`;
      const distance = Math.hypot(target.position.x - caster.position.x, target.position.z - caster.position.z);
      if (ability.range && distance > ability.range) {
        return `${ability.name}: außer Reichweite (${distance.toFixed(1)} m von ${ability.range.toFixed(1)} m)`;
      }
    }
    if (ability.targeting === 'ground' && !point) return `${ability.name}: kein Bodenpunkt`;

    // Bedingungen aus den Fähigkeiten-Daten, z.B. "nur gegen liegende Ziele".
    const needed = ability.requires?.targetStatus;
    if (needed && !target?.status.has(needed)) {
      return `${ability.name}: nur gegen ${ability.requires.label ?? needed}`;
    }
    return null;
  }

  #context({ ability, caster, target, point }) {
    return {
      executor: this,
      entities: this.entities,
      bus: this.bus,
      projectiles: this.projectiles,
      hazards: this.hazards,
      tethers: this.tethers,
      barriers: this.barriers,
      scheduler: this.scheduler,
      ability,
      caster,
      target,
      point,
    };
  }

  /** Komponentenliste abarbeiten — auch verschachtelt oder zeitversetzt. */
  runComponents(components, context) {
    for (const component of components) {
      const handler = componentHandlers.find(component.type);
      if (!handler) {
        console.warn(`[AbilityExecutor] Kein Handler für Komponente "${component.type}"`);
        continue;
      }
      handler(context, component);
    }
  }

  #deny(caster, text) {
    if (caster.template.faction === 'player') this.bus.emit('ui:notice', { text, tone: 'warn' });
    return false;
  }
}
