/**
 * Abklingzeiten und Ladungen — eine Komponente pro Entity.
 *
 * Ladungen (Ausweichen: zwei Stück, die sich einzeln aufladen) laufen über
 * denselben Mechanismus wie normale Cooldowns, damit die Ability-Pipeline
 * keinen Sonderfall dafür braucht.
 */
export class CooldownController {
  #timers = new Map();   // abilityId -> Restzeit in Sekunden
  #charges = new Map();  // abilityId -> { current, max, chargeTime, elapsed }

  /** @returns {boolean} true, wenn die Fähigkeit jetzt einsetzbar ist */
  isReady(ability) {
    if (ability.charges) {
      const pool = this.#pool(ability);
      return pool.current > 0;
    }
    return (this.#timers.get(ability.id) ?? 0) <= 0;
  }

  remaining(abilityId) {
    return Math.max(0, this.#timers.get(abilityId) ?? 0);
  }

  chargesOf(abilityId) {
    const pool = this.#charges.get(abilityId);
    return pool ? { current: pool.current, max: pool.max } : null;
  }

  /** Nach erfolgreichem Einsatz: Zeit bzw. Ladung verbrauchen. */
  consume(ability) {
    if (ability.charges) {
      const pool = this.#pool(ability);
      pool.current = Math.max(0, pool.current - 1);
      return;
    }
    if (ability.cooldown > 0) this.#timers.set(ability.id, ability.cooldown);
  }

  update(dt) {
    for (const [id, remaining] of this.#timers) {
      const next = remaining - dt;
      if (next <= 0) this.#timers.delete(id);
      else this.#timers.set(id, next);
    }

    for (const pool of this.#charges.values()) {
      if (pool.current >= pool.max) continue;
      pool.elapsed += dt;
      while (pool.elapsed >= pool.chargeTime && pool.current < pool.max) {
        pool.elapsed -= pool.chargeTime;
        pool.current += 1;
      }
      if (pool.current >= pool.max) pool.elapsed = 0;
    }
  }

  /** Fortschritt der nächsten Ladung, 0..1 — für die Anzeige. */
  chargeProgress(abilityId) {
    const pool = this.#charges.get(abilityId);
    if (!pool || pool.current >= pool.max) return 1;
    return pool.elapsed / pool.chargeTime;
  }

  #pool(ability) {
    let pool = this.#charges.get(ability.id);
    if (!pool) {
      pool = { current: ability.charges, max: ability.charges, chargeTime: ability.chargeTime ?? 5, elapsed: 0 };
      this.#charges.set(ability.id, pool);
    }
    return pool;
  }

  toJSON() {
    return {
      timers: Object.fromEntries(this.#timers),
      charges: Object.fromEntries([...this.#charges].map(([id, pool]) => [id, pool.current])),
    };
  }
}
