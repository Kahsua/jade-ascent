import { EQUIPMENT_SLOTS, items } from '../data/items.js';

/**
 * Ausrüstung als eigene Komponente: Slots, Verträglichkeitsregeln und die
 * Summe der Stat-Boni.
 *
 * Die Regeln stehen in den Item-Daten, nicht im Code: "grip" entscheidet, ob
 * eine Waffe die Nebenhand blockiert, "dualWield" erlaubt sie dort zusätzlich.
 * Damit ist Dual-Wield keine Sonderbehandlung für Dolche, sondern ein Feld.
 */
export class Equipment {
  constructor({ state, onChange = null }) {
    this.state = state;
    this.onChange = onChange;
    if (!state.equipment) state.equipment = {};
    if (!state.inventory) state.inventory = [];
  }

  get slots() {
    return this.state.equipment;
  }

  get inventory() {
    return this.state.inventory;
  }

  itemIn(slot) {
    return this.state.equipment[slot] ?? null;
  }

  definition(slot) {
    const id = this.itemIn(slot);
    return id ? { id, ...items.get(id) } : null;
  }

  /** @returns {{ok: boolean, reason?: string, slot?: string, frees?: string[]}} */
  canEquip(itemId, targetSlot = null) {
    const definition = items.find(itemId);
    if (!definition) return { ok: false, reason: 'Unbekannter Gegenstand' };

    const slot = targetSlot ?? definition.slot;
    if (!EQUIPMENT_SLOTS.includes(slot)) return { ok: false, reason: 'Ungültiger Slot' };

    if ((definition.level ?? 1) > (this.state.level ?? 1)) {
      return { ok: false, reason: `Erst ab Stufe ${definition.level}` };
    }

    if (slot === 'offHand') {
      const allowed = definition.grip === 'off_hand' || definition.dualWield === true;
      if (!allowed) return { ok: false, reason: 'Nicht für die Nebenhand geeignet' };

      const main = this.definition('mainHand');
      if (main?.grip === 'two_hand') {
        return { ok: false, reason: `${main.name} braucht beide Hände` };
      }
    }

    if (slot === 'mainHand' && definition.grip === 'two_hand' && this.itemIn('offHand')) {
      // Kein Fehler: die Nebenhand wandert zurück ins Gepäck.
      return { ok: true, slot, frees: ['offHand'] };
    }

    if (slot !== definition.slot && !(slot === 'offHand' && definition.dualWield)) {
      return { ok: false, reason: 'Passt nicht in diesen Slot' };
    }

    return { ok: true, slot, frees: [] };
  }

  /**
   * Anlegen. Verdrängte Gegenstände wandern zurück ins Gepäck.
   * @returns {{ok: boolean, reason?: string, removed?: string[]}}
   */
  equip(itemId, targetSlot = null) {
    const check = this.canEquip(itemId, targetSlot);
    if (!check.ok) return check;

    // Liegt das Stück schon im Zielslot, ist nichts zu tun.
    if (this.itemIn(check.slot) === itemId) return { ok: true, removed: [], slot: check.slot };

    // Sonst muss es im Gepäck liegen oder in einem anderen Slot stecken —
    // sonst ließe sich ein Stück beliebig oft anlegen.
    const bagIndex = this.inventory.indexOf(itemId);
    const wornSlot = EQUIPMENT_SLOTS.find((slot) => slot !== check.slot && this.itemIn(slot) === itemId);
    if (bagIndex < 0 && !wornSlot) return { ok: false, reason: 'Nicht im Gepäck' };

    const removed = [];
    for (const slot of [check.slot, ...(check.frees ?? [])]) {
      const current = this.itemIn(slot);
      if (!current) continue;
      this.state.equipment[slot] = null;
      removed.push(current);
      this.onChange?.({ slot, itemId: null });
    }

    if (bagIndex >= 0) {
      this.inventory.splice(bagIndex, 1);
    } else {
      // Umhängen: aus dem alten Slot heraus, nicht aus dem Gepäck.
      this.state.equipment[wornSlot] = null;
      this.onChange?.({ slot: wornSlot, itemId: null });
    }

    for (const id of removed) this.inventory.push(id);

    this.state.equipment[check.slot] = itemId;
    this.onChange?.({ slot: check.slot, itemId });
    return { ok: true, removed, slot: check.slot };
  }

  unequip(slot) {
    const current = this.itemIn(slot);
    if (!current) return false;
    this.state.equipment[slot] = null;
    this.inventory.push(current);
    this.onChange?.({ slot, itemId: null });
    return true;
  }

  addToInventory(itemId) {
    if (!items.has(itemId)) return false;
    this.inventory.push(itemId);
    this.onChange?.({ slot: null, itemId, inventory: true });
    return true;
  }

  /** Summe aller angelegten Boni — fließt in deriveStats. */
  bonuses() {
    const totals = {};
    for (const slot of EQUIPMENT_SLOTS) {
      const definition = this.definition(slot);
      if (!definition?.stats) continue;
      for (const [stat, value] of Object.entries(definition.stats)) {
        totals[stat] = (totals[stat] ?? 0) + value;
      }
    }
    return totals;
  }

  /** Überblick für das Inventarfenster. */
  overview() {
    return EQUIPMENT_SLOTS.map((slot) => ({ slot, item: this.definition(slot) }));
  }
}
