/**
 * Eine Komponente pro Belang: Leben, Mana, Regeneration.
 *
 * Kennt weder EventBus noch Rendering — sie meldet Änderungen über einen
 * Callback. Wer sie besitzt (die Entity), entscheidet, was daraus wird.
 */
export class ResourcePool {
  constructor({ maxHealth = 1, maxMana = 0, healthRegen = 0, manaRegen = 0, onChange = null } = {}) {
    this.maxHealth = maxHealth;
    this.maxMana = maxMana;
    this.healthRegen = healthRegen;
    this.manaRegen = manaRegen;
    this.health = maxHealth;
    this.mana = maxMana;
    this.onChange = onChange;
    this._lastReported = { health: -1, mana: -1, maxHealth: -1, maxMana: -1 };
  }

  get isAlive() {
    return this.health > 0;
  }

  get healthRatio() {
    return this.maxHealth > 0 ? this.health / this.maxHealth : 0;
  }

  get manaRatio() {
    return this.maxMana > 0 ? this.mana / this.maxMana : 0;
  }

  /** Maxima aus neu berechneten Stats übernehmen, Verhältnis beibehalten. */
  applyStats(stats, { keepRatio = true } = {}) {
    const healthRatio = keepRatio && this.maxHealth > 0 ? this.healthRatio : 1;
    const manaRatio = keepRatio && this.maxMana > 0 ? this.manaRatio : 1;

    this.maxHealth = stats.maxHealth;
    this.maxMana = stats.maxMana;
    this.healthRegen = stats.healthRegen;
    this.manaRegen = stats.manaRegen;

    this.health = Math.min(this.maxHealth, this.maxHealth * healthRatio);
    this.mana = Math.min(this.maxMana, this.maxMana * manaRatio);
    this.#report();
  }

  update(dt) {
    if (!this.isAlive) return;
    if (this.health < this.maxHealth) {
      this.health = Math.min(this.maxHealth, this.health + this.healthRegen * dt);
    }
    if (this.mana < this.maxMana) {
      this.mana = Math.min(this.maxMana, this.mana + this.manaRegen * dt);
    }
    this.#report();
  }

  /**
   * Rohschaden abziehen. Rüstung, Magieresistenz und Krit kommen in Phase 6
   * davor — die Formel gehört nicht in diese Komponente.
   */
  damage(amount) {
    if (amount <= 0 || !this.isAlive) return 0;
    const applied = Math.min(this.health, amount);
    this.health -= applied;
    this.#report();
    return applied;
  }

  heal(amount) {
    if (amount <= 0 || !this.isAlive) return 0;
    const applied = Math.min(this.maxHealth - this.health, amount);
    this.health += applied;
    this.#report();
    return applied;
  }

  spendMana(amount) {
    if (amount > this.mana) return false;
    this.mana -= amount;
    this.#report();
    return true;
  }

  revive(healthRatio = 1) {
    this.health = this.maxHealth * healthRatio;
    this.mana = this.maxMana;
    this.#report();
  }

  /** Nur melden, wenn sich ein ganzzahliger Wert ändert — spart DOM-Arbeit. */
  #report() {
    if (!this.onChange) return;
    const snapshot = {
      health: Math.round(this.health),
      mana: Math.round(this.mana),
      maxHealth: Math.round(this.maxHealth),
      maxMana: Math.round(this.maxMana),
    };
    const last = this._lastReported;
    if (snapshot.health === last.health && snapshot.mana === last.mana
      && snapshot.maxHealth === last.maxHealth && snapshot.maxMana === last.maxMana) return;
    this._lastReported = snapshot;
    this.onChange(this);
  }

  toJSON() {
    return { health: this.health, mana: this.mana };
  }

  restore(data) {
    if (!data) return;
    this.health = Math.min(this.maxHealth, data.health ?? this.maxHealth);
    this.mana = Math.min(this.maxMana, data.mana ?? this.maxMana);
    this.#report();
  }
}
