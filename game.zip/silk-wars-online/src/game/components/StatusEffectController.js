import { statusEffects } from '../data/statusEffects.js';

/**
 * Buffs und Debuffs einer Entity — eine Komponente pro Belang.
 *
 * Die Gate-Methoden canMove/canAct/canCast sind die einzige Stelle, an der
 * Bewegung und Fähigkeiten fragen, ob sie überhaupt dürfen. Kein System muss
 * einzelne Effekte kennen.
 *
 * Wie der ResourcePool kennt auch dieser Controller den EventBus nicht; er
 * meldet über Callbacks.
 */
export class StatusEffectController {
  #active = new Map();

  constructor({ onChange = null, onTick = null, onImpulse = null } = {}) {
    this.onChange = onChange;
    this.onTick = onTick;
    this.onImpulse = onImpulse;
  }

  apply(effectId, { duration = 3, magnitude = null, source = null, stacks = 1 } = {}) {
    const definition = statusEffects.find(effectId);
    if (!definition) {
      console.warn(`[StatusEffect] Unbekannter Effekt: ${effectId}`);
      return null;
    }

    // Reiner Rückstoß: keine Dauer, sondern ein einmaliger Impuls.
    if (definition.impulse) {
      this.onImpulse?.(definition.impulse, source);
      return null;
    }

    const existing = this.#active.get(effectId);
    if (existing) {
      existing.remaining = Math.max(existing.remaining, duration);
      if (definition.stacking === 'stack') {
        existing.stacks = Math.min(definition.maxStacks ?? 1, existing.stacks + stacks);
      }
      if (magnitude !== null) existing.magnitude = magnitude;
      this.onChange?.(this);
      return existing;
    }

    const effect = {
      id: effectId,
      definition,
      remaining: duration,
      duration,
      magnitude,
      stacks: definition.stacking === 'stack' ? stacks : 1,
      source,
      tickAccumulator: 0,
    };
    this.#active.set(effectId, effect);
    this.onChange?.(this);
    return effect;
  }

  remove(effectId) {
    if (!this.#active.delete(effectId)) return false;
    this.onChange?.(this);
    return true;
  }

  clear() {
    if (this.#active.size === 0) return;
    this.#active.clear();
    this.onChange?.(this);
  }

  has(effectId) {
    return this.#active.has(effectId);
  }

  list() {
    return [...this.#active.values()].map((effect) => ({
      id: effect.id,
      name: effect.definition.name,
      glyph: effect.definition.glyph,
      category: effect.definition.category,
      remaining: effect.remaining,
      duration: effect.duration,
      stacks: effect.stacks,
    }));
  }

  update(dt) {
    if (this.#active.size === 0) return;
    let changed = false;

    for (const effect of [...this.#active.values()]) {
      const dot = effect.definition.dot;
      if (dot) {
        effect.tickAccumulator += dt;
        while (effect.tickAccumulator >= 1) {
          effect.tickAccumulator -= 1;
          this.onTick?.(effect, dot.amount * effect.stacks, dot.school);
        }
      }

      effect.remaining -= dt;
      if (effect.remaining <= 0) {
        this.#active.delete(effect.id);
        changed = true;
      }
    }

    if (changed) this.onChange?.(this);
  }

  // --- Gates ---------------------------------------------------------------

  #blocked(gate) {
    for (const effect of this.#active.values()) {
      if (effect.definition.blocks?.includes(gate)) return true;
    }
    return false;
  }

  canMove() { return !this.#blocked('move'); }
  canAct() { return !this.#blocked('act'); }
  canCast() { return !this.#blocked('cast'); }

  get isInvulnerable() {
    for (const effect of this.#active.values()) {
      if (effect.definition.invulnerable) return true;
    }
    return false;
  }

  // --- Aggregierte Modifikatoren -------------------------------------------

  #sum(key) {
    let total = 0;
    for (const effect of this.#active.values()) {
      const value = effect.definition.modifiers?.[key];
      if (value === undefined) continue;
      // magnitude aus den Fähigkeiten-Daten überschreibt den Standardwert.
      const magnitude = effect.magnitude !== null && effect.magnitude !== undefined
        ? (value < 0 ? -Math.abs(effect.magnitude) : Math.abs(effect.magnitude))
        : value;
      total += magnitude * effect.stacks;
    }
    return total;
  }

  moveSpeedMultiplier() {
    return Math.max(0.1, 1 + this.#sum('moveSpeed'));
  }

  damageTakenMultiplier() {
    return Math.max(0, 1 + this.#sum('damageTaken'));
  }

  damageDealtMultiplier() {
    return Math.max(0, 1 + this.#sum('damageDealt'));
  }

  /** Aktive Waffenverzauberung, falls vorhanden. */
  imbue() {
    for (const effect of this.#active.values()) {
      if (effect.definition.imbue) return effect.definition.imbue;
    }
    return null;
  }

  toJSON() {
    return [...this.#active.values()].map((effect) => ({
      id: effect.id, remaining: effect.remaining, stacks: effect.stacks, magnitude: effect.magnitude,
    }));
  }
}
