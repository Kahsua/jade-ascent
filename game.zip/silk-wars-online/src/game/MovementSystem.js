import { CONFIG } from '../core/Config.js';
import { approach, lerpAngle, smoothing } from '../core/math.js';
import { heightAt, WORLD_HALF } from './Heightfield.js';

/**
 * Bewegung als reine Logik: kein three, keine Meshes.
 *
 * Kollider kommen als einfache Datenliste ({ x, z, radius }) herein, geliefert
 * von der Weltschicht. Ab Phase 6 fragt update() zusätzlich
 * statusEffects.canMove() ab — dafür ist der Gate-Parameter schon vorgesehen.
 */
export class MovementSystem {
  constructor({ colliders = [], config = CONFIG.player, bus = null, dynamic = null } = {}) {
    this.colliders = colliders;
    this.config = config;
    this.bus = bus;
    // Quelle beweglicher Hindernisse (Barrieren). Liefert eine flache Liste.
    this.dynamic = dynamic;
  }

  setColliders(colliders) {
    this.colliders = colliders;
  }

  /**
   * @param {object} state    Entity-Zustand mit position/velocity/facing
   * @param {number} dt       fester Zeitschritt
   * @param {{x:number,z:number}} direction  normalisierte Weltrichtung
   * @param {{canMove?: () => boolean}} [gates]
   */
  update(state, dt, direction, gates = null) {
    const cfg = this.config;

    // Ausweichschritt hat Vorrang: die movement-Komponente einer Fähigkeit
    // legt state.dash an, hier wird daraus Bewegung. Kein Teleport.
    if (state.dash && state.dash.remaining > 0) {
      this.#dash(state, dt, cfg);
      return;
    }

    const blocked = gates?.canMove ? !gates.canMove() : false;
    const wanted = !blocked && direction && (direction.x !== 0 || direction.z !== 0);

    // Slow, Hast und Wurzeln wirken hier — nicht als Sonderfall, sondern als
    // ein Faktor aus dem StatusEffectController.
    // Grundtempo kommt aus der Entity (Monster laufen anders als der Spieler),
    // der Faktor aus dem StatusEffectController.
    const speed = (state.moveSpeed ?? cfg.walkSpeed) * (gates?.moveSpeedMultiplier?.() ?? 1);
    const targetX = wanted ? direction.x * speed : 0;
    const targetZ = wanted ? direction.z * speed : 0;
    const rate = (wanted ? cfg.acceleration : cfg.deceleration) * dt;

    state.velocity.x = approach(state.velocity.x, targetX, rate);
    state.velocity.z = approach(state.velocity.z, targetZ, rate);

    let x = state.position.x + state.velocity.x * dt;
    let z = state.position.z + state.velocity.z * dt;

    ({ x, z } = this.#resolveCollisions(x, z, cfg.radius));

    state.position.x = Math.max(-WORLD_HALF, Math.min(WORLD_HALF, x));
    state.position.z = Math.max(-WORLD_HALF, Math.min(WORLD_HALF, z));
    state.position.y = heightAt(state.position.x, state.position.z);

    state.speed = Math.hypot(state.velocity.x, state.velocity.z);

    if (state.speed > 0.15) {
      const desired = Math.atan2(state.velocity.x, state.velocity.z);
      state.facing = lerpAngle(state.facing, desired, smoothing(cfg.turnRate, dt));
    }

    const moving = state.speed > 0.15;
    if (this.bus && moving !== state._wasMoving) {
      state._wasMoving = moving;
      this.bus.emit('entity:movestate', { id: state.id, moving });
    }
  }

  #dash(state, dt, cfg) {
    const dash = state.dash;
    const step = Math.min(dt, dash.remaining);

    state.velocity.x = dash.x * dash.speed;
    state.velocity.z = dash.z * dash.speed;

    let x = state.position.x + state.velocity.x * step;
    let z = state.position.z + state.velocity.z * step;
    ({ x, z } = this.#resolveCollisions(x, z, cfg.radius));

    state.position.x = Math.max(-WORLD_HALF, Math.min(WORLD_HALF, x));
    state.position.z = Math.max(-WORLD_HALF, Math.min(WORLD_HALF, z));
    state.position.y = heightAt(state.position.x, state.position.z);
    state.speed = Math.hypot(state.velocity.x, state.velocity.z);

    dash.remaining -= dt;
    if (dash.remaining <= 0) {
      state.dash = null;
      state.velocity.x *= 0.25;
      state.velocity.z *= 0.25;
    }
  }

  /** Kreis-gegen-Kreis, Spieler wird aus dem Hindernis herausgeschoben. */
  #resolveCollisions(x, z, radius) {
    const dynamic = this.dynamic?.colliders() ?? null;
    const sets = dynamic && dynamic.length ? [this.colliders, dynamic] : [this.colliders];

    for (const collider of sets.flat()) {
      const dx = x - collider.x;
      const dz = z - collider.z;
      const minDistance = collider.radius + radius;
      const distanceSq = dx * dx + dz * dz;

      if (distanceSq >= minDistance * minDistance || distanceSq === 0) continue;

      const distance = Math.sqrt(distanceSq);
      const push = (minDistance - distance) / distance;
      x += dx * push;
      z += dz * push;
    }
    return { x, z };
  }
}
