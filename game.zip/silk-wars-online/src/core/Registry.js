/**
 * Daten statt Fallunterscheidungen: Klassen, Skills, Monster, Items und
 * Modelle liegen als Datensätze in Registries. Kein if/switch im Code.
 */
export class Registry {
  #entries = new Map();
  #name;

  constructor(name) {
    this.#name = name;
  }

  register(id, data) {
    if (this.#entries.has(id)) {
      console.warn(`[Registry:${this.#name}] "${id}" wird überschrieben.`);
    }
    this.#entries.set(id, data);
    return data;
  }

  registerAll(records) {
    for (const [id, data] of Object.entries(records)) this.register(id, data);
  }

  get(id) {
    if (!this.#entries.has(id)) {
      throw new Error(`[Registry:${this.#name}] Unbekannte ID: "${id}"`);
    }
    return this.#entries.get(id);
  }

  find(id) {
    return this.#entries.get(id) ?? null;
  }

  has(id) {
    return this.#entries.has(id);
  }

  ids() {
    return [...this.#entries.keys()];
  }

  all() {
    return [...this.#entries.values()];
  }

  get size() {
    return this.#entries.size;
  }
}
