/**
 * Zentrale Konfiguration. Regel aus dem Auftrag: keine Balancing- oder
 * Steuerungswerte hart im Code. Alles Justierbare landet hier.
 */
export const CONFIG = {
  world: {
    size: 240,            // Kantenlänge des Terrains in Metern
    segments: 160,        // Auflösung des Terrain-Meshes
    hillHeight: 7.5,      // maximale Hügelamplitude
    spawnFlatRadius: 14,  // ebene Lichtung um den Startpunkt
    edgeMargin: 6,        // unbegehbarer Rand
  },

  player: {
    walkSpeed: 6.2,       // m/s
    acceleration: 46,     // m/s²
    deceleration: 34,     // m/s²
    radius: 0.42,         // Kollisionsradius
    turnRate: 12,         // wie schnell sich die Figur in Laufrichtung dreht
  },

  camera: {
    distance: 9,
    minDistance: 2.4,
    maxDistance: 20,
    zoomSpeed: 0.0125,
    pitch: 0.52,          // Startneigung in Radiant
    minPitch: -0.12,
    maxPitch: 1.24,
    sensitivity: 0.0026,  // Vorzeichen umdrehen = invertierte Maussteuerung
    targetHeight: 1.45,   // Blickpunkt über den Füßen der Figur
    collisionPadding: 0.35,
    followLerp: 16,
  },

  render: {
    fov: 58,
    near: 0.1,
    far: 420,
    shadows: true,
    maxPixelRatio: 2,
    fogNear: 55,
    fogFar: 200,
    skyColor: '#8fb3cc',
  },

  loop: {
    fixedStep: 1 / 60,    // Logik läuft deterministisch, Anzeige interpoliert
    maxStepsPerFrame: 5,
  },

  progression: {
    baseAttribute: 5,
    startPool: 5,
    attributePointsPerLevel: 3,
    masteryPointsPerLevel: 2,
    startMasteryPoints: 5,
    maxLevel: 60,
    // Erfahrung bis zum nächsten Level: base * level^exponent
    experienceCurve: { base: 120, exponent: 1.45 },
  },

  /**
   * Wie aus den vier Primärattributen Kampfwerte werden — Abschnitt 5.2.
   * Stärke -> physischer Schaden, Geschicklichkeit -> Krit (NICHT Schaden),
   * Intelligenz -> Magie und Mana, Vitalität -> Leben, Rüstung, Regeneration.
   * Balancing passiert hier, nicht im Code.
   */
  stats: {
    health: { base: 40, perVitality: 12, perLevel: 8 },
    mana: { base: 30, perIntelligence: 9, perLevel: 4 },
    healthRegen: { base: 0.45, perVitality: 0.12 },
    manaRegen: { base: 0.9, perIntelligence: 0.18 },
    armor: { base: 0, perVitality: 0.8 },
    magicResist: { base: 0, perVitality: 0.5 },
    physicalPower: { base: 10, perStrength: 2.2 },
    magicPower: { base: 8, perIntelligence: 2 },
    critChance: { base: 0.05, perDexterity: 0.006, max: 0.75 },
    critDamage: { base: 1.5, perDexterity: 0.01 },
  },

  targeting: {
    maxSelectRange: 45,   // wie weit Tab greift
    dropRange: 60,        // ab hier verliert man das Ziel wieder
    reticleSegments: 48,
  },

  touch: {
    lookScale: 0.75,     // Finger bewegen die Kamera etwas ruhiger als die Maus
    stickRadius: 52,
  },

  ui: {
    nameplateRange: 34,
    nameplateFadeStart: 24,
  },

  combat: {
    defenseConstant: 100, // effektiverSchaden = roh * 100 / (100 + Verteidigung)
    dodgeCharges: 2,
  },

  debug: {
    overlayVisible: false,
    exposeGlobals: true,  // window.game für die Konsole
  },
};
