import { CONFIG } from './Config.js';

/**
 * Fester Logiktakt, freier Rendertakt.
 *
 * Warum: Kampf, Cooldowns und Statuseffekte sollen ab Phase 5 unabhängig von
 * der Framerate identisch ablaufen. Die Views interpolieren ihre Meshes zum
 * Logikzustand, deshalb wirkt die Darstellung trotzdem flüssig.
 *
 * Events: "update" (fester Schritt, dt konstant) und "render" (echtes dt).
 */
export class GameLoop {
  #bus;
  #step;
  #maxSteps;
  #accumulator = 0;
  #lastTime = 0;
  #rafId = null;
  #running = false;

  constructor(bus, options = {}) {
    this.#bus = bus;
    this.#step = options.fixedStep ?? CONFIG.loop.fixedStep;
    this.#maxSteps = options.maxStepsPerFrame ?? CONFIG.loop.maxStepsPerFrame;
    this.stats = { fps: 0, frameTime: 0, steps: 0 };
  }

  start() {
    if (this.#running) return;
    this.#running = true;
    this.#lastTime = performance.now();
    this.#accumulator = 0;
    this.#rafId = requestAnimationFrame(this.#frame);
  }

  stop() {
    this.#running = false;
    if (this.#rafId !== null) cancelAnimationFrame(this.#rafId);
    this.#rafId = null;
  }

  #frame = (now) => {
    if (!this.#running) return;
    this.#rafId = requestAnimationFrame(this.#frame);

    // Tab-Wechsel oder Haltepunkt: großen Sprung abschneiden statt aufholen.
    const delta = Math.min((now - this.#lastTime) / 1000, 0.25);
    this.#lastTime = now;

    this.#accumulator += delta;
    let steps = 0;
    while (this.#accumulator >= this.#step && steps < this.#maxSteps) {
      this.#bus.emit('update', this.#step);
      this.#accumulator -= this.#step;
      steps += 1;
    }
    if (steps === this.#maxSteps) this.#accumulator = 0;

    this.stats.frameTime = delta * 1000;
    this.stats.fps = delta > 0 ? 1 / delta : 0;
    this.stats.steps = steps;

    this.#bus.emit('render', delta);
  };
}
