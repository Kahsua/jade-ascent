/**
 * Zentraler Event-Emitter. Systeme reden über den Bus, nicht über direkte
 * Referenzen. Ein Fehler in einem Handler darf nie den Frame killen.
 */
export class EventBus {
  #handlers = new Map();

  /** @returns {() => void} Abmelde-Funktion */
  on(event, handler) {
    if (typeof handler !== 'function') throw new TypeError('handler muss eine Funktion sein');
    if (!this.#handlers.has(event)) this.#handlers.set(event, new Set());
    this.#handlers.get(event).add(handler);
    return () => this.off(event, handler);
  }

  once(event, handler) {
    const off = this.on(event, (payload) => {
      off();
      handler(payload);
    });
    return off;
  }

  off(event, handler) {
    const set = this.#handlers.get(event);
    if (!set) return;
    set.delete(handler);
    if (set.size === 0) this.#handlers.delete(event);
  }

  emit(event, payload) {
    const set = this.#handlers.get(event);
    if (!set) return;
    for (const handler of [...set]) {
      try {
        handler(payload);
      } catch (error) {
        console.error(`[EventBus] Handler für "${event}" ist gescheitert:`, error);
      }
    }
  }

  clear(event) {
    if (event) this.#handlers.delete(event);
    else this.#handlers.clear();
  }
}
