import { Registry } from '../core/Registry.js';
import { BODY_TEMPLATES } from './models/bodyTemplates.js';
import { buildRig } from './models/rigs.js';
import { attachments, buildAttachment } from './models/attachments.js';

/**
 * Die einzige Tür zwischen Gameplay und Geometrie.
 *
 * Gameplay-Code sagt: assets.createModel('character.warrior') und
 * assets.equip(model, 'mainHand', 'weapon.greatsword'). Was dahinter liegt —
 * Primitive, ein CC0-Pack, ein GLTF mit Mixamo-Clips — ist austauschbar,
 * solange der Rig-Vertrag aus rigs.js eingehalten wird.
 */
const modelFactories = new Registry('models');
const bodyTemplates = new Registry('bodies');

export const assets = {
  registerModel(id, factory) {
    return modelFactories.register(id, factory);
  },

  registerBody(template) {
    bodyTemplates.register(template.id, template);
    modelFactories.register(template.id, (options = {}) => buildRig(template, options));
    return template;
  },

  createModel(id, options = {}) {
    const model = modelFactories.get(id)(options);
    model.root.userData.modelId = id;
    return model;
  },

  /**
   * Ausrüstung anlegen oder abnehmen.
   * @returns {object|null} Item-Definition (mit pose/grip) oder null
   */
  equip(model, slot, attachmentId) {
    if (!attachmentId) {
      model.setAttachment(slot, null);
      return null;
    }
    const { definition, object } = buildAttachment(attachmentId);
    model.setAttachment(slot, object, definition.transform);
    return definition;
  },

  getAttachmentDefinition(id) {
    return attachments.find(id);
  },

  hasModel(id) {
    return modelFactories.has(id);
  },

  modelIds() {
    return modelFactories.ids();
  },

  attachmentIds() {
    return attachments.ids();
  },

  bodyTemplate(id) {
    return bodyTemplates.find(id);
  },
};

export function registerDefaultModels() {
  for (const template of BODY_TEMPLATES) assets.registerBody(template);
}
