import * as THREE from 'three';
import { Registry } from '../../core/Registry.js';
import { makeNoiseTexture, makeClothTexture, makeMetalTexture } from '../TextureFactory.js';

/**
 * Rig-Bauer: aus einem Körper-Datensatz wird eine Objekt-Hierarchie.
 *
 * Jeder Bauer liefert dieselbe Form zurück — das ist der Vertrag, an den sich
 * auch ein späterer GLTF-Loader halten muss:
 *
 *   { id, kind, animation, root, parts, anchors, slots, materials, height,
 *     setAttachment(slot, object3D|null, transform), getAttachment(slot),
 *     dispose() }
 *
 * Solange diese Form stimmt, merkt weder die Animation noch der spätere
 * Kampf-Code, ob dahinter Primitive oder ein Kenney-/Quaternius-Modell steckt.
 */

export const rigBuilders = new Registry('rigs');

// --- Bau-Helfer ------------------------------------------------------------

/** Gelenk: leere Gruppe als Drehpunkt. */
function joint(parent, x, y, z) {
  const group = new THREE.Group();
  group.position.set(x, y, z);
  parent.add(group);
  return group;
}

/** Glied: Geometrie hängt unterhalb ihres Drehpunkts. */
function bone(parent, geometry, material, length) {
  geometry.translate(0, -length / 2, 0);
  const mesh = new THREE.Mesh(geometry, material);
  mesh.castShadow = true;
  mesh.receiveShadow = true;
  parent.add(mesh);
  return mesh;
}

function block(parent, geometry, material, x = 0, y = 0, z = 0) {
  const mesh = new THREE.Mesh(geometry, material);
  mesh.position.set(x, y, z);
  mesh.castShadow = true;
  mesh.receiveShadow = true;
  parent.add(mesh);
  return mesh;
}

function buildMaterials(palette) {
  const materials = {};
  const cloth = ['tunic', 'trousers'];
  for (const [key, color] of Object.entries(palette)) {
    if (key === 'metal') {
      materials[key] = new THREE.MeshStandardMaterial({ map: makeMetalTexture({ color }), roughness: 0.42, metalness: 0.65 });
    } else if (cloth.includes(key)) {
      materials[key] = new THREE.MeshStandardMaterial({ map: makeClothTexture({ color }), roughness: 0.92 });
    } else {
      materials[key] = new THREE.MeshStandardMaterial({ map: makeNoiseTexture({ color, variance: key === 'hair' ? 18 : 13 }), roughness: 0.88 });
    }
  }
  return materials;
}

/** Gemeinsamer Teil jedes Rigs: Slot-Verwaltung, Aufräumen. */
function finishRig(template, root, parts, anchors, materials, height) {
  const attached = new Map();

  return {
    id: template.id,
    label: template.label ?? template.id,
    kind: template.kind,
    animation: template.animation,
    slots: template.slots ?? {},
    root,
    parts,
    anchors,
    materials,
    height,

    /** Objekt an einen Ausrüstungs-Slot hängen. null entfernt es wieder. */
    setAttachment(slot, object3D, transform = null) {
      const previous = attached.get(slot);
      if (previous) {
        previous.parent?.remove(previous);
        previous.traverse?.((child) => child.geometry?.dispose?.());
        attached.delete(slot);
      }
      if (!object3D) return null;

      const anchorName = this.slots[slot];
      const anchor = anchorName ? anchors[anchorName] : null;
      if (!anchor) {
        console.warn(`[Rig:${template.id}] Kein Anker für Slot "${slot}"`);
        return null;
      }

      if (transform?.position) object3D.position.set(...transform.position);
      if (transform?.rotation) object3D.rotation.set(...transform.rotation);
      if (transform?.scale) object3D.scale.setScalar(transform.scale);

      anchor.add(object3D);
      attached.set(slot, object3D);
      return object3D;
    },

    getAttachment(slot) {
      return attached.get(slot) ?? null;
    },

    attachedSlots() {
      return [...attached.keys()];
    },

    dispose() {
      root.traverse((object) => object.geometry?.dispose?.());
      for (const material of Object.values(materials)) {
        material.map?.dispose();
        material.dispose();
      }
    },
  };
}

// --- Zweibeiner ------------------------------------------------------------

rigBuilders.register('biped', (template) => {
  const p = template.proportions;
  const materials = buildMaterials(template.palette);

  const root = new THREE.Group();
  root.name = template.id;
  root.scale.setScalar(template.scale ?? 1);

  const hips = joint(root, 0, p.hip.y, 0);
  block(hips, new THREE.BoxGeometry(p.hip.width, p.hip.height, p.hip.depth), materials.trousers, 0, 0.03, 0);

  const torso = joint(hips, 0, p.torso.offset, 0);
  block(torso, new THREE.BoxGeometry(p.torso.width, p.torso.height, p.torso.depth), materials.tunic, 0, p.torso.height / 2, 0);
  block(torso, new THREE.BoxGeometry(p.torso.width + 0.02, 0.07, p.torso.depth + 0.02), materials.leather, 0, 0.03, 0);

  const head = joint(torso, 0, p.head.offset, 0);
  block(head, new THREE.CylinderGeometry(0.07, 0.08, p.head.neck, 8), materials.skin, 0, p.head.neck / 2, 0);
  const skull = p.head.size;
  block(head, new THREE.BoxGeometry(skull, skull + 0.02, skull), materials.skin, 0, p.head.neck + skull / 2 + 0.04, 0);
  block(head, new THREE.BoxGeometry(skull + 0.02, 0.09, skull + 0.02), materials.hair, 0, p.head.neck + skull + 0.05, 0);
  block(head, new THREE.BoxGeometry(skull + 0.02, 0.12, 0.05), materials.hair, 0, p.head.neck + skull * 0.75, -skull / 2 - 0.005);
  block(head, new THREE.ConeGeometry(0.035, 0.07, 4), materials.skin, 0, p.head.neck + skull * 0.55, skull / 2 + 0.02).rotation.x = Math.PI / 2;

  const parts = { hips, torso, head };
  const anchors = {
    head,
    chest: joint(torso, 0, p.torso.height * 0.5, 0),
    back: joint(torso, 0, p.torso.height * 0.6, -p.torso.depth / 2 - 0.03),
  };

  for (const [side, sign] of [['L', -1], ['R', 1]]) {
    const shoulder = joint(torso, sign * p.arm.spread, p.arm.shoulderY, 0);
    shoulder.rotation.z = sign * p.arm.splay;
    shoulder.userData.restZ = shoulder.rotation.z;
    bone(shoulder, new THREE.CylinderGeometry(p.arm.thickness, p.arm.thickness * 0.88, p.arm.upper, 8), materials.tunic, p.arm.upper);

    const elbow = joint(shoulder, 0, -p.arm.upper, 0);
    elbow.rotation.x = -0.22;
    bone(elbow, new THREE.CylinderGeometry(p.arm.thickness * 0.85, p.arm.thickness * 0.75, p.arm.lower, 8), materials.skin, p.arm.lower);

    const wrist = joint(elbow, 0, -p.arm.lower, 0);
    block(wrist, new THREE.BoxGeometry(0.1, 0.12, 0.1), materials.leather, 0, -0.06, 0);

    const hand = joint(wrist, 0, -0.11, 0.02);
    hand.name = `hand${side}`;

    parts[`shoulder${side}`] = shoulder;
    parts[`elbow${side}`] = elbow;
    parts[`wrist${side}`] = wrist;
    anchors[`hand${side}`] = hand;
  }

  for (const [side, sign] of [['L', -1], ['R', 1]]) {
    const hip = joint(hips, sign * p.leg.spread, -0.02, 0);
    bone(hip, new THREE.CylinderGeometry(p.leg.thickness, p.leg.thickness * 0.86, p.leg.upper, 8), materials.trousers, p.leg.upper);

    const knee = joint(hip, 0, -p.leg.upper, 0);
    bone(knee, new THREE.CylinderGeometry(p.leg.thickness * 0.86, p.leg.thickness * 0.72, p.leg.lower, 8), materials.trousers, p.leg.lower);

    const ankle = joint(knee, 0, -p.leg.lower, 0);
    block(ankle, new THREE.BoxGeometry(0.13, 0.09, 0.26), materials.leather, 0, -0.045, 0.04);

    parts[`hip${side}`] = hip;
    parts[`knee${side}`] = knee;
    parts[`ankle${side}`] = ankle;
  }

  const height = (p.hip.y + p.torso.offset + p.head.offset + p.head.neck + p.head.size + 0.1) * (template.scale ?? 1);
  return finishRig(template, root, parts, anchors, materials, height);
});

// --- Vierbeiner ------------------------------------------------------------

rigBuilders.register('quadruped', (template) => {
  const p = template.proportions;
  const materials = buildMaterials(template.palette);

  const root = new THREE.Group();
  root.name = template.id;
  root.scale.setScalar(template.scale ?? 1);

  const body = joint(root, 0, p.body.y, 0);
  block(body, new THREE.BoxGeometry(p.body.width, p.body.height, p.body.length), materials.fur);
  block(body, new THREE.BoxGeometry(p.body.width * 0.92, p.body.height * 0.5, p.body.length * 0.5), materials.furDark, 0, p.body.height * 0.26, -0.05);

  const neck = joint(body, 0, p.body.height * 0.22, p.body.length / 2 - 0.05);
  neck.rotation.x = -0.35;
  bone(neck, new THREE.CylinderGeometry(0.15, 0.17, 0.26, 7), materials.fur, -0.26);

  const head = joint(neck, 0, 0.24, 0.06);
  head.rotation.x = 0.35;
  const skull = p.head.size;
  block(head, new THREE.BoxGeometry(skull, skull * 0.85, skull * 1.05), materials.fur, 0, 0, 0.06);
  block(head, new THREE.BoxGeometry(skull * 0.55, skull * 0.45, p.head.snout), materials.furDark, 0, -0.04, skull * 0.5 + p.head.snout / 2);
  block(head, new THREE.SphereGeometry(0.035, 6, 5), materials.skin, 0, -0.02, skull * 0.5 + p.head.snout);
  for (const sign of [-1, 1]) {
    block(head, new THREE.ConeGeometry(0.065, 0.16, 4), materials.furDark, sign * 0.09, skull * 0.5, 0.02);
  }

  const parts = { body, neck, head };
  const anchors = { head, back: joint(body, 0, p.body.height / 2, -0.1) };

  for (const [name, sx, sz] of [['FL', -1, 1], ['FR', 1, 1], ['BL', -1, -1], ['BR', 1, -1]]) {
    const hip = joint(body, sx * p.leg.spreadX, -p.body.height / 2 + 0.03, sz * p.leg.spreadZ);
    bone(hip, new THREE.CylinderGeometry(p.leg.thickness, p.leg.thickness * 0.85, p.leg.upper, 7), materials.fur, p.leg.upper);

    const knee = joint(hip, 0, -p.leg.upper, 0);
    knee.rotation.x = sz > 0 ? 0.2 : -0.25; // Vorder-/Hinterbeine unterschiedlich geknickt
    knee.userData.restX = knee.rotation.x;
    bone(knee, new THREE.CylinderGeometry(p.leg.thickness * 0.8, p.leg.thickness * 0.65, p.leg.lower, 7), materials.furDark, p.leg.lower);

    const paw = joint(knee, 0, -p.leg.lower, 0);
    block(paw, new THREE.BoxGeometry(0.12, 0.07, 0.18), materials.furDark, 0, -0.035, 0.02);

    parts[`leg${name}`] = hip;
    parts[`knee${name}`] = knee;
    parts[`paw${name}`] = paw;
  }

  let tailParent = joint(body, 0, p.body.height * 0.3, -p.body.length / 2);
  parts.tail = [];
  for (let i = 0; i < p.tail.segments; i += 1) {
    tailParent.rotation.x = 0.7;
    bone(tailParent, new THREE.CylinderGeometry(p.tail.thickness * (1 - i * 0.25), p.tail.thickness * (0.8 - i * 0.25), p.tail.length, 6), materials.furDark, p.tail.length);
    parts.tail.push(tailParent);
    tailParent = joint(tailParent, 0, -p.tail.length, 0);
  }

  const height = (p.body.y + p.body.height / 2 + 0.35) * (template.scale ?? 1);
  return finishRig(template, root, parts, anchors, materials, height);
});

export function buildRig(template, options = {}) {
  const merged = options.palette
    ? { ...template, palette: { ...template.palette, ...options.palette } }
    : template;
  return rigBuilders.get(template.kind)({ ...merged, scale: options.scale ?? template.scale });
}
