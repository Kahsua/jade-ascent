import * as THREE from 'three';
import { Registry } from '../../core/Registry.js';
import { makeMetalTexture, makeNoiseTexture, makeBarkTexture } from '../TextureFactory.js';

/**
 * Ausrüstungs-Meshes als eigene Objekte, die an Rig-Anker gehängt werden.
 *
 * Jeder Eintrag ist ein Datensatz:
 *   build()   -> Object3D, Griff liegt im Ursprung, Klinge zeigt nach +Y
 *   transform -> Position/Rotation am Anker
 *   pose      -> wie die Arme das Ding halten (fließt in den Animator)
 *   grip      -> ein-/beidhändig; Phase 9 prüft damit Slot-Kompatibilität
 *
 * Ein neues Item ist ein neuer Eintrag. Kein Kampf- oder Animationscode wird
 * dafür angefasst.
 */
export const attachments = new Registry('attachments');

// Materialien einmal bauen und teilen — prozedurale Texturen sind nicht gratis.
let shared = null;
function materials() {
  if (shared) return shared;
  shared = {
    steel: new THREE.MeshStandardMaterial({ map: makeMetalTexture({ color: '#b9c0c7' }), roughness: 0.35, metalness: 0.75 }),
    darkSteel: new THREE.MeshStandardMaterial({ map: makeMetalTexture({ color: '#7c848c' }), roughness: 0.5, metalness: 0.6 }),
    gold: new THREE.MeshStandardMaterial({ map: makeMetalTexture({ color: '#c39a3f' }), roughness: 0.38, metalness: 0.8 }),
    wood: new THREE.MeshStandardMaterial({ map: makeBarkTexture({ color: '#6b4a2c' }), roughness: 0.9 }),
    leather: new THREE.MeshStandardMaterial({ map: makeNoiseTexture({ color: '#4a3524', variance: 14 }), roughness: 0.92 }),
    cord: new THREE.MeshStandardMaterial({ color: '#d9d2c0', roughness: 0.95 }),
    gem: new THREE.MeshStandardMaterial({ color: '#4fd6c0', emissive: '#1d6f63', roughness: 0.25, metalness: 0.2, flatShading: true }),
  };
  return shared;
}

function mesh(parent, geometry, material, x = 0, y = 0, z = 0) {
  const object = new THREE.Mesh(geometry, material);
  object.position.set(x, y, z);
  object.castShadow = true;
  parent.add(object);
  return object;
}

/** Klingenwaffe aus Knauf, Griff, Parierstange, Klinge und Spitze. */
function bladeWeapon({ grip = 0.16, guard = 0.24, blade = 0.62, width = 0.09, metal = 'steel' }) {
  const m = materials();
  const group = new THREE.Group();

  mesh(group, new THREE.SphereGeometry(width * 0.42, 6, 5), m.gold, 0, -0.02);
  mesh(group, new THREE.CylinderGeometry(width * 0.3, width * 0.32, grip, 6), m.leather, 0, grip / 2);
  mesh(group, new THREE.BoxGeometry(guard, 0.05, width * 0.7), m.gold, 0, grip + 0.025);
  mesh(group, new THREE.BoxGeometry(width, blade, width * 0.3), m[metal], 0, grip + 0.05 + blade / 2);
  mesh(group, new THREE.ConeGeometry(width * 0.56, width * 1.5, 4), m[metal], 0, grip + 0.05 + blade + width * 0.72).rotation.y = Math.PI / 4;

  return group;
}

attachments.register('weapon.sword', {
  label: 'Kurzschwert',
  grip: 'one_hand',
  build: () => bladeWeapon({}),
  transform: { rotation: [-0.18, 0, 0.06] },
  pose: { mainArm: { x: -0.12, z: 0.06, elbow: -0.35, swing: 0.55 } },
});

attachments.register('weapon.dagger', {
  label: 'Dolch',
  grip: 'one_hand',
  build: () => bladeWeapon({ grip: 0.1, guard: 0.14, blade: 0.26, width: 0.06 }),
  transform: { rotation: [-0.25, 0, 0.05] },
  pose: { mainArm: { x: -0.05, z: 0.04, elbow: -0.5, swing: 0.7 } },
});

attachments.register('weapon.greatsword', {
  label: 'Großschwert',
  grip: 'two_hand',
  build: () => bladeWeapon({ grip: 0.3, guard: 0.36, blade: 1.12, width: 0.13, metal: 'darkSteel' }),
  transform: { rotation: [-0.5, 0, 0.12] },
  pose: {
    mainArm: { x: -0.85, z: 0.12, elbow: -0.75, swing: 0.25 },
    offArm: { x: -0.95, z: -0.32, y: 0.35, elbow: -0.95, swing: 0.25 },
  },
});

attachments.register('weapon.spear', {
  label: 'Speer',
  grip: 'two_hand',
  build: () => {
    const m = materials();
    const group = new THREE.Group();
    mesh(group, new THREE.CylinderGeometry(0.026, 0.03, 1.9, 7), m.wood, 0, 0.55);
    mesh(group, new THREE.CylinderGeometry(0.04, 0.04, 0.1, 7), m.gold, 0, 1.45);
    mesh(group, new THREE.ConeGeometry(0.055, 0.3, 4), m.steel, 0, 1.65).rotation.y = Math.PI / 4;
    mesh(group, new THREE.CylinderGeometry(0.034, 0.034, 0.18, 6), m.leather, 0, 0.05);
    return group;
  },
  transform: { rotation: [-0.12, 0, 0.05] },
  pose: {
    mainArm: { x: -0.45, z: 0.1, elbow: -0.6, swing: 0.35 },
    offArm: { x: -0.7, z: -0.25, y: 0.2, elbow: -0.7, swing: 0.35 },
  },
});

attachments.register('weapon.bow', {
  label: 'Jagdbogen',
  grip: 'two_hand',
  build: () => {
    const m = materials();
    const group = new THREE.Group();
    const arc = 2.4;
    const radius = 0.5;

    // Eigene Ausrichtungs-Gruppe: transform.rotation aus der Item-Definition
    // wirkt auf die äußere Gruppe und darf diese Drehung nicht überschreiben.
    const oriented = new THREE.Group();
    oriented.rotation.y = -Math.PI / 2; // Wölbung nach vorne
    group.add(oriented);

    // Griff in den Ursprung schieben, Sehne zeigt zum Schützen.
    const limbs = new THREE.Group();
    limbs.position.x = -radius;
    oriented.add(limbs);

    const torus = new THREE.Mesh(new THREE.TorusGeometry(radius, 0.026, 5, 14, arc), m.wood);
    torus.rotation.z = -arc / 2;
    torus.castShadow = true;
    limbs.add(torus);

    const chordX = radius * Math.cos(arc / 2);
    const chordLength = 2 * radius * Math.sin(arc / 2);
    mesh(limbs, new THREE.CylinderGeometry(0.007, 0.007, chordLength, 4), m.cord, chordX, 0);
    mesh(oriented, new THREE.CylinderGeometry(0.032, 0.032, 0.2, 6), m.leather, 0, 0);

    return group;
  },
  transform: { rotation: [0.1, 0, 0] },
  pose: {
    mainArm: { x: -1.42, z: 0.22, elbow: -0.12, swing: 0.15 },
    offArm: { x: -1.15, z: -0.15, y: -0.25, elbow: -1.15, swing: 0.15 },
  },
});

attachments.register('weapon.staff', {
  label: 'Zauberstab',
  grip: 'two_hand',
  build: () => {
    const m = materials();
    const group = new THREE.Group();
    mesh(group, new THREE.CylinderGeometry(0.028, 0.034, 1.7, 7), m.wood, 0, 0.5);
    mesh(group, new THREE.CylinderGeometry(0.038, 0.038, 0.12, 6), m.leather, 0, 0.02);
    mesh(group, new THREE.TorusGeometry(0.09, 0.018, 5, 10), m.gold, 0, 1.34).rotation.x = Math.PI / 2;
    mesh(group, new THREE.IcosahedronGeometry(0.075, 0), m.gem, 0, 1.34);
    return group;
  },
  transform: { rotation: [-0.06, 0, 0.04] },
  pose: {
    mainArm: { x: -0.32, z: 0.14, elbow: -0.45, swing: 0.4 },
  },
});

attachments.register('shield.round', {
  label: 'Rundschild',
  grip: 'off_hand',
  build: () => {
    const m = materials();
    const group = new THREE.Group();
    const disc = mesh(group, new THREE.CylinderGeometry(0.3, 0.3, 0.05, 10), m.wood, 0, 0);
    disc.rotation.x = Math.PI / 2;
    const rim = mesh(group, new THREE.TorusGeometry(0.3, 0.028, 5, 12), m.darkSteel, 0, 0);
    rim.rotation.x = 0;
    mesh(group, new THREE.SphereGeometry(0.08, 7, 6), m.steel, 0, 0, 0.045);
    return group;
  },
  transform: { position: [0, -0.06, 0.12], rotation: [1.35, 0, 0] },
  pose: { offArm: { x: -0.55, z: -0.42, elbow: -1.35, swing: 0.25 } },
});

// --- Rüstung ---------------------------------------------------------------

function helmet({ metal = 'leather', crest = false }) {
  const m = materials();
  const group = new THREE.Group();
  const shell = m[metal] ?? m.leather;

  mesh(group, new THREE.SphereGeometry(0.16, 8, 5, 0, Math.PI * 2, 0, Math.PI * 0.62), shell, 0, 0.05);
  mesh(group, new THREE.CylinderGeometry(0.17, 0.175, 0.05, 8), shell, 0, -0.02);
  mesh(group, new THREE.BoxGeometry(0.2, 0.03, 0.12), shell, 0, -0.01, 0.11);
  if (crest) mesh(group, new THREE.BoxGeometry(0.03, 0.09, 0.24), m.gold, 0, 0.15, 0);
  return group;
}

function cuirass({ metal = 'leather', trim = false }) {
  const m = materials();
  const group = new THREE.Group();
  const shell = m[metal] ?? m.leather;

  mesh(group, new THREE.BoxGeometry(0.5, 0.38, 0.32), shell, 0, 0, 0);
  mesh(group, new THREE.SphereGeometry(0.12, 7, 5), shell, -0.27, 0.14, 0);
  mesh(group, new THREE.SphereGeometry(0.12, 7, 5), shell, 0.27, 0.14, 0);
  if (trim) mesh(group, new THREE.BoxGeometry(0.52, 0.05, 0.34), m.gold, 0, -0.16, 0);
  return group;
}

attachments.register('armor.helm', {
  label: 'Lederkappe', grip: 'armor',
  build: () => helmet({ metal: 'leather' }),
  transform: { position: [0, 0.3, 0] },
});

attachments.register('armor.helm.iron', {
  label: 'Eisenhelm', grip: 'armor',
  build: () => helmet({ metal: 'darkSteel', crest: true }),
  transform: { position: [0, 0.3, 0] },
});

attachments.register('armor.chest', {
  label: 'Lederwams', grip: 'armor',
  build: () => cuirass({ metal: 'leather' }),
  transform: { position: [0, 0, 0] },
});

attachments.register('armor.chest.iron', {
  label: 'Eisenpanzer', grip: 'armor',
  build: () => cuirass({ metal: 'darkSteel', trim: true }),
  transform: { position: [0, 0, 0] },
});

export function buildAttachment(id) {
  const definition = attachments.get(id);
  return { definition, object: definition.build() };
}
