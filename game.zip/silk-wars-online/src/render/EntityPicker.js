import * as THREE from 'three';
import { heightAt } from '../game/Heightfield.js';

/**
 * Maus -> Welt. Die einzige Stelle, an der für das Zielen geraycastet wird.
 *
 * Zwei Fragen, zwei Methoden: Welche Entity liegt unter dem Zeiger? Und auf
 * welchen Bodenpunkt zeigt er? Beides liefert nur Daten zurück — die
 * Entscheidung, was damit passiert, trifft die Logikschicht.
 */
export class EntityPicker {
  #raycaster = new THREE.Raycaster();
  #pointer = new THREE.Vector2();
  #plane = new THREE.Plane();
  #point = new THREE.Vector3();

  constructor({ camera, viewManager, terrain }) {
    this.camera = camera;
    this.viewManager = viewManager;
    this.terrain = terrain;
  }

  #cast(pointer) {
    this.#pointer.set(pointer.x, pointer.y);
    this.#raycaster.setFromCamera(this.#pointer, this.camera);
    return this.#raycaster;
  }

  /** @returns {string|null} Entity-ID unter dem Zeiger */
  pickEntity(pointer) {
    const roots = this.viewManager.entries().map((entry) => entry.view.root);
    if (roots.length === 0) return null;

    const hits = this.#cast(pointer).intersectObjects(roots, true);
    for (const hit of hits) {
      let node = hit.object;
      while (node) {
        if (node.userData?.entityId) return node.userData.entityId;
        node = node.parent;
      }
    }
    return null;
  }

  /**
   * Bodenpunkt unter dem Zeiger.
   *
   * Erst der genaue Weg über das Terrain-Mesh. Zeigt die Maus über den
   * Horizont hinaus, trifft der Strahl kein Terrain — dann fällt die Methode
   * auf eine waagerechte Ebene in Spielerhöhe zurück, damit der Indikator
   * nicht verschwindet, sondern einfach an der Reichweitengrenze klebt.
   */
  pickGround(pointer, fallbackHeight = 0) {
    const raycaster = this.#cast(pointer);
    const hits = raycaster.intersectObject(this.terrain, false);
    if (hits.length > 0) {
      const { x, z } = hits[0].point;
      return { x, y: hits[0].point.y, z };
    }

    this.#plane.set(new THREE.Vector3(0, 1, 0), -fallbackHeight);
    const point = raycaster.ray.intersectPlane(this.#plane, this.#point);
    if (!point) return null;
    return { x: point.x, y: heightAt(point.x, point.z), z: point.z };
  }
}
