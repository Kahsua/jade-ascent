import * as THREE from 'three';
import { CONFIG } from '../core/Config.js';
import { heightAt } from '../game/Heightfield.js';

const FACTION_COLORS = {
  hostile: '#d2543f',
  neutral: '#d8b44a',
  player: '#57c79a',
};

function ringMesh(inner, outer, color, opacity = 0.75) {
  const geometry = new THREE.RingGeometry(inner, outer, CONFIG.targeting.reticleSegments);
  geometry.rotateX(-Math.PI / 2);
  const material = new THREE.MeshBasicMaterial({
    color,
    transparent: true,
    opacity,
    side: THREE.DoubleSide,
    depthWrite: false,
  });
  const mesh = new THREE.Mesh(geometry, material);
  mesh.renderOrder = 2;
  return mesh;
}

/** Ring unter dem ausgewählten Ziel, Farbe nach Fraktion. */
export class SelectionRing {
  constructor(scene) {
    this.group = new THREE.Group();
    this.group.visible = false;

    this.ring = ringMesh(0.52, 0.62, FACTION_COLORS.neutral);
    this.tick = ringMesh(0.66, 0.78, FACTION_COLORS.neutral, 0.4);
    this.group.add(this.ring, this.tick);

    scene.add(this.group);
    this.entity = null;
  }

  attach(entity) {
    this.entity = entity;
    this.group.visible = Boolean(entity);
    if (!entity) return;

    const color = new THREE.Color(FACTION_COLORS[entity.template.faction] ?? FACTION_COLORS.neutral);
    this.ring.material.color = color;
    this.tick.material.color = color;
  }

  update(dt) {
    if (!this.entity) return;
    const { x, z } = this.entity.position;
    this.group.position.set(x, heightAt(x, z) + 0.06, z);
    this.tick.rotation.y += dt * 0.9;
  }
}

/**
 * Boden-Indikator für Flächenfähigkeiten: äußerer Reichweitenring um den
 * Spieler, innerer Wirkungsradius am Mauspunkt. Er wird gestutzt, sobald die
 * Maus die Maximalreichweite überschreitet — das ist die sichtbare Hälfte der
 * Regel aus dem Auftrag.
 */
export class GroundReticle {
  constructor(scene) {
    this.group = new THREE.Group();
    this.group.visible = false;

    this.area = ringMesh(0.1, 1, '#57c79a', 0.55);
    this.fill = ringMesh(0, 1, '#57c79a', 0.14);
    this.group.add(this.area, this.fill);

    this.rangeRing = ringMesh(1, 1.06, '#e9e4d6', 0.22);
    this.rangeRing.visible = false;

    scene.add(this.group);
    scene.add(this.rangeRing);
    this.radius = 1;
  }

  begin({ radius, range }) {
    this.radius = radius ?? 1;
    this.group.scale.setScalar(this.radius);
    this.rangeRing.scale.setScalar(range ?? 1);
    this.group.visible = true;
    this.rangeRing.visible = true;
  }

  end() {
    this.group.visible = false;
    this.rangeRing.visible = false;
  }

  update(point, ownerPosition, clamped) {
    if (!this.group.visible || !point) return;

    this.group.position.set(point.x, heightAt(point.x, point.z) + 0.07, point.z);
    const color = clamped ? '#d8b44a' : '#57c79a';
    this.area.material.color.set(color);
    this.fill.material.color.set(color);

    this.rangeRing.position.set(ownerPosition.x, heightAt(ownerPosition.x, ownerPosition.z) + 0.05, ownerPosition.z);
  }
}
