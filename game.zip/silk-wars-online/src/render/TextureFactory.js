import * as THREE from 'three';

/**
 * Prozedurale Texturen über Canvas — keine Bilddateien, kein Ladepfad,
 * GitHub-Pages-tauglich. Ab Phase 2 kann die AssetRegistry hier
 * stattdessen echte Texturen einhängen, ohne dass Gameplay-Code es merkt.
 */

function createContext(size) {
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  return canvas.getContext('2d', { willReadFrequently: true });
}

function hexToRgb(hex) {
  const value = parseInt(hex.replace('#', ''), 16);
  return { r: (value >> 16) & 255, g: (value >> 8) & 255, b: value & 255 };
}

function addNoise(ctx, size, variance) {
  const image = ctx.getImageData(0, 0, size, size);
  const data = image.data;
  for (let i = 0; i < data.length; i += 4) {
    const jitter = (Math.random() - 0.5) * variance * 2;
    data[i] = Math.max(0, Math.min(255, data[i] + jitter));
    data[i + 1] = Math.max(0, Math.min(255, data[i + 1] + jitter));
    data[i + 2] = Math.max(0, Math.min(255, data[i + 2] + jitter));
  }
  ctx.putImageData(image, 0, 0);
}

function finish(ctx, { repeat = 1, pixelated = true } = {}) {
  const texture = new THREE.CanvasTexture(ctx.canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  texture.repeat.set(repeat, repeat);
  if (pixelated) texture.magFilter = THREE.NearestFilter;
  texture.anisotropy = 4;
  texture.needsUpdate = true;
  return texture;
}

/** Gesprenkelter Untergrund mit dunkleren Flecken. */
export function makeGroundTexture({ size = 256, repeat = 34 } = {}) {
  const ctx = createContext(size);
  ctx.fillStyle = '#5c7a3f';
  ctx.fillRect(0, 0, size, size);

  for (let i = 0; i < 220; i += 1) {
    const shade = Math.random() < 0.5 ? '#4c6a35' : '#6b8a48';
    ctx.fillStyle = shade;
    const radius = 3 + Math.random() * 14;
    ctx.beginPath();
    ctx.arc(Math.random() * size, Math.random() * size, radius, 0, Math.PI * 2);
    ctx.fill();
  }

  // Einzelne Erdstellen, damit große Flächen nicht wie ein Filzteppich wirken.
  for (let i = 0; i < 26; i += 1) {
    ctx.fillStyle = 'rgba(107, 84, 54, 0.55)';
    ctx.beginPath();
    ctx.ellipse(Math.random() * size, Math.random() * size, 6 + Math.random() * 16, 4 + Math.random() * 10, Math.random() * Math.PI, 0, Math.PI * 2);
    ctx.fill();
  }

  addNoise(ctx, size, 14);
  return finish(ctx, { repeat, pixelated: false });
}

/** Grundfläche mit leichtem Rauschen — Haut, Leder, Fels. */
export function makeNoiseTexture({ color = '#c58c5f', variance = 16, size = 64, repeat = 1 } = {}) {
  const ctx = createContext(size);
  ctx.fillStyle = color;
  ctx.fillRect(0, 0, size, size);
  addNoise(ctx, size, variance);
  return finish(ctx, { repeat });
}

/** Stoff: Rauschen plus angedeutete Webstruktur. */
export function makeClothTexture({ color = '#3f6f5a', size = 64, repeat = 1 } = {}) {
  const ctx = createContext(size);
  ctx.fillStyle = color;
  ctx.fillRect(0, 0, size, size);

  const { r, g, b } = hexToRgb(color);
  ctx.strokeStyle = `rgba(${Math.max(0, r - 26)}, ${Math.max(0, g - 26)}, ${Math.max(0, b - 26)}, 0.5)`;
  ctx.lineWidth = 1;
  for (let i = 0; i < size; i += 4) {
    ctx.beginPath();
    ctx.moveTo(0, i + 0.5);
    ctx.lineTo(size, i + 0.5);
    ctx.moveTo(i + 0.5, 0);
    ctx.lineTo(i + 0.5, size);
    ctx.stroke();
  }

  addNoise(ctx, size, 9);
  return finish(ctx, { repeat });
}

/** Metall: senkrechte Schlieren, damit Licht daran „entlangläuft". */
export function makeMetalTexture({ color = '#9aa4ad', size = 64, repeat = 1 } = {}) {
  const ctx = createContext(size);
  ctx.fillStyle = color;
  ctx.fillRect(0, 0, size, size);

  for (let x = 0; x < size; x += 1) {
    const alpha = Math.random() * 0.22;
    ctx.fillStyle = Math.random() < 0.5 ? `rgba(255,255,255,${alpha})` : `rgba(0,0,0,${alpha})`;
    ctx.fillRect(x, 0, 1, size);
  }

  addNoise(ctx, size, 6);
  return finish(ctx, { repeat });
}

/** Rinde: senkrechte Furchen. */
export function makeBarkTexture({ color = '#5a4230', size = 64, repeat = 1 } = {}) {
  const ctx = createContext(size);
  ctx.fillStyle = color;
  ctx.fillRect(0, 0, size, size);

  for (let i = 0; i < 26; i += 1) {
    ctx.fillStyle = Math.random() < 0.5 ? 'rgba(0,0,0,0.22)' : 'rgba(255,255,255,0.08)';
    const x = Math.random() * size;
    ctx.fillRect(x, 0, 1 + Math.random() * 2, size);
  }

  addNoise(ctx, size, 12);
  return finish(ctx, { repeat });
}
