import * as THREE from 'three';

/**
 * Schadens- und Heilzahlen als HTML über der Trefferstelle.
 *
 * Die Zahl wird beim Entstehen einmal auf den Bildschirm projiziert und
 * treibt dann per CSS nach oben — das kostet nichts und liest sich besser als
 * eine Zahl, die an einer laufenden Figur klebt.
 */
export class FloatingTextLayer {
  #vector = new THREE.Vector3();

  constructor({ container, camera, entities, bus }) {
    this.container = container;
    this.camera = camera;
    this.entities = entities;

    bus.on('entity:damaged', ({ id, amount, critical, overTime }) => {
      if (amount <= 0) return;
      const tone = critical ? 'crit' : (overTime ? 'dot' : 'damage');
      this.#spawn(id, `${critical ? '' : ''}-${Math.round(amount)}`, tone);
    });

    bus.on('entity:immune', ({ id }) => this.#spawn(id, 'immun', 'immune'));

    bus.on('entity:healed', ({ id, amount }) => {
      if (amount <= 0) return;
      this.#spawn(id, `+${Math.round(amount)}`, 'heal');
    });
  }

  #spawn(entityId, text, tone) {
    const entity = this.entities.get(entityId);
    if (!entity) return;

    this.#vector.set(
      entity.position.x + (Math.random() - 0.5) * 0.6,
      entity.position.y + 1.9,
      entity.position.z + (Math.random() - 0.5) * 0.6,
    );
    this.#vector.project(this.camera);
    if (this.#vector.z > 1) return;

    const element = document.createElement('span');
    element.className = `floater floater-${tone}`;
    element.textContent = text;
    element.style.left = `${(this.#vector.x * 0.5 + 0.5) * window.innerWidth}px`;
    element.style.top = `${(-this.#vector.y * 0.5 + 0.5) * window.innerHeight}px`;
    this.container.appendChild(element);

    setTimeout(() => element.remove(), 950);
  }
}
