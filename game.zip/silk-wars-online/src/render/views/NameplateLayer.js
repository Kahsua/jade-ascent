import * as THREE from 'three';
import { CONFIG } from '../../core/Config.js';

/**
 * Namensschilder und Lebensbalken über den Figuren.
 *
 * Bewusst HTML statt In-World-Geometrie: gestochen scharfe Schrift, und in
 * Phase 4 wird derselbe Marker zum Ziel-Rahmen erweitert. Der Layer projiziert
 * nur Weltpositionen auf Bildschirmkoordinaten — er kennt keine Spielregeln.
 */
export class NameplateLayer {
  #plates = new Map();
  #vector = new THREE.Vector3();

  constructor({ container, camera, bus, exclude = null }) {
    this.container = container;
    this.camera = camera;
    this.exclude = exclude;
    this.entities = new Map();

    bus.on('entity:spawned', (entity) => this.add(entity));
    bus.on('entity:removed', (entity) => this.remove(entity.id));
    bus.on('entity:resources', (payload) => this.#updateBar(payload));
    bus.on('entity:died', ({ id }) => this.#plates.get(id)?.root.classList.add('is-dead'));
    bus.on('entity:revived', ({ id }) => this.#plates.get(id)?.root.classList.remove('is-dead'));
  }

  add(entity) {
    if (entity.id === this.exclude) return;

    const root = document.createElement('div');
    root.className = 'nameplate';
    root.innerHTML = `
      <span class="nameplate-name">${entity.state.name} <span class="nameplate-level">Stufe ${entity.state.level}</span></span>
      <span class="nameplate-bar"><i style="width:100%"></i></span>`;
    this.container.appendChild(root);

    this.#plates.set(entity.id, { root, fill: root.querySelector('i'), entity });
    this.entities.set(entity.id, entity);
  }

  remove(id) {
    const plate = this.#plates.get(id);
    if (!plate) return;
    plate.root.remove();
    this.#plates.delete(id);
    this.entities.delete(id);
  }

  #updateBar({ id, healthRatio }) {
    const plate = this.#plates.get(id);
    if (!plate) return;
    plate.fill.style.width = `${Math.max(0, healthRatio * 100).toFixed(1)}%`;
    plate.root.classList.toggle('is-hurt', healthRatio < 0.999);
  }

  update() {
    const { nameplateRange, nameplateFadeStart } = CONFIG.ui;
    const halfWidth = window.innerWidth / 2;
    const halfHeight = window.innerHeight / 2;

    for (const { root, entity } of this.#plates.values()) {
      const height = entity.template.plateHeight ?? 2.1;
      this.#vector.set(entity.position.x, entity.position.y + height, entity.position.z);
      const distance = this.#vector.distanceTo(this.camera.position);

      if (distance > nameplateRange) {
        root.style.display = 'none';
        continue;
      }

      this.#vector.project(this.camera);
      if (this.#vector.z > 1) {
        root.style.display = 'none';
        continue;
      }

      root.style.display = 'block';
      root.style.transform = `translate(-50%, -100%) translate(${(this.#vector.x * halfWidth + halfWidth).toFixed(1)}px, ${(-this.#vector.y * halfHeight + halfHeight).toFixed(1)}px)`;
      root.style.opacity = distance > nameplateFadeStart
        ? (1 - (distance - nameplateFadeStart) / (nameplateRange - nameplateFadeStart)).toFixed(2)
        : '1';
    }
  }
}
