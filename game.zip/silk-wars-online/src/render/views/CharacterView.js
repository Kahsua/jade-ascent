import * as THREE from 'three';
import { CONFIG } from '../../core/Config.js';
import { lerpAngle, smoothing } from '../../core/math.js';
import { AnimationController } from '../animation/AnimationController.js';
import { ABILITY_CLIPS } from '../animation/clips.js';
import { WeaponTrail } from './WeaponTrail.js';
import { assets } from '../AssetRegistry.js';

/**
 * Brücke zwischen Logikzustand und Mesh — für Spieler, NPCs und ab Phase 7
 * auch Monster. Der View kennt nur { position, facing, speed }.
 *
 * Die Logik läuft im festen 60-Hz-Takt, gerendert wird mit Monitorrate; der
 * View interpoliert deshalb, statt Werte hart zu setzen.
 */
export class CharacterView {
  constructor(modelId, options = {}) {
    this.model = assets.createModel(modelId, options);
    this.root = this.model.root;
    this.animator = new AnimationController(this.model);
    this.trail = options.scene ? new WeaponTrail(options.scene) : null;
    this.equipped = new Map();

    this._facing = 0;
    this._target = new THREE.Vector3();
    this._snapped = false;
    this.dead = false;
    this.maxSpeed = options.maxSpeed ?? CONFIG.player.walkSpeed;
  }

  /**
   * Ausrüstung sichtbar machen. Die Armhaltung folgt aus den Item-Daten,
   * nicht aus einer Fallunterscheidung im Animator.
   */
  equip(slot, attachmentId) {
    const definition = assets.equip(this.model, slot, attachmentId);
    if (definition) this.equipped.set(slot, { id: attachmentId, definition });
    else this.equipped.delete(slot);

    // Die Schwungspur hängt an der Waffe in der Haupthand.
    if (slot === 'mainHand' && this.trail) {
      this.trail.attach(this.model.getAttachment('mainHand'), {
        length: definition?.trailLength ?? 0.85,
      });
    }
    this.#refreshPose();
    return definition;
  }

  #refreshPose() {
    let pose = null;
    for (const { definition } of this.equipped.values()) {
      if (!definition.pose) continue;
      pose = { ...(pose ?? {}), ...definition.pose };
    }
    this.animator.setPose(pose);
  }

  equippedLabel(slot) {
    const entry = this.equipped.get(slot);
    return entry ? entry.definition.label : null;
  }

  /** Nach einem Respawn: nicht zur neuen Position gleiten, sondern springen. */
  snap() {
    this._snapped = false;
  }

  /** Kurze Animation für eine eingesetzte Fähigkeit. */
  playGesture(name) {
    if (this.dead) return;
    const clip = ABILITY_CLIPS[name] ?? name;
    this.animator.play(clip);
    // Der Vorlauf trifft den Moment, in dem die Klinge tatsächlich durchzieht.
    if (clip === 'swing') this.trail?.begin(0.3, 0.16);
    else if (clip === 'thrust') this.trail?.begin(0.22, 0.12);
  }

  /** Sichtbarer Tod: die Figur sackt zusammen und bleibt liegen. */
  setDead(dead) {
    if (this.dead === dead) return;
    this.dead = dead;

    if (dead) {
      this.animator.stopAll();
      this.animator.play('death');
      this.trail?.detach();
    } else {
      this.animator.stopAll();
    }
  }

  sync(state, dt) {
    this._target.set(state.position.x, state.position.y, state.position.z);

    if (!this._snapped) {
      this.root.position.copy(this._target);
      this._facing = state.facing ?? 0;
      this._snapped = true;
    } else {
      this.root.position.lerp(this._target, smoothing(22, dt));
      this._facing = lerpAngle(this._facing, state.facing ?? 0, smoothing(CONFIG.player.turnRate * 1.5, dt));
    }

    if (!this.dead) this.root.rotation.y = this._facing;

    this.animator.update(dt, this.dead ? 0 : (state.speed ?? 0), this.maxSpeed);
    this.trail?.update(dt);
  }

  dispose() {
    this.trail?.dispose();
    this.model.dispose?.();
  }
}
