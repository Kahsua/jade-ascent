import * as THREE from 'three';

/**
 * Schwungspur der Waffe: ein schmales Band, das der Klinge kurz hinterherzieht.
 *
 * Es wird nur während eines Schlags gezeichnet und läuft danach aus, indem
 * die älteren Stützstellen zusammenfallen — dadurch verjüngt sich das Band
 * zum Ende hin, statt einfach zu verschwinden.
 */
const SAMPLES = 12;

export class WeaponTrail {
  #base = [];
  #tip = [];

  constructor(scene) {
    this.scene = scene;
    this.remaining = 0;
    this.delay = 0;
    this.delay = 0;

    this.baseMarker = new THREE.Object3D();
    this.tipMarker = new THREE.Object3D();
    this.attached = null;

    this.geometry = new THREE.BufferGeometry();
    this.geometry.setAttribute('position', new THREE.BufferAttribute(new Float32Array(SAMPLES * 2 * 3), 3));

    const indices = [];
    for (let i = 0; i < SAMPLES - 1; i += 1) {
      const a = i * 2;
      indices.push(a, a + 1, a + 2, a + 1, a + 3, a + 2);
    }
    this.geometry.setIndex(indices);

    this.material = new THREE.MeshBasicMaterial({
      color: '#dfeaf2', transparent: true, opacity: 0, side: THREE.DoubleSide, depthWrite: false,
    });

    this.mesh = new THREE.Mesh(this.geometry, this.material);
    this.mesh.frustumCulled = false;
    this.mesh.renderOrder = 2;
    this.mesh.visible = false;
    scene.add(this.mesh);

    for (let i = 0; i < SAMPLES; i += 1) {
      this.#base.push(new THREE.Vector3());
      this.#tip.push(new THREE.Vector3());
    }
  }

  /** An die getragene Waffe hängen; length ist die ungefähre Klingenlänge. */
  attach(object3D, { length = 0.9, offset = 0.15 } = {}) {
    this.detach();
    if (!object3D) return;

    this.baseMarker.position.set(0, offset, 0);
    this.tipMarker.position.set(0, length, 0);
    object3D.add(this.baseMarker, this.tipMarker);
    this.attached = object3D;
  }

  detach() {
    if (!this.attached) return;
    this.attached.remove(this.baseMarker, this.tipMarker);
    this.attached = null;
    this.mesh.visible = false;
    this.remaining = 0;
  }

  /**
   * @param duration Wie lange das Band nachzieht
   * @param delay    Vorlauf: erst beim eigentlichen Schlag einsetzen, nicht
   *                 schon beim Ausholen — sonst ist die Spur beim Treffer
   *                 bereits verblasst.
   */
  begin(duration = 0.3, delay = 0) {
    if (!this.attached) return;
    this.remaining = duration;
    this.delay = delay;
    this.mesh.visible = delay <= 0;

    // Historie auf die aktuelle Lage setzen, sonst zieht das Band einen
    // Streifen quer durch die Welt.
    this.baseMarker.getWorldPosition(this.#base[0]);
    this.tipMarker.getWorldPosition(this.#tip[0]);
    for (let i = 1; i < SAMPLES; i += 1) {
      this.#base[i].copy(this.#base[0]);
      this.#tip[i].copy(this.#base[0]);
    }
  }

  update(dt) {
    if (this.delay > 0) {
      this.delay -= dt;
      // Historie mitziehen, damit beim Start kein Streifen quer durchs Bild geht.
      this.baseMarker.getWorldPosition(this.#base[0]);
      this.tipMarker.getWorldPosition(this.#tip[0]);
      for (let i = 1; i < SAMPLES; i += 1) {
        this.#base[i].copy(this.#base[0]);
        this.#tip[i].copy(this.#base[0]);
      }
      if (this.delay <= 0) this.mesh.visible = true;
      return;
    }

    if (this.remaining <= 0) {
      if (this.mesh.visible) this.mesh.visible = false;
      return;
    }
    this.remaining -= dt;

    for (let i = SAMPLES - 1; i > 0; i -= 1) {
      this.#base[i].copy(this.#base[i - 1]);
      this.#tip[i].copy(this.#tip[i - 1]);
    }
    this.baseMarker.getWorldPosition(this.#base[0]);
    this.tipMarker.getWorldPosition(this.#tip[0]);

    const positions = this.geometry.attributes.position.array;
    for (let i = 0; i < SAMPLES; i += 1) {
      const taper = 1 - i / (SAMPLES - 1);
      const base = this.#base[i];
      const tip = this.#tip[i];
      const o = i * 6;

      positions[o] = base.x;
      positions[o + 1] = base.y;
      positions[o + 2] = base.z;
      // Ältere Stützstellen laufen zur Basis zusammen: das Band verjüngt sich.
      positions[o + 3] = base.x + (tip.x - base.x) * taper;
      positions[o + 4] = base.y + (tip.y - base.y) * taper;
      positions[o + 5] = base.z + (tip.z - base.z) * taper;
    }

    this.geometry.attributes.position.needsUpdate = true;
    this.material.opacity = Math.min(0.5, Math.max(0, this.remaining) * 1.8);
  }

  dispose() {
    this.detach();
    this.scene.remove(this.mesh);
    this.geometry.dispose();
    this.material.dispose();
  }
}
