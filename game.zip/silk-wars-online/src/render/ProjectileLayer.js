import * as THREE from 'three';
import { makeMetalTexture, makeBarkTexture } from './TextureFactory.js';

/**
 * Anzeige der Geschosse. Positionen werden pro Frame aus dem
 * ProjectileSystem abgelesen — nur Entstehen und Vergehen laufen über
 * Ereignisse.
 */
const builders = {
  arrow(materials, scale = 1, material = null) {
    const group = new THREE.Group();
    const head = material ?? materials.steel;
    const shaft = new THREE.Mesh(new THREE.CylinderGeometry(0.018 * scale, 0.018 * scale, 0.7, 5), materials.wood);
    shaft.rotation.x = Math.PI / 2;
    const tip = new THREE.Mesh(new THREE.ConeGeometry(0.04 * scale, 0.12 * scale, 4), head);
    tip.rotation.x = Math.PI / 2;
    tip.position.z = 0.4;
    const fletching = new THREE.Mesh(new THREE.BoxGeometry(0.09 * scale, 0.002, 0.12), head);
    fletching.position.z = -0.3;
    group.add(shaft, tip, fletching);
    return group;
  },

  'arrow.golden': (materials) => builders.arrow(materials, 1.35, materials.gold),
  'arrow.heavy': (materials) => builders.arrow(materials, 1.9, materials.dark),

  /** Luftklinge: flache Sichel, die quer durch die Luft schneidet. */
  blade(materials) {
    const group = new THREE.Group();
    const arc = new THREE.Mesh(new THREE.TorusGeometry(0.36, 0.045, 4, 8, Math.PI * 0.9), materials.bladeEdge);
    arc.rotation.y = Math.PI / 2;
    arc.rotation.z = Math.PI / 2;
    group.add(arc);
    return group;
  },

  /** Geworfene Klinge: das Schwert selbst, im Flug rotierend. */
  sword(materials) {
    const group = new THREE.Group();
    const blade = new THREE.Mesh(new THREE.BoxGeometry(0.09, 0.78, 0.03), materials.steel);
    blade.position.y = 0.2;
    const guard = new THREE.Mesh(new THREE.BoxGeometry(0.26, 0.05, 0.06), materials.gold);
    guard.position.y = -0.2;
    const grip = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 0.18, 5), materials.dark);
    grip.position.y = -0.3;
    group.add(blade, guard, grip);
    group.rotation.x = Math.PI / 2;
    return group;
  },

  /** Geworfener Speer: fliegt mit der Spitze voran. */
  spear(materials) {
    const group = new THREE.Group();
    const shaft = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.035, 1.5, 6), materials.wood);
    shaft.rotation.x = Math.PI / 2;
    const tip = new THREE.Mesh(new THREE.ConeGeometry(0.07, 0.3, 4), materials.steel);
    tip.rotation.x = Math.PI / 2;
    tip.position.z = 0.85;
    group.add(shaft, tip);
    return group;
  },

  /** Geworfener Schild: rotiert flach wie eine Wurfscheibe. */
  shield(materials) {
    const group = new THREE.Group();
    const disc = new THREE.Mesh(new THREE.CylinderGeometry(0.32, 0.32, 0.06, 10), materials.wood);
    disc.rotation.x = Math.PI / 2;
    const rim = new THREE.Mesh(new THREE.TorusGeometry(0.32, 0.03, 5, 12), materials.dark);
    const boss = new THREE.Mesh(new THREE.SphereGeometry(0.09, 7, 6), materials.steel);
    group.add(disc, rim, boss);
    return group;
  },

  /** Ohne Element: ein schlichtes Wurfmesser. */
  physical(materials) {
    const group = new THREE.Group();
    const blade = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.34, 0.02), materials.steel);
    blade.rotation.x = Math.PI / 2;
    const grip = new THREE.Mesh(new THREE.CylinderGeometry(0.022, 0.022, 0.12, 5), materials.dark);
    grip.rotation.x = Math.PI / 2;
    grip.position.z = -0.2;
    group.add(blade, grip);
    return group;
  },

  /** Feuerball: glühender Kern mit lose umlaufender Hülle. */
  fire(materials) {
    const group = new THREE.Group();
    group.add(new THREE.Mesh(new THREE.IcosahedronGeometry(0.19, 0), materials.fireCore));
    group.add(new THREE.Mesh(new THREE.IcosahedronGeometry(0.3, 0), materials.fireHalo));
    return group;
  },

  /** Eissplitter: eine nach vorne gerichtete Spitze. */
  ice(materials) {
    const group = new THREE.Group();
    const shard = new THREE.Mesh(new THREE.ConeGeometry(0.12, 0.5, 5), materials.iceCore);
    shard.rotation.x = Math.PI / 2;
    group.add(shard);
    group.add(new THREE.Mesh(new THREE.IcosahedronGeometry(0.2, 0), materials.iceHalo));
    return group;
  },

  /** Blitz: gezackt statt rund, wie in der Farbsprache festgelegt. */
  lightning(materials) {
    const group = new THREE.Group();
    for (let i = 0; i < 4; i += 1) {
      const bolt = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.05, 0.26), materials.lightning);
      bolt.position.set((Math.random() - 0.5) * 0.16, (Math.random() - 0.5) * 0.16, (i - 1.5) * 0.2);
      bolt.rotation.z = Math.random() * Math.PI;
      group.add(bolt);
    }
    return group;
  },
  bolt(materials) {
    const group = new THREE.Group();
    const core = new THREE.Mesh(new THREE.IcosahedronGeometry(0.16, 0), materials.arcane);
    const halo = new THREE.Mesh(new THREE.IcosahedronGeometry(0.26, 0), materials.arcaneHalo);
    group.add(core, halo);
    return group;
  },
};

export class ProjectileLayer {
  #meshes = new Map();

  constructor({ scene, bus, projectiles }) {
    this.scene = scene;
    this.projectiles = projectiles;

    this.materials = {
      wood: new THREE.MeshStandardMaterial({ map: makeBarkTexture({ color: '#6b4a2c' }), roughness: 0.9 }),
      steel: new THREE.MeshStandardMaterial({ map: makeMetalTexture({ color: '#c2c8ce' }), roughness: 0.4, metalness: 0.7 }),
      arcane: new THREE.MeshBasicMaterial({ color: '#68e0c8' }),
      arcaneHalo: new THREE.MeshBasicMaterial({ color: '#3fae9a', transparent: true, opacity: 0.28, wireframe: true }),
      gold: new THREE.MeshStandardMaterial({ map: makeMetalTexture({ color: '#d8ac48' }), roughness: 0.3, metalness: 0.85, emissive: '#5c4310' }),
      dark: new THREE.MeshStandardMaterial({ map: makeMetalTexture({ color: '#6d757c' }), roughness: 0.6, metalness: 0.5 }),
      fireCore: new THREE.MeshBasicMaterial({ color: '#ffb45a' }),
      fireHalo: new THREE.MeshBasicMaterial({ color: '#e0602c', transparent: true, opacity: 0.32, wireframe: true }),
      iceCore: new THREE.MeshBasicMaterial({ color: '#dcf3ff' }),
      iceHalo: new THREE.MeshBasicMaterial({ color: '#79c8ea', transparent: true, opacity: 0.3, wireframe: true }),
      lightning: new THREE.MeshBasicMaterial({ color: '#bfe8ff' }),
      bladeEdge: new THREE.MeshBasicMaterial({ color: '#dff0ff', transparent: true, opacity: 0.85 }),
    };

    bus.on('projectile:spawned', (projectile) => this.#add(projectile));
    bus.on('projectile:removed', ({ id }) => this.#remove(id));
  }

  #add(projectile) {
    // Modell schlägt Element, Element schlägt Standard — so bekommt jedes
    // Element seine eigene Form, ohne dass jede Fähigkeit sie nennen muss.
    const build = builders[projectile.model] ?? builders[projectile.element] ?? builders.bolt;
    const mesh = build(this.materials);
    mesh.position.set(projectile.position.x, projectile.position.y, projectile.position.z);
    this.scene.add(mesh);
    this.#meshes.set(projectile.id, mesh);
  }

  #remove(id) {
    const mesh = this.#meshes.get(id);
    if (!mesh) return;
    this.scene.remove(mesh);
    mesh.traverse((child) => child.geometry?.dispose?.());
    this.#meshes.delete(id);
  }

  sync(dt) {
    for (const projectile of this.projectiles.all()) {
      const mesh = this.#meshes.get(projectile.id);
      if (!mesh) continue;
      mesh.position.set(projectile.position.x, projectile.position.y, projectile.position.z);
      mesh.rotation.y = Math.atan2(projectile.direction.x, projectile.direction.z);
      // Geworfene Waffen und Klingen überschlagen sich im Flug.
      if (projectile.model === 'sword') mesh.rotation.z += dt * 14;
      else if (projectile.model === 'shield') mesh.rotation.z += dt * 16;
      else if (projectile.model === 'spear') mesh.rotation.z += dt * 4;
      else if (projectile.model === 'blade') mesh.rotation.x += dt * 9;
      else if (!projectile.model?.startsWith('arrow')) mesh.rotation.z += dt * 6;
    }
  }
}
