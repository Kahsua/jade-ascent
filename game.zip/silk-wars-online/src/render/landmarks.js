import * as THREE from 'three';
import { regions } from '../game/data/regions.js';
import { heightAt } from '../game/Heightfield.js';
import { makeBarkTexture, makeNoiseTexture } from './TextureFactory.js';

/**
 * Wahrzeichen der Gebiete — reine Anzeige, aus denselben Primitiven wie alles
 * andere zusammengesetzt. Welches Gebiet welches Wahrzeichen bekommt, steht in
 * den Gebietsdaten.
 */
const builders = {
  camp(center, materials) {
    const group = new THREE.Group();
    const updaters = [];

    // Zerbrochene Säulen im Halbkreis
    for (let i = 0; i < 5; i += 1) {
      const angle = -0.6 + i * 0.65;
      const x = center.x + Math.cos(angle) * 7.5;
      const z = center.z + Math.sin(angle) * 7.5;
      const height = 1.4 + (i % 3) * 0.9;

      const pillar = new THREE.Mesh(new THREE.CylinderGeometry(0.34, 0.42, height, 7), materials.stone);
      pillar.position.set(x, heightAt(x, z) + height / 2 - 0.1, z);
      pillar.rotation.z = (i % 2 ? 1 : -1) * 0.06;
      pillar.castShadow = true;
      pillar.receiveShadow = true;

      const cap = new THREE.Mesh(new THREE.BoxGeometry(0.9, 0.22, 0.9), materials.stone);
      cap.position.set(x, heightAt(x, z) + height - 0.05, z);
      cap.rotation.y = i * 0.4;
      cap.castShadow = true;

      group.add(pillar, cap);
    }

    // Feuerstelle
    const fireY = heightAt(center.x, center.z);
    for (let i = 0; i < 9; i += 1) {
      const angle = (i / 9) * Math.PI * 2;
      const stone = new THREE.Mesh(new THREE.IcosahedronGeometry(0.22, 0), materials.stone);
      stone.position.set(center.x + Math.cos(angle) * 1.1, fireY + 0.1, center.z + Math.sin(angle) * 1.1);
      stone.rotation.set(Math.random(), Math.random(), Math.random());
      stone.castShadow = true;
      group.add(stone);
    }

    for (let i = 0; i < 3; i += 1) {
      const log = new THREE.Mesh(new THREE.CylinderGeometry(0.11, 0.13, 1.1, 6), materials.wood);
      log.position.set(center.x, fireY + 0.22, center.z);
      log.rotation.set(Math.PI / 2.6, (i / 3) * Math.PI, 0);
      log.castShadow = true;
      group.add(log);
    }

    const flame = new THREE.Mesh(
      new THREE.ConeGeometry(0.35, 0.9, 6),
      new THREE.MeshBasicMaterial({ color: '#f0913c', transparent: true, opacity: 0.85 }),
    );
    flame.position.set(center.x, fireY + 0.62, center.z);
    group.add(flame);

    const light = new THREE.PointLight('#ff9a44', 3.2, 16, 2);
    light.position.set(center.x, fireY + 1.1, center.z);
    group.add(light);

    // Flackern: zwei ungleiche Sinuswellen, damit es nicht pulsiert
    let time = Math.random() * 10;
    updaters.push((dt) => {
      time += dt;
      const flicker = 0.82 + Math.sin(time * 9.1) * 0.1 + Math.sin(time * 3.3) * 0.08;
      light.intensity = 3.2 * flicker;
      flame.scale.set(0.9 + flicker * 0.2, flicker, 0.9 + flicker * 0.2);
      flame.rotation.y += dt * 1.6;
    });

    // Kisten
    for (const offset of [{ x: 3.2, z: -2.4 }, { x: 2.4, z: -3.4 }, { x: -3.6, z: 2.2 }]) {
      const x = center.x + offset.x;
      const z = center.z + offset.z;
      const crate = new THREE.Mesh(new THREE.BoxGeometry(0.8, 0.7, 0.8), materials.wood);
      crate.position.set(x, heightAt(x, z) + 0.35, z);
      crate.rotation.y = Math.random() * Math.PI;
      crate.castShadow = true;
      crate.receiveShadow = true;
      group.add(crate);
    }

    return { group, updaters };
  },
};

export function buildLandmarks() {
  const root = new THREE.Group();
  root.name = 'landmarks';
  const updaters = [];

  const materials = {
    stone: new THREE.MeshStandardMaterial({ map: makeNoiseTexture({ color: '#8a8579', variance: 20 }), roughness: 0.95, flatShading: true }),
    wood: new THREE.MeshStandardMaterial({ map: makeBarkTexture({ color: '#5c4029' }), roughness: 0.9 }),
  };

  for (const regionId of regions.ids()) {
    const region = regions.get(regionId);
    const build = region.landmark ? builders[region.landmark] : null;
    if (!build) continue;

    const result = build(region.center, materials);
    root.add(result.group);
    updaters.push(...result.updaters);
  }

  return {
    group: root,
    update(dt) {
      for (const updater of updaters) updater(dt);
    },
  };
}
