import * as THREE from 'three';
import { CONFIG } from '../core/Config.js';
import { heightAt } from '../game/Heightfield.js';
import { makeGroundTexture } from './TextureFactory.js';

/**
 * Das Mesh wird AUS dem Heightfield erzeugt, nie umgekehrt. Damit können
 * Logik und Anzeige nie auseinanderlaufen.
 */
export function createTerrainMesh() {
  const { size, segments } = CONFIG.world;

  const geometry = new THREE.PlaneGeometry(size, size, segments, segments);
  geometry.rotateX(-Math.PI / 2);

  const position = geometry.attributes.position;
  for (let i = 0; i < position.count; i += 1) {
    position.setY(i, heightAt(position.getX(i), position.getZ(i)));
  }
  position.needsUpdate = true;
  geometry.computeVertexNormals();

  const material = new THREE.MeshStandardMaterial({
    map: makeGroundTexture(),
    roughness: 0.96,
    metalness: 0,
  });

  const mesh = new THREE.Mesh(geometry, material);
  mesh.name = 'terrain';
  mesh.receiveShadow = true;
  return mesh;
}
