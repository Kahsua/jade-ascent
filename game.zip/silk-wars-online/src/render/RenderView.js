import * as THREE from 'three';
import { CONFIG } from '../core/Config.js';

/**
 * Renderer, Szene, Kamera, Licht. Kennt keine Spielregeln.
 */
export class RenderView {
  constructor(canvas) {
    this.canvas = canvas;

    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: 'high-performance' });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, CONFIG.render.maxPixelRatio));
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.shadowMap.enabled = CONFIG.render.shadows;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    // Filmische Tonwertkurve: Sonnenseiten brennen nicht mehr aus, Schatten
    // bleiben lesbar. Kostet nichts und hebt den Gesamteindruck deutlich.
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.15;

    const sky = new THREE.Color(CONFIG.render.skyColor);
    this.scene = new THREE.Scene();
    this.scene.background = sky;
    this.scene.fog = new THREE.Fog(sky, CONFIG.render.fogNear, CONFIG.render.fogFar);

    this.camera = new THREE.PerspectiveCamera(
      CONFIG.render.fov,
      window.innerWidth / window.innerHeight,
      CONFIG.render.near,
      CONFIG.render.far,
    );
    this.camera.position.set(0, 6, 10);

    this.#setupLights();
    this.#setupResize();
    this.resize();
  }

  #setupLights() {
    // Himmel/Boden-Licht statt flachem Ambient: Schattenseiten bleiben lesbar.
    this.hemisphere = new THREE.HemisphereLight('#bcd7f0', '#3f4d2f', 0.85);
    this.scene.add(this.hemisphere);

    this.sun = new THREE.DirectionalLight('#fff1d6', 1.7);
    this.sun.castShadow = CONFIG.render.shadows;
    this.sun.shadow.mapSize.set(2048, 2048);
    this.sun.shadow.bias = -0.0006;
    this.sun.shadow.normalBias = 0.03;

    // Enger Schattenkasten, der dem Spieler folgt: scharfe Schatten dort,
    // wo man hinsieht, statt einer verwaschenen Map über die ganze Welt.
    const shadowCam = this.sun.shadow.camera;
    shadowCam.left = -32;
    shadowCam.right = 32;
    shadowCam.top = 32;
    shadowCam.bottom = -32;
    shadowCam.near = 1;
    shadowCam.far = 160;
    shadowCam.updateProjectionMatrix();

    // Kaltes Gegenlicht von der Schattenseite: die Silhouetten heben sich
    // dadurch vom Hintergrund ab, ohne dass ein zweiter Schattenwurf nötig ist.
    this.rim = new THREE.DirectionalLight('#a8c8ff', 0.55);
    this.rim.position.set(-30, 22, -34);
    this.scene.add(this.rim);

    this.sunOffset = new THREE.Vector3(38, 62, 26);
    this.scene.add(this.sun);
    this.scene.add(this.sun.target);
  }

  /** Sonne dem Fokuspunkt nachführen, damit Schatten immer greifen. */
  updateSun(focus) {
    this.sun.target.position.set(focus.x, focus.y, focus.z);
    this.sun.target.updateMatrixWorld();
    this.sun.position.set(focus.x + this.sunOffset.x, focus.y + this.sunOffset.y, focus.z + this.sunOffset.z);
  }

  #setupResize() {
    this._onResize = () => this.resize();
    window.addEventListener('resize', this._onResize);
  }

  resize() {
    const width = window.innerWidth;
    const height = window.innerHeight;
    this.renderer.setSize(width, height, false);
    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
  }

  render() {
    this.renderer.render(this.scene, this.camera);
  }

  dispose() {
    window.removeEventListener('resize', this._onResize);
    this.renderer.dispose();
  }
}
