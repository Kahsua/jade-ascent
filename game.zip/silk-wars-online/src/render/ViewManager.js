import { modelOfItem } from '../game/data/items.js';
import { CharacterView } from './views/CharacterView.js';

/**
 * Hält für jede Entity ein Modell — und zwar von selbst.
 *
 * Der ViewManager hört auf "entity:spawned" und "entity:removed". Deshalb muss
 * ab Phase 7 kein Monster-Code wissen, dass es eine Anzeige gibt: spawnen
 * genügt, das Modell erscheint.
 */
export class ViewManager {
  #views = new Map();

  constructor({ scene, bus }) {
    this.scene = scene;
    this.bus = bus;

    bus.on('entity:spawned', (entity) => this.add(entity));
    bus.on('entity:removed', (entity) => this.remove(entity.id));
    // Der Zustand führt Item-IDs, die Anzeige braucht Modell-IDs.
    bus.on('entity:equipment', ({ id, slot, itemId }) => this.get(id)?.equip(slot, modelOfItem(itemId)));
    bus.on('ability:cast', ({ casterId, animation }) => {
      if (animation) this.get(casterId)?.playGesture(animation);
    });
    // Treffer sind sichtbar, nicht nur als Zahl.
    bus.on('entity:damaged', ({ id, amount, overTime }) => {
      if (overTime || amount <= 0) return;
      this.get(id)?.playGesture('flinch');
    });

    bus.on('entity:died', ({ id }) => this.get(id)?.setDead(true));
    bus.on('entity:revived', ({ id, atSpawn }) => {
      const view = this.get(id);
      if (!view) return;
      view.setDead(false);
      if (atSpawn) view.snap();
    });
  }

  add(entity) {
    const view = new CharacterView(entity.template.model, { scene: this.scene });
    // Marker für das Anklicken: der Picker läuft von jedem getroffenen Mesh
    // die Hierarchie hoch, bis er diese ID findet.
    view.root.userData.entityId = entity.id;
    const equipment = entity.state.equipment ?? entity.template.equipment ?? {};
    for (const [slot, itemId] of Object.entries(equipment)) {
      const model = modelOfItem(itemId);
      if (model) view.equip(slot, model);
    }
    this.scene.add(view.root);
    this.#views.set(entity.id, { view, entity });
    return view;
  }

  remove(id) {
    const entry = this.#views.get(id);
    if (!entry) return;
    this.scene.remove(entry.view.root);
    entry.view.dispose();
    this.#views.delete(id);
  }

  get(id) {
    return this.#views.get(id)?.view ?? null;
  }

  entries() {
    return [...this.#views.values()];
  }

  sync(dt) {
    for (const { view, entity } of this.#views.values()) view.sync(entity.state, dt);
  }
}
