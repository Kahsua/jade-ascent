import * as THREE from 'three';
import { paletteOf } from './effects.js';

/**
 * Sichtbare Kette zwischen zwei Entities — leicht durchhängend, damit sie wie
 * eine Kette wirkt und nicht wie ein Laserstrahl. Sie besteht, solange die
 * Verbindung besteht, nicht nur im Moment des Treffers.
 */
const SEGMENTS = 12;

export class TetherLayer {
  #lines = new Map();

  constructor({ scene, bus, tethers, entities }) {
    this.scene = scene;
    this.tethers = tethers;
    this.entities = entities;

    bus.on('tether:created', (tether) => this.#add(tether));
    bus.on('tether:removed', ({ id }) => this.#remove(id));
  }

  #add(tether) {
    if (this.#lines.has(tether.id)) return;

    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute('position', new THREE.BufferAttribute(new Float32Array((SEGMENTS + 1) * 3), 3));
    const material = new THREE.LineBasicMaterial({
      color: paletteOf(tether.style).spark, transparent: true, opacity: 0.75, depthWrite: false,
    });

    const line = new THREE.Line(geometry, material);
    line.frustumCulled = false;
    line.renderOrder = 3;
    this.scene.add(line);
    this.#lines.set(tether.id, { line, geometry, material });
  }

  #remove(id) {
    const entry = this.#lines.get(id);
    if (!entry) return;
    this.scene.remove(entry.line);
    entry.geometry.dispose();
    entry.material.dispose();
    this.#lines.delete(id);
  }

  sync() {
    for (const tether of this.tethers.all()) {
      const entry = this.#lines.get(tether.id);
      const source = this.entities.get(tether.sourceId);
      const target = this.entities.get(tether.targetId);
      if (!entry || !source || !target) continue;

      const positions = entry.geometry.attributes.position.array;
      const spanX = target.position.x - source.position.x;
      const spanZ = target.position.z - source.position.z;
      const distance = Math.hypot(spanX, spanZ);

      // Je straffer die Kette, desto weniger Durchhang.
      const slack = Math.max(0.05, 1 - distance / tether.maxDistance) * 0.9;

      for (let i = 0; i <= SEGMENTS; i += 1) {
        const t = i / SEGMENTS;
        const sag = Math.sin(t * Math.PI) * slack;
        positions[i * 3] = source.position.x + spanX * t;
        positions[i * 3 + 1] = (source.position.y + 1.1) + ((target.position.y + 1.1) - (source.position.y + 1.1)) * t - sag;
        positions[i * 3 + 2] = source.position.z + spanZ * t;
      }
      entry.geometry.attributes.position.needsUpdate = true;
    }
  }
}
