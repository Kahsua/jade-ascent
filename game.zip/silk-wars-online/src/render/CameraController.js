import * as THREE from 'three';
import { CONFIG } from '../core/Config.js';
import { clamp, smoothing } from '../core/math.js';

/**
 * Third-Person-Orbitkamera.
 *
 * - Drehen nur bei gehaltener rechter Maustaste (linke Maus bleibt ab Phase 4
 *   für Ziel-/Bodenauswahl frei).
 * - Zoom per Mausrad.
 * - Kamera-Kollision per Raycast gegen Terrain und Umgebung: die Kamera zieht
 *   sich heran, statt in einen Hügel zu tauchen.
 *
 * getYaw() ist die einzige Information, die die Bewegungsschicht von der
 * Kamera braucht — dadurch bleibt Bewegung testbar ohne Renderer.
 */
export class CameraController {
  constructor(camera, input, { obstacles = [], config = CONFIG.camera } = {}) {
    this.camera = camera;
    this.input = input;
    this.config = config;
    this.obstacles = obstacles;

    this.yaw = Math.PI;
    this.pitch = config.pitch;
    this.distance = config.distance;

    this._focus = new THREE.Vector3();
    this._desiredFocus = new THREE.Vector3();
    this._offset = new THREE.Vector3();
    this._raycaster = new THREE.Raycaster();
    this._initialised = false;
  }

  setObstacles(obstacles) {
    this.obstacles = obstacles;
  }

  update(dt, targetPosition) {
    const cfg = this.config;

    const look = this.input.consumeLook();
    // Maus nach rechts -> Blick nach rechts, also yaw verkleinern.
    this.yaw -= look.x * cfg.sensitivity;
    this.pitch = clamp(this.pitch + look.y * cfg.sensitivity, cfg.minPitch, cfg.maxPitch);

    const zoom = this.input.consumeZoom();
    if (zoom !== 0) {
      this.distance = clamp(this.distance + zoom * cfg.zoomSpeed, cfg.minDistance, cfg.maxDistance);
    }

    this._desiredFocus.set(targetPosition.x, targetPosition.y + cfg.targetHeight, targetPosition.z);
    if (!this._initialised) {
      this._focus.copy(this._desiredFocus);
      this._initialised = true;
    } else {
      this._focus.lerp(this._desiredFocus, smoothing(cfg.followLerp, dt));
    }

    const cosPitch = Math.cos(this.pitch);
    this._offset.set(
      Math.sin(this.yaw) * cosPitch,
      Math.sin(this.pitch),
      Math.cos(this.yaw) * cosPitch,
    ).normalize();

    const distance = this.#collide(this._focus, this._offset, this.distance);

    this.camera.position.copy(this._focus).addScaledVector(this._offset, distance);
    this.camera.lookAt(this._focus);
  }

  #collide(focus, direction, distance) {
    if (this.obstacles.length === 0) return distance;

    this._raycaster.set(focus, direction);
    this._raycaster.far = distance;
    const hits = this._raycaster.intersectObjects(this.obstacles, true);
    if (hits.length === 0) return distance;

    return Math.max(this.config.minDistance * 0.6, hits[0].distance - this.config.collisionPadding);
  }

  /** Kamerarelative Absicht -> Weltrichtung. */
  toWorldDirection(intent) {
    if (intent.x === 0 && intent.z === 0) return { x: 0, z: 0 };

    const forwardX = -Math.sin(this.yaw);
    const forwardZ = -Math.cos(this.yaw);
    const rightX = -forwardZ;
    const rightZ = forwardX;

    const x = forwardX * intent.z + rightX * intent.x;
    const z = forwardZ * intent.z + rightZ * intent.x;
    const length = Math.hypot(x, z) || 1;

    return { x: x / length, z: z / length };
  }
}
