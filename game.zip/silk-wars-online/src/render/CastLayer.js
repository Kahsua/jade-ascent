import * as THREE from 'three';
import { paletteOf } from './effects.js';

/**
 * Ladeanimation: eine Energiekugel wächst am Charakter, bis der Zauber sitzt,
 * und entlädt sich beim Auslösen.
 *
 * Farbe kommt aus dem Element der Fähigkeit — dieselbe Sprache wie bei
 * Projektilen und Flächeneffekten.
 */
export class CastLayer {
  #casts = new Map();

  constructor({ scene, bus, entities }) {
    this.scene = scene;
    this.entities = entities;

    this.coreGeometry = new THREE.IcosahedronGeometry(0.3, 0);
    this.shellGeometry = new THREE.IcosahedronGeometry(0.5, 0);

    bus.on('cast:started', ({ id, element }) => this.#begin(id, element));
    bus.on('cast:progress', ({ id, progress }) => {
      const entry = this.#casts.get(id);
      if (entry) entry.progress = progress;
    });
    bus.on('cast:finished', ({ id }) => this.#end(id));
    bus.on('cast:cancelled', ({ id }) => this.#end(id));
  }

  #begin(id, element) {
    this.#end(id);
    const palette = paletteOf(element);

    const group = new THREE.Group();
    const core = new THREE.Mesh(this.coreGeometry, new THREE.MeshBasicMaterial({
      color: palette.spark, transparent: true, opacity: 0.85,
    }));
    const shell = new THREE.Mesh(this.shellGeometry, new THREE.MeshBasicMaterial({
      color: palette.color, transparent: true, opacity: 0.35, wireframe: true,
    }));
    group.add(core, shell);
    group.scale.setScalar(0.15);
    this.scene.add(group);

    this.#casts.set(id, { group, core, shell, progress: 0, element });
  }

  #end(id) {
    const entry = this.#casts.get(id);
    if (!entry) return;

    this.scene.remove(entry.group);
    entry.core.material.dispose();
    entry.shell.material.dispose();
    this.#casts.delete(id);
  }

  update(dt) {
    for (const [id, entry] of this.#casts) {
      const entity = this.entities.get(id);
      if (!entity) {
        this.#end(id);
        continue;
      }

      entry.group.position.set(entity.position.x, entity.position.y + 1.25, entity.position.z);
      const scale = 0.2 + entry.progress * 0.9;
      entry.group.scale.setScalar(scale);
      entry.shell.rotation.y += dt * 2.4;
      entry.shell.rotation.x += dt * 1.1;
      entry.core.rotation.y -= dt * 3.2;
      entry.core.material.opacity = 0.5 + entry.progress * 0.45;
    }
  }
}
