import * as THREE from 'three';
import { paletteOf } from './effects.js';

/**
 * Anzeige der Bodeneffekte. Wie bei den Geschossen kommen Position und Größe
 * pro Frame aus dem Logiksystem; nur Entstehen und Vergehen laufen über
 * Ereignisse.
 */
const builders = {
  /** Nagelfeld: Ring plus kleine Spitzen, die im Boden stecken. */
  nails(hazard, palette) {
    const group = new THREE.Group();
    const material = new THREE.MeshStandardMaterial({ color: palette.color, roughness: 0.5, metalness: 0.6, flatShading: true });

    for (let i = 0; i < 10; i += 1) {
      const angle = (i / 10) * Math.PI * 2;
      const distance = hazard.radius * (0.3 + Math.random() * 0.65);
      const nail = new THREE.Mesh(new THREE.ConeGeometry(0.07, 0.45, 4), material);
      nail.position.set(Math.cos(angle) * distance, 0.16, Math.sin(angle) * distance);
      nail.rotation.set((Math.random() - 0.5) * 0.4, Math.random(), (Math.random() - 0.5) * 0.4);
      group.add(nail);
    }
    return group;
  },

  /** Pfeilwirbel: mehrere Ebenen kleiner Pfeile, die gegeneinander rotieren. */
  tornado(hazard, palette) {
    const group = new THREE.Group();
    const material = new THREE.MeshBasicMaterial({ color: palette.spark, transparent: true, opacity: 0.8 });

    for (let ring = 0; ring < 4; ring += 1) {
      const level = new THREE.Group();
      level.position.y = 0.35 + ring * 0.55;
      const count = 5 + ring;

      for (let i = 0; i < count; i += 1) {
        const angle = (i / count) * Math.PI * 2;
        const distance = hazard.radius * (0.35 + ring * 0.16);
        const shaft = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.06, 0.55), material);
        shaft.position.set(Math.cos(angle) * distance, 0, Math.sin(angle) * distance);
        shaft.rotation.y = -angle;
        level.add(shaft);
      }
      level.userData.spin = (ring % 2 ? -1 : 1) * (2.6 - ring * 0.3);
      group.add(level);
    }
    return group;
  },

  /** Standard: flaches Feld mit pulsierendem Rand. */
  field(hazard, palette) {
    const group = new THREE.Group();
    const geometry = new THREE.RingGeometry(hazard.radius * 0.86, hazard.radius, 36);
    geometry.rotateX(-Math.PI / 2);
    const ring = new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({
      color: palette.color, transparent: true, opacity: 0.6, side: THREE.DoubleSide, depthWrite: false,
    }));
    ring.position.y = 0.06;
    group.add(ring);
    return group;
  },
};

export class HazardLayer {
  #meshes = new Map();

  constructor({ scene, bus, hazards }) {
    this.scene = scene;
    this.hazards = hazards;

    bus.on('hazard:spawned', (hazard) => this.#add(hazard));
    bus.on('hazard:removed', ({ id }) => this.#remove(id));
  }

  #add(hazard) {
    const palette = paletteOf(hazard.style);
    const build = builders[hazard.model] ?? builders.field;
    const group = build(hazard, palette);
    group.position.set(hazard.position.x, hazard.position.y, hazard.position.z);
    this.scene.add(group);
    this.#meshes.set(hazard.id, group);
  }

  #remove(id) {
    const group = this.#meshes.get(id);
    if (!group) return;
    this.scene.remove(group);
    group.traverse((child) => child.geometry?.dispose?.());
    this.#meshes.delete(id);
  }

  sync(dt) {
    for (const hazard of this.hazards.all()) {
      const group = this.#meshes.get(hazard.id);
      if (!group) continue;

      group.position.set(hazard.position.x, hazard.position.y, hazard.position.z);

      // Wirbel drehen sich, Felder pulsieren zum Ende hin schneller.
      for (const child of group.children) {
        if (child.userData.spin) child.rotation.y += child.userData.spin * dt;
      }
      const fade = Math.min(1, hazard.remaining / 0.8);
      group.scale.setScalar(0.85 + 0.15 * fade);
    }
  }
}
