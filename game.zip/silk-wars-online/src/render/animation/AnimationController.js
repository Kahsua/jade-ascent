import { clips } from './clips.js';
import { createAnimator } from './createAnimator.js';

/**
 * Legt Keyframe-Clips über die prozedurale Laufanimation.
 *
 * Die Laufschicht bestimmt weiterhin Beine, Arme und Atmung; jeder aktive
 * Clip addiert seine Werte darauf. Ein Clip mit "override" (Sterben) schaltet
 * die Laufschicht ab und arbeitet stattdessen auf der Grundhaltung.
 */
function sample(track, t) {
  if (t <= track[0].t) return track[0];
  const last = track[track.length - 1];
  if (t >= last.t) return last;

  for (let i = 1; i < track.length; i += 1) {
    if (t > track[i].t) continue;
    const a = track[i - 1];
    const b = track[i];
    const span = b.t - a.t || 1;
    const raw = (t - a.t) / span;
    const k = raw * raw * (3 - 2 * raw); // weiches Ein- und Ausschwingen

    return {
      x: (a.x ?? 0) + ((b.x ?? 0) - (a.x ?? 0)) * k,
      y: (a.y ?? 0) + ((b.y ?? 0) - (a.y ?? 0)) * k,
      z: (a.z ?? 0) + ((b.z ?? 0) - (a.z ?? 0)) * k,
      py: (a.py ?? 0) + ((b.py ?? 0) - (a.py ?? 0)) * k,
    };
  }
  return last;
}

export class AnimationController {
  #active = [];

  constructor(model) {
    this.model = model;
    this.parts = model.parts;
    this.locomotion = createAnimator(model);

    // Grundhaltung merken, um sie bei Override-Clips wiederherstellen zu können.
    this.rest = new Map();
    for (const [name, part] of Object.entries(model.parts)) {
      if (!part || Array.isArray(part) || !part.rotation) continue;
      this.rest.set(name, {
        part,
        rotation: { x: part.rotation.x, y: part.rotation.y, z: part.rotation.z },
        y: part.position.y,
      });
    }
  }

  setPose(pose) {
    this.locomotion.setPose?.(pose);
  }

  play(clipId, { speed = 1, weight = 1 } = {}) {
    const clip = clips.find(clipId);
    if (!clip) return null;

    // Derselbe Clip startet neu, statt sich mit sich selbst zu überlagern.
    this.#active = this.#active.filter((instance) => instance.id !== clipId);

    const instance = { id: clipId, clip, elapsed: 0, speed, weight: weight * (clip.weight ?? 1) };
    this.#active.push(instance);
    this.#active.sort((a, b) => (a.clip.priority ?? 0) - (b.clip.priority ?? 0));
    return instance;
  }

  stop(clipId) {
    this.#active = this.#active.filter((instance) => instance.id !== clipId);
  }

  stopAll() {
    this.#active.length = 0;
  }

  isPlaying(clipId) {
    return this.#active.some((instance) => instance.id === clipId);
  }

  #restore() {
    for (const entry of this.rest.values()) {
      entry.part.rotation.x = entry.rotation.x;
      entry.part.rotation.y = entry.rotation.y;
      entry.part.rotation.z = entry.rotation.z;
      entry.part.position.y = entry.y;
    }
  }

  update(dt, speed, maxSpeed) {
    const overriding = this.#active.some((instance) => instance.clip.override);

    if (overriding) this.#restore();
    else this.locomotion.update(dt, speed, maxSpeed);

    for (let i = this.#active.length - 1; i >= 0; i -= 1) {
      const instance = this.#active[i];
      instance.elapsed += dt * instance.speed;

      const progress = instance.elapsed / instance.clip.duration;
      if (progress >= 1 && !instance.clip.hold) {
        this.#active.splice(i, 1);
        continue;
      }

      const t = Math.min(1, progress);
      for (const [joint, track] of Object.entries(instance.clip.tracks)) {
        const part = this.parts[joint];
        if (!part?.rotation) continue; // Gelenk gibt es an diesem Rig nicht

        const value = sample(track, t);
        part.rotation.x += value.x * instance.weight;
        part.rotation.y += value.y * instance.weight;
        part.rotation.z += value.z * instance.weight;
        if (value.py) part.position.y += value.py * instance.weight;
      }
    }
  }
}
