import { Registry } from '../../core/Registry.js';

/**
 * Animationen als Daten — Keyframe-Kurven statt fest verdrahteter Sinuswellen.
 *
 * Eine Spur gehört zu einem Gelenk des Rigs und enthält Stützstellen:
 *   { t, x, y, z, py }   t = 0..1 über die Laufzeit, Werte sind ZUSÄTZE
 *                        auf die Grundhaltung (py = Höhenversatz)
 *
 * Weil alles additiv ist, lassen sich Clips überlagern: ein Zucken beim
 * Treffer legt sich über den laufenden Schlag, ohne dass beide voneinander
 * wissen müssen.
 *
 * Fehlende Gelenke werden übersprungen — deshalb funktioniert derselbe Clip
 * für Zweibeiner und Vierbeiner, jeder mit den Spuren, die er hat.
 */
export const clips = new Registry('clips');

clips.registerAll({
  // --- Angriffe ------------------------------------------------------------
  swing: {
    duration: 0.55, priority: 2,
    tracks: {
      shoulderR: [{ t: 0, x: 0 }, { t: 0.2, x: 0.75, z: -0.35 }, { t: 0.4, x: -2.05, z: 0.3 }, { t: 0.6, x: -1.1 }, { t: 1, x: 0 }],
      elbowR: [{ t: 0, x: 0 }, { t: 0.2, x: -1.05 }, { t: 0.42, x: 0.35 }, { t: 1, x: 0 }],
      shoulderL: [{ t: 0, x: 0 }, { t: 0.4, x: 0.3 }, { t: 1, x: 0 }],
      torso: [{ t: 0, y: 0 }, { t: 0.2, y: 0.4 }, { t: 0.45, y: -0.45, x: 0.18 }, { t: 1, y: 0, x: 0 }],
      hips: [{ t: 0, y: 0 }, { t: 0.2, y: 0.18 }, { t: 0.45, y: -0.22 }, { t: 1, y: 0 }],
      // Vierbeiner beißen mit derselben Marke: Kopf vor, Nacken hoch.
      neck: [{ t: 0, x: 0 }, { t: 0.25, x: -0.45 }, { t: 0.45, x: 0.55 }, { t: 1, x: 0 }],
      head: [{ t: 0, x: 0 }, { t: 0.25, x: -0.3 }, { t: 0.45, x: 0.5 }, { t: 1, x: 0 }],
    },
  },

  thrust: {
    duration: 0.45, priority: 2,
    tracks: {
      shoulderR: [{ t: 0, x: 0 }, { t: 0.25, x: 0.4 }, { t: 0.45, x: -1.15 }, { t: 1, x: 0 }],
      elbowR: [{ t: 0, x: 0 }, { t: 0.25, x: -1.3 }, { t: 0.45, x: 0.55 }, { t: 1, x: 0 }],
      torso: [{ t: 0, y: 0 }, { t: 0.25, y: 0.3 }, { t: 0.45, y: -0.15 }, { t: 1, y: 0 }],
    },
  },

  shoot: {
    duration: 0.5, priority: 2,
    tracks: {
      elbowR: [{ t: 0, x: 0 }, { t: 0.42, x: -0.95 }, { t: 0.55, x: 0.25 }, { t: 1, x: 0 }],
      shoulderR: [{ t: 0, x: 0 }, { t: 0.42, x: 0.2, z: -0.15 }, { t: 0.55, x: -0.1 }, { t: 1, x: 0 }],
      torso: [{ t: 0, y: 0 }, { t: 0.42, y: 0.18 }, { t: 0.6, y: -0.08 }, { t: 1, y: 0 }],
      head: [{ t: 0, y: 0 }, { t: 0.42, y: 0.12 }, { t: 1, y: 0 }],
    },
  },

  cast: {
    duration: 0.7, priority: 2,
    tracks: {
      shoulderR: [{ t: 0, x: 0 }, { t: 0.35, x: -1.35, z: 0.25 }, { t: 0.6, x: -0.85 }, { t: 1, x: 0 }],
      shoulderL: [{ t: 0, x: 0 }, { t: 0.35, x: -1.15, z: -0.2 }, { t: 0.6, x: -0.7 }, { t: 1, x: 0 }],
      elbowR: [{ t: 0, x: 0 }, { t: 0.35, x: -0.7 }, { t: 0.6, x: 0.15 }, { t: 1, x: 0 }],
      elbowL: [{ t: 0, x: 0 }, { t: 0.35, x: -0.6 }, { t: 0.6, x: 0.1 }, { t: 1, x: 0 }],
      torso: [{ t: 0, x: 0 }, { t: 0.35, x: -0.22 }, { t: 0.62, x: 0.16 }, { t: 1, x: 0 }],
      hips: [{ t: 0, py: 0 }, { t: 0.35, py: -0.06 }, { t: 1, py: 0 }],
    },
  },

  dash: {
    duration: 0.36, priority: 3,
    tracks: {
      torso: [{ t: 0, x: 0 }, { t: 0.25, x: 0.5 }, { t: 1, x: 0 }],
      shoulderR: [{ t: 0, x: 0 }, { t: 0.25, x: 0.8 }, { t: 1, x: 0 }],
      shoulderL: [{ t: 0, x: 0 }, { t: 0.25, x: 0.8 }, { t: 1, x: 0 }],
      hips: [{ t: 0, py: 0 }, { t: 0.3, py: -0.1 }, { t: 1, py: 0 }],
      body: [{ t: 0, x: 0 }, { t: 0.25, x: 0.3 }, { t: 1, x: 0 }],
    },
  },

  /**
   * Emporschleudern. Die Bewegung kennt keine Y-Achse, deshalb ist das
   * Hochgehen reine Anzeige: das Modell schnellt hoch und fällt zurück,
   * während die Spiellogik einen Niederschlag verbucht.
   */
  launch: {
    duration: 0.8, priority: 4,
    tracks: {
      hips: [{ t: 0, py: 0, x: 0 }, { t: 0.35, py: 1.25, x: -0.4 }, { t: 0.75, py: 0.1, x: 0.5 }, { t: 1, py: 0, x: 0 }],
      torso: [{ t: 0, x: 0 }, { t: 0.35, x: -0.3 }, { t: 1, x: 0 }],
      kneeL: [{ t: 0, x: 0 }, { t: 0.4, x: 0.9 }, { t: 1, x: 0 }],
      kneeR: [{ t: 0, x: 0 }, { t: 0.4, x: 0.7 }, { t: 1, x: 0 }],
      body: [{ t: 0, py: 0 }, { t: 0.35, py: 1 }, { t: 1, py: 0 }],
    },
  },

  // --- Reaktionen ----------------------------------------------------------
  flinch: {
    duration: 0.28, priority: 1, weight: 0.85,
    tracks: {
      torso: [{ t: 0, x: 0 }, { t: 0.3, x: 0.3, y: 0.12 }, { t: 1, x: 0, y: 0 }],
      head: [{ t: 0, x: 0 }, { t: 0.3, x: -0.28 }, { t: 1, x: 0 }],
      shoulderR: [{ t: 0, x: 0 }, { t: 0.3, x: 0.35, z: 0.2 }, { t: 1, x: 0 }],
      shoulderL: [{ t: 0, x: 0 }, { t: 0.3, x: 0.35, z: -0.2 }, { t: 1, x: 0 }],
      neck: [{ t: 0, x: 0 }, { t: 0.3, x: 0.3 }, { t: 1, x: 0 }],
      body: [{ t: 0, py: 0 }, { t: 0.3, py: -0.06 }, { t: 1, py: 0 }],
    },
  },

  death: {
    duration: 1.1, priority: 9, hold: true, override: true,
    tracks: {
      hips: [{ t: 0, x: 0, py: 0 }, { t: 0.35, x: 0.5, py: -0.2 }, { t: 1, x: 1.42, py: -0.62 }],
      torso: [{ t: 0, x: 0 }, { t: 0.4, x: -0.35 }, { t: 1, x: -0.55, y: 0.3 }],
      head: [{ t: 0, x: 0 }, { t: 1, x: 0.45, z: 0.3 }],
      shoulderR: [{ t: 0, x: 0 }, { t: 0.5, x: -0.4 }, { t: 1, x: -0.75, z: 0.5 }],
      shoulderL: [{ t: 0, x: 0 }, { t: 0.5, x: -0.4 }, { t: 1, x: -0.75, z: -0.5 }],
      hipL: [{ t: 0, x: 0 }, { t: 1, x: -0.5 }],
      hipR: [{ t: 0, x: 0 }, { t: 1, x: -0.35 }],
      kneeL: [{ t: 0, x: 0 }, { t: 1, x: 0.95 }],
      kneeR: [{ t: 0, x: 0 }, { t: 1, x: 0.75 }],
      // Vierbeiner kippen zur Seite statt nach hinten.
      body: [{ t: 0, z: 0, py: 0 }, { t: 1, z: 1.35, py: -0.35 }],
      neck: [{ t: 0, x: 0 }, { t: 1, x: 0.6 }],
    },
  },
});

/** Welcher Clip gehört zu welcher Fähigkeiten-Animation. */
export const ABILITY_CLIPS = {
  swing: 'swing',
  thrust: 'thrust',
  shoot: 'shoot',
  cast: 'cast',
  dash: 'dash',
};
