import { Registry } from '../../core/Registry.js';
import { BipedLocomotion } from './BipedLocomotion.js';
import { QuadrupedLocomotion } from './QuadrupedLocomotion.js';

/** Animator wird per Registry über das Rig-Profil gewählt — kein switch. */
export const animators = new Registry('animators');

animators.register('biped', (model) => new BipedLocomotion(model));
animators.register('quadruped', (model) => new QuadrupedLocomotion(model));

export function createAnimator(model) {
  return animators.get(model.animation)(model);
}
