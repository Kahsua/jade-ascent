import { CONFIG } from '../../core/Config.js';

const NO_ARM = {};


/**
 * Prozedurale Lauf-/Idle-Animation für Zweibeiner.
 *
 * Fähigkeiten-Animationen liegen als Keyframe-Clips darüber (AnimationController);
 * diese Schicht kümmert sich nur um Gehen, Stehen und Atmen.
 *
 * setPose(): Eine ausgerüstete Waffe liefert eine Armhaltung
 * mit, die die Grundrotation der Arme verschiebt und den Schwung dämpft — ein
 * Bogen wird vorgestreckt gehalten, ein Großschwert beidhändig, ein Dolch
 * schwingt fast frei mit.
 *
 * Ab Phase 5 legt sich ein AnimationController darüber, der auf
 * "ability:cast" hört und Oberkörper-Posen überlagert. Die Beine bleiben hier.
 */
export class BipedLocomotion {
  constructor(model) {
    this.parts = model.parts;
    this.phase = 0;
    this.pose = null;
    this.hipRestY = this.parts.hips.position.y;
    this.torsoRestY = this.parts.torso.position.y;
    this.restZ = {
      L: this.parts.shoulderL.userData.restZ ?? this.parts.shoulderL.rotation.z,
      R: this.parts.shoulderR.userData.restZ ?? this.parts.shoulderR.rotation.z,
    };
  }

  /** @param {{mainArm?: object, offArm?: object}|null} pose */
  setPose(pose) {
    this.pose = pose;
  }

  #arm(side, armPose, swing, stride, blend, mirror) {
    const p = this.parts;
    const shoulder = p[`shoulder${side}`];
    const elbow = p[`elbow${side}`];
    const damping = armPose.swing ?? 1;

    shoulder.rotation.x = (armPose.x ?? 0) + swing * stride * 0.75 * damping * mirror;
    shoulder.rotation.y = (armPose.y ?? 0) * (side === 'L' ? -1 : 1);
    shoulder.rotation.z = this.restZ[side] + (armPose.z ?? 0) * (side === 'L' ? -1 : 1);
    elbow.rotation.x = (armPose.elbow ?? -0.22) - Math.max(0, swing * mirror) * 0.55 * blend * damping;
  }

  update(dt, speed, maxSpeed = CONFIG.player.walkSpeed) {
    const p = this.parts;
    const blend = Math.min(speed / maxSpeed, 1);

    this.phase += dt * (2.1 + blend * 7.4);
    const swing = Math.sin(this.phase);
    const stride = 0.82 * blend;

    p.hipL.rotation.x = swing * stride;
    p.hipR.rotation.x = -swing * stride;
    p.kneeL.rotation.x = Math.max(0, -swing) * 1.15 * blend;
    p.kneeR.rotation.x = Math.max(0, swing) * 1.15 * blend;
    p.ankleL.rotation.x = -p.kneeL.rotation.x * 0.4;
    p.ankleR.rotation.x = -p.kneeR.rotation.x * 0.4;

    this.#arm('R', this.pose?.mainArm ?? NO_ARM, swing, stride, blend, 1);
    this.#arm('L', this.pose?.offArm ?? NO_ARM, swing, stride, blend, -1);

    p.torso.rotation.x = 0; // Grundlage für additive Clips

    p.hips.rotation.y = swing * 0.09 * blend;
    p.torso.rotation.y = -swing * 0.13 * blend;
    p.hips.position.y = this.hipRestY + Math.abs(swing) * 0.042 * blend;

    const idle = 1 - blend;
    p.torso.position.y = this.torsoRestY + Math.sin(this.phase * 0.55) * 0.013 * idle;
    p.head.rotation.z = Math.sin(this.phase * 0.4) * 0.02 * idle;
  }
}
