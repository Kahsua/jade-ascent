import * as THREE from 'three';
import { heightAt } from '../game/Heightfield.js';

/**
 * Farbsprache der Elemente — durchgängig für Projektile, Flächen, Einschläge
 * und Aufladeeffekte, damit man am Effekt erkennt, was gerade wirkt.
 */
const STYLE = {
  fire: { color: '#e0743c', spark: '#ffc06a' },
  ice: { color: '#6fc7e8', spark: '#e6f7ff' },
  frost: { color: '#6fc7e8', spark: '#cfeeff' },
  lightning: { color: '#8fd6ff', spark: '#e8f6ff' },
  holy: { color: '#e8c463', spark: '#fff3cd' },
  dark: { color: '#8a6bb0', spark: '#d3bff0' },
  arcane: { color: '#57c79a', spark: '#b6f0dc' },
  physical: { color: '#e9e4d6', spark: '#ffffff' },
  slash: { color: '#e9e4d6', spark: '#ffffff' },
  impact: { color: '#ffd9a0', spark: '#fff0cf' },
};

export function paletteOf(style) {
  return STYLE[style] ?? STYLE.impact;
}

/**
 * Kurzlebige Treffer-, Flächen- und Blitzeffekte.
 *
 * Reine Anzeige: die Schicht hört auf "vfx:aoe", "vfx:impact" und "vfx:beam",
 * die von den Komponenten-Handlern gemeldet werden. Die Spiellogik weiß
 * nichts davon — sie kennt weder Farben noch Partikel.
 */
export class EffectLayer {
  #active = [];

  constructor({ scene, bus }) {
    this.scene = scene;

    this.ringGeometry = new THREE.RingGeometry(0.72, 1, 40);
    this.ringGeometry.rotateX(-Math.PI / 2);
    this.sparkGeometry = new THREE.IcosahedronGeometry(0.2, 0);
    this.shardGeometry = new THREE.ConeGeometry(0.12, 0.5, 4);

    bus.on('vfx:aoe', (payload) => this.#burst(payload.point, payload.radius, payload.style ?? 'fire', payload));
    bus.on('vfx:falling', ({ point, delay, style, radius, model }) => this.#falling(point, delay, style, radius, model));
    bus.on('vfx:impact', ({ position, element }) => this.#spark(position, element));
    bus.on('vfx:beam', ({ from, to, style }) => this.#beam(from, to, style ?? 'lightning'));
  }

  // --- Flächen -------------------------------------------------------------

  #burst(point, radius, style, payload = {}) {
    const palette = STYLE[style] ?? STYLE.fire;
    const y = heightAt(point.x, point.z) + 0.09;

    const material = new THREE.MeshBasicMaterial({
      color: palette.color, transparent: true, opacity: 0.85,
      side: THREE.DoubleSide, depthWrite: false,
    });

    // Kegel bekommen ein Tortenstück statt eines vollen Rings.
    let geometry = this.ringGeometry;
    if (payload.shape === 'cone') {
      const angle = payload.angle ?? 1.2;
      geometry = new THREE.RingGeometry(0.12, 1, 20, 1, -angle / 2, angle);
      geometry.rotateX(-Math.PI / 2);
    }

    const ring = new THREE.Mesh(geometry, material);
    if (payload.shape === 'cone') ring.rotation.y = payload.facing ?? 0;
    ring.position.set(point.x, y, point.z);
    ring.renderOrder = 3;
    this.scene.add(ring);
    this.#active.push({
      kind: 'ring', mesh: ring, material, life: 0, duration: 0.55,
      from: radius * 0.25, to: radius,
      geometry: payload.shape === 'cone' ? geometry : null,
    });

    if (payload.shape === 'cone') return;   // Kegel bleiben schlicht
    if (style === 'frost' || style === 'ice') this.#shards(point, radius, palette);
    else if (style !== 'slash') this.#embers(point, radius, palette);
  }

  /** Aufsteigende Funken für Feuer und Blitz. */
  #embers(point, radius, palette) {
    const count = 26;
    const positions = new Float32Array(count * 3);
    const velocities = [];

    for (let i = 0; i < count; i += 1) {
      const angle = Math.random() * Math.PI * 2;
      const distance = Math.sqrt(Math.random()) * radius;
      const x = point.x + Math.cos(angle) * distance;
      const z = point.z + Math.sin(angle) * distance;

      positions[i * 3] = x;
      positions[i * 3 + 1] = heightAt(x, z) + 0.1;
      positions[i * 3 + 2] = z;
      velocities.push({ x: (Math.random() - 0.5) * 0.6, y: 1.4 + Math.random() * 2.2, z: (Math.random() - 0.5) * 0.6 });
    }

    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));

    const material = new THREE.PointsMaterial({
      color: palette.spark, size: 0.16, transparent: true, opacity: 0.95, depthWrite: false,
    });
    const points = new THREE.Points(geometry, material);
    points.frustumCulled = false;
    this.scene.add(points);

    this.#active.push({ kind: 'embers', mesh: points, material, geometry, velocities, life: 0, duration: 0.9 });
  }

  /** Eisstacheln, die aus dem Boden fahren. */
  #shards(point, radius, palette) {
    const group = new THREE.Group();
    const material = new THREE.MeshStandardMaterial({
      color: palette.color, transparent: true, opacity: 0.8, roughness: 0.2, metalness: 0.1, flatShading: true,
    });

    for (let i = 0; i < 9; i += 1) {
      const angle = (i / 9) * Math.PI * 2 + Math.random() * 0.3;
      const distance = radius * (0.35 + Math.random() * 0.6);
      const x = point.x + Math.cos(angle) * distance;
      const z = point.z + Math.sin(angle) * distance;

      const shard = new THREE.Mesh(this.shardGeometry, material);
      shard.position.set(x, heightAt(x, z) - 0.2, z);
      shard.rotation.set((Math.random() - 0.5) * 0.5, Math.random() * Math.PI, (Math.random() - 0.5) * 0.5);
      shard.scale.setScalar(0.6 + Math.random() * 0.7);
      group.add(shard);
    }

    this.scene.add(group);
    this.#active.push({ kind: 'shards', mesh: group, material, life: 0, duration: 0.85, rise: 0.55 });
  }

  /**
   * Etwas fällt vom Himmel. Die Wirkung kommt verzögert aus der Spiellogik —
   * hier fällt nur das Objekt, damit die Wartezeit sichtbar ist.
   */
  #falling(point, delay, style, radius = 3, model = 'meteor') {
    const palette = STYLE[style] ?? STYLE.fire;
    const ground = heightAt(point.x, point.z);

    const geometry = model === 'shard'
      ? new THREE.ConeGeometry(0.28, 1, 5)
      : new THREE.IcosahedronGeometry(Math.max(0.5, radius * 0.18), 0);
    const material = new THREE.MeshBasicMaterial({ color: palette.spark });

    const mesh = new THREE.Mesh(geometry, material);
    mesh.position.set(point.x, ground + 24, point.z);
    if (model === 'shard') mesh.rotation.x = Math.PI;
    this.scene.add(mesh);

    // Zielmarkierung am Boden, solange es fällt.
    const markGeometry = new THREE.RingGeometry(radius * 0.88, radius, 32);
    markGeometry.rotateX(-Math.PI / 2);
    const markMaterial = new THREE.MeshBasicMaterial({
      color: palette.color, transparent: true, opacity: 0.4, side: THREE.DoubleSide, depthWrite: false,
    });
    const mark = new THREE.Mesh(markGeometry, markMaterial);
    mark.position.set(point.x, ground + 0.07, point.z);
    this.scene.add(mark);

    this.#active.push({
      kind: 'falling', mesh, material, geometry, life: 0, duration: Math.max(0.1, delay),
      from: ground + 24, to: ground + 0.4, mark, markMaterial, markGeometry,
    });
  }

  #spark(position, element = 'impact') {
    const palette = STYLE[element] ?? STYLE.impact;
    const material = new THREE.MeshBasicMaterial({ color: palette.spark, transparent: true, opacity: 0.9 });
    const mesh = new THREE.Mesh(this.sparkGeometry, material);
    mesh.position.set(position.x, position.y, position.z);
    this.scene.add(mesh);
    this.#active.push({ kind: 'spark', mesh, material, life: 0, duration: 0.28, from: 0.4, to: 1.6 });
  }

  /** Gezackter Blitz zwischen zwei Punkten — für den Kettenblitz. */
  #beam(from, to, style) {
    const palette = STYLE[style] ?? STYLE.lightning;
    const segments = 9;
    const points = [];

    const start = new THREE.Vector3(from.x, from.y, from.z);
    const end = new THREE.Vector3(to.x, to.y, to.z);
    const spread = start.distanceTo(end) * 0.08;

    for (let i = 0; i <= segments; i += 1) {
      const t = i / segments;
      const point = start.clone().lerp(end, t);
      if (i > 0 && i < segments) {
        point.x += (Math.random() - 0.5) * spread;
        point.y += (Math.random() - 0.5) * spread;
        point.z += (Math.random() - 0.5) * spread;
      }
      points.push(point);
    }

    const geometry = new THREE.BufferGeometry().setFromPoints(points);
    const material = new THREE.LineBasicMaterial({ color: palette.spark, transparent: true, opacity: 1, depthWrite: false });
    const line = new THREE.Line(geometry, material);
    line.renderOrder = 4;
    this.scene.add(line);

    this.#active.push({ kind: 'beam', mesh: line, material, geometry, life: 0, duration: 0.24 });
  }

  // --- Takt ----------------------------------------------------------------

  update(dt) {
    for (let i = this.#active.length - 1; i >= 0; i -= 1) {
      const effect = this.#active[i];
      effect.life += dt;
      const t = effect.life / effect.duration;

      if (t >= 1) {
        this.scene.remove(effect.mesh);
        effect.material.dispose();
        effect.geometry?.dispose();
        if (effect.mark) {
          this.scene.remove(effect.mark);
          effect.markMaterial.dispose();
          effect.markGeometry.dispose();
        }
        this.#active.splice(i, 1);
        continue;
      }

      if (effect.kind === 'ring') {
        effect.mesh.scale.setScalar(effect.from + (effect.to - effect.from) * Math.sqrt(t));
        effect.material.opacity = (1 - t) * 0.9;
      } else if (effect.kind === 'spark') {
        effect.mesh.scale.setScalar(effect.from + (effect.to - effect.from) * t);
        effect.mesh.rotation.y += dt * 8;
        effect.material.opacity = (1 - t) * 0.9;
      } else if (effect.kind === 'embers') {
        const positions = effect.geometry.attributes.position.array;
        for (let e = 0; e < effect.velocities.length; e += 1) {
          const velocity = effect.velocities[e];
          positions[e * 3] += velocity.x * dt;
          positions[e * 3 + 1] += velocity.y * dt;
          positions[e * 3 + 2] += velocity.z * dt;
          velocity.y -= 2.4 * dt; // etwas Schwere, damit sie kippen
        }
        effect.geometry.attributes.position.needsUpdate = true;
        effect.material.opacity = 1 - t * t;
      } else if (effect.kind === 'shards') {
        const rise = Math.min(1, t * 3);
        for (const shard of effect.mesh.children) shard.position.y += effect.rise * rise * dt * 2;
        effect.material.opacity = 0.8 * (1 - Math.max(0, (t - 0.5) * 2));
      } else if (effect.kind === 'falling') {
        // Beschleunigt nach unten, damit der Einschlag Wucht bekommt.
        effect.mesh.position.y = effect.from + (effect.to - effect.from) * (t * t);
        effect.mesh.rotation.x += dt * 5;
        effect.mesh.rotation.y += dt * 3;
        effect.markMaterial.opacity = 0.25 + Math.abs(Math.sin(effect.life * 9)) * 0.35;
      } else if (effect.kind === 'beam') {
        effect.material.opacity = 1 - t;
      }
    }
  }
}
