import * as THREE from 'three';
import { paletteOf } from './effects.js';

/**
 * Anzeige der Barrieren: eine Reihe schimmernder Segmente auf den runden
 * Kollidern, die die Bewegung ohnehin schon kennt. Gegen Ende wird die Mauer
 * durchscheinender — man sieht, dass sie gleich fällt.
 */
export class BarrierLayer {
  #walls = new Map();

  constructor({ scene, bus, barriers }) {
    this.scene = scene;
    this.barriers = barriers;

    bus.on('barrier:spawned', (barrier) => this.#add(barrier));
    bus.on('barrier:removed', ({ id }) => this.#remove(id));
  }

  #add(barrier) {
    const palette = paletteOf(barrier.style);
    const group = new THREE.Group();

    const material = new THREE.MeshStandardMaterial({
      color: palette.color, transparent: true, opacity: 0.5,
      roughness: 0.3, metalness: 0.2, emissive: palette.color, emissiveIntensity: 0.25,
      flatShading: true,
    });

    for (const collider of barrier.colliders) {
      const segment = new THREE.Mesh(new THREE.BoxGeometry(collider.radius * 2.1, 1.7, collider.radius * 1.2), material);
      segment.position.set(collider.x, collider.y + 0.8, collider.z);
      segment.rotation.y = -barrier.facing;
      segment.castShadow = false;
      group.add(segment);
    }

    this.scene.add(group);
    this.#walls.set(barrier.id, { group, material });
  }

  #remove(id) {
    const entry = this.#walls.get(id);
    if (!entry) return;
    this.scene.remove(entry.group);
    entry.group.traverse((child) => child.geometry?.dispose?.());
    entry.material.dispose();
    this.#walls.delete(id);
  }

  sync(dt) {
    for (const barrier of this.barriers.all()) {
      const entry = this.#walls.get(barrier.id);
      if (!entry) continue;

      const fade = Math.min(1, barrier.remaining / 1.5);
      entry.material.opacity = 0.2 + fade * 0.35;
      for (const segment of entry.group.children) {
        segment.position.y += Math.sin(barrier.remaining * 4 + segment.position.x) * dt * 0.05;
      }
    }
  }
}
