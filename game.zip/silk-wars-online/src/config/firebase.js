/**
 * Firebase-Zugangsdaten.
 *
 * Solange hier null steht, speichert das Spiel im Browser — kein Konto, keine
 * Netzverbindung nötig. Zum Umstellen die Konfiguration aus der Firebase-
 * Konsole (Projekteinstellungen -> Meine Apps -> Web) eintragen:
 *
 * export const FIREBASE_CONFIG = {
 *   apiKey: '...',
 *   authDomain: 'DEIN-PROJEKT.firebaseapp.com',
 *   projectId: 'DEIN-PROJEKT',
 *   storageBucket: 'DEIN-PROJEKT.appspot.com',
 *   messagingSenderId: '...',
 *   appId: '...',
 * };
 *
 * Zusätzlich in der Konsole nötig:
 *   Authentication -> Anmeldemethode -> Anonym aktivieren
 *   Firestore-Datenbank anlegen und die Regeln aus FirebaseAdapter.js setzen
 *
 * Am Spielcode ändert sich dadurch nichts.
 */
export const FIREBASE_CONFIG = null;
