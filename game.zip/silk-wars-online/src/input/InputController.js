/**
 * Rohe Eingabe einsammeln — keine Spiellogik, keine Kamera-Mathematik.
 *
 * Bewusste Entscheidung: Kamera drehen nur bei gehaltener rechter Maustaste
 * (mit Pointer Lock). Die linke Maustaste bleibt frei für Ziel-Auswahl und
 * Boden-Zielen ab Phase 4 — genau das GW2-Muster.
 */
export class InputController {
  #keys = new Set();
  #look = { x: 0, y: 0 };
  #zoom = 0;
  #clicks = [];
  #rotating = false;
  #canvas;
  #disposers = [];

  constructor(canvas) {
    this.#canvas = canvas;
    this.pointerLocked = false;
    /** Mausposition in Clip-Koordinaten (-1..1) für Raycasts. */
    this.pointer = { x: 0, y: 0 };
    this.pointerStamp = 0;
    this.#bind();
  }

  #bind() {
    const on = (target, type, handler, options) => {
      target.addEventListener(type, handler, options);
      this.#disposers.push(() => target.removeEventListener(type, handler, options));
    };

    on(window, 'keydown', (event) => {
      if (event.target instanceof HTMLInputElement || event.target instanceof HTMLTextAreaElement) return;
      this.#keys.add(event.code);
      // Tab würde den Fokus verschieben, F1 die Browser-Hilfe öffnen.
      if (event.code === 'F3' || event.code === 'Space' || event.code === 'Tab'
        || /^F[1-8]$/.test(event.code)) event.preventDefault();
    });

    on(window, 'keyup', (event) => this.#keys.delete(event.code));
    on(window, 'blur', () => {
      this.#keys.clear();
      this.#rotating = false;
    });

    on(this.#canvas, 'contextmenu', (event) => event.preventDefault());

    on(this.#canvas, 'mousedown', (event) => {
      // Jeder Klick wird gemerkt; wer ihn braucht, holt ihn im nächsten Frame.
      this.#clicks.push({ button: event.button, x: this.pointer.x, y: this.pointer.y });

      if (event.button !== 2) return;
      event.preventDefault();
      this.#rotating = true;
      this.#canvas.requestPointerLock?.();
    });

    on(window, 'mouseup', (event) => {
      if (event.button !== 2) return;
      this.#rotating = false;
      if (document.pointerLockElement === this.#canvas) document.exitPointerLock();
    });

    on(document, 'pointerlockchange', () => {
      this.pointerLocked = document.pointerLockElement === this.#canvas;
      if (!this.pointerLocked) this.#rotating = false;
    });

    on(window, 'mousemove', (event) => {
      if (this.#rotating) {
        this.#look.x += event.movementX ?? 0;
        this.#look.y += event.movementY ?? 0;
        return; // Bei gefangenem Zeiger sind clientX/Y bedeutungslos.
      }
      this.pointer.x = (event.clientX / window.innerWidth) * 2 - 1;
      this.pointer.y = -(event.clientY / window.innerHeight) * 2 + 1;
      this.pointerStamp = performance.now();
    });

    on(this.#canvas, 'wheel', (event) => {
      event.preventDefault();
      this.#zoom += event.deltaY;
    }, { passive: false });
  }

  isDown(code) {
    return this.#keys.has(code);
  }

  /** Lokale Absicht: z = vorwärts, x = rechts. Normalisiert. */
  getMoveIntent() {
    let x = 0;
    let z = 0;
    if (this.isDown('KeyW') || this.isDown('ArrowUp')) z += 1;
    if (this.isDown('KeyS') || this.isDown('ArrowDown')) z -= 1;
    if (this.isDown('KeyD') || this.isDown('ArrowRight')) x += 1;
    if (this.isDown('KeyA') || this.isDown('ArrowLeft')) x -= 1;

    const length = Math.hypot(x, z);
    if (length === 0) return { x: 0, z: 0 };
    return { x: x / length, z: z / length };
  }

  /** Maus-Delta seit dem letzten Frame; setzt den Akkumulator zurück. */
  consumeLook() {
    const look = { x: this.#look.x, y: this.#look.y };
    this.#look.x = 0;
    this.#look.y = 0;
    return look;
  }

  /** Klicks seit dem letzten Frame, jeweils mit der Zeigerposition. */
  consumeClicks() {
    const clicks = this.#clicks;
    this.#clicks = [];
    return clicks;
  }

  consumeZoom() {
    const zoom = this.#zoom;
    this.#zoom = 0;
    return zoom;
  }

  dispose() {
    for (const off of this.#disposers) off();
    this.#disposers.length = 0;
  }
}
