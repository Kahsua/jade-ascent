/**
 * Führt mehrere Eingabequellen zu einer zusammen.
 *
 * Kamera und Spiellogik fragen weiterhin dieselbe Schnittstelle ab und wissen
 * nicht, ob gerade eine Tastatur, ein Finger oder beides bedient wird. Genau
 * deshalb ließ sich die Touch-Steuerung nachrüsten, ohne Kamera, Bewegung oder
 * Zielsystem anzufassen.
 */
export class InputRouter {
  constructor(sources = []) {
    this.sources = sources.filter(Boolean);
  }

  add(source) {
    if (source) this.sources.push(source);
    return this;
  }

  /** Zuletzt bewegter Zeiger gewinnt — Maus oder Finger. */
  get pointer() {
    let best = null;
    let stamp = -1;
    for (const source of this.sources) {
      if (!source.pointer) continue;
      const sourceStamp = source.pointerStamp ?? 0;
      if (sourceStamp >= stamp) {
        stamp = sourceStamp;
        best = source.pointer;
      }
    }
    return best ?? { x: 0, y: 0 };
  }

  /** Erste Quelle mit echter Eingabe gewinnt — der Stick schlägt WASD. */
  getMoveIntent() {
    let result = { x: 0, z: 0 };
    for (const source of this.sources) {
      const intent = source.getMoveIntent?.() ?? { x: 0, z: 0 };
      if (intent.x !== 0 || intent.z !== 0) result = intent;
    }
    return result;
  }

  consumeLook() {
    const total = { x: 0, y: 0 };
    for (const source of this.sources) {
      const look = source.consumeLook?.() ?? { x: 0, y: 0 };
      total.x += look.x;
      total.y += look.y;
    }
    return total;
  }

  consumeZoom() {
    let total = 0;
    for (const source of this.sources) total += source.consumeZoom?.() ?? 0;
    return total;
  }

  consumeClicks() {
    const clicks = [];
    for (const source of this.sources) clicks.push(...(source.consumeClicks?.() ?? []));
    return clicks;
  }

  isDown(code) {
    return this.sources.some((source) => source.isDown?.(code));
  }

  dispose() {
    for (const source of this.sources) source.dispose?.();
  }
}
