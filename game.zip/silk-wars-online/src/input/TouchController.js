import { CONFIG } from '../core/Config.js';

/**
 * Berührungseingabe mit derselben Schnittstelle wie der InputController:
 * getMoveIntent / consumeLook / consumeZoom / consumeClicks / pointer.
 *
 * Aufteilung der Gesten:
 *   linker Daumen  virtueller Stick -> Laufrichtung
 *   ein Finger auf der Welt, gezogen -> Kamera drehen
 *   ein Finger, kurz getippt         -> Ziel wählen bzw. Bodenpunkt bestätigen
 *   zwei Finger, gespreizt           -> zoomen
 *   zwei Finger, kurz getippt        -> abbrechen (entspricht Rechtsklick)
 */
const TAP_MOVE_LIMIT = 14;   // px
const TAP_TIME_LIMIT = 320;  // ms

export class TouchController {
  #clicks = [];
  #look = { x: 0, y: 0 };
  #zoom = 0;
  #stick = { x: 0, z: 0 };
  #disposers = [];

  constructor(canvas, { stickElement, knobElement, radius = 52 } = {}) {
    this.canvas = canvas;
    this.stickElement = stickElement;
    this.knobElement = knobElement;
    this.radius = radius;
    this.pointer = { x: 0, y: 0 };
    this.pointerStamp = 0;

    this.stickTouch = null;
    this.stickOrigin = { x: 0, y: 0 };
    this.gesture = null;
    this.pinch = null;

    this.#bindStick();
    this.#bindWorld();
  }

  // --- Virtueller Stick ----------------------------------------------------

  #bindStick() {
    if (!this.stickElement) return;

    const start = (event) => {
      const touch = event.changedTouches[0];
      this.stickTouch = touch.identifier;
      const rect = this.stickElement.getBoundingClientRect();
      this.stickOrigin = { x: rect.left + rect.width / 2, y: rect.top + rect.height / 2 };
      this.stickElement.classList.add('is-active');
      this.#updateStick(touch);
      event.preventDefault();
    };

    const move = (event) => {
      if (this.stickTouch === null) return;
      for (const touch of event.changedTouches) {
        if (touch.identifier === this.stickTouch) this.#updateStick(touch);
      }
      event.preventDefault();
    };

    const end = (event) => {
      for (const touch of event.changedTouches) {
        if (touch.identifier !== this.stickTouch) continue;
        this.stickTouch = null;
        this.#stick = { x: 0, z: 0 };
        this.stickElement.classList.remove('is-active');
        if (this.knobElement) this.knobElement.style.transform = 'translate(-50%, -50%)';
      }
    };

    this.#on(this.stickElement, 'touchstart', start, { passive: false });
    this.#on(window, 'touchmove', move, { passive: false });
    this.#on(window, 'touchend', end);
    this.#on(window, 'touchcancel', end);
  }

  #updateStick(touch) {
    let dx = touch.clientX - this.stickOrigin.x;
    let dy = touch.clientY - this.stickOrigin.y;
    const length = Math.hypot(dx, dy);

    if (length > this.radius) {
      dx = (dx / length) * this.radius;
      dy = (dy / length) * this.radius;
    }

    if (this.knobElement) {
      this.knobElement.style.transform = `translate(calc(-50% + ${dx.toFixed(0)}px), calc(-50% + ${dy.toFixed(0)}px))`;
    }

    // Richtung und Stärke aus den bereits begrenzten Werten ableiten —
    // sonst bliebe der Ausschlag am Rand unter 1.
    const clamped = Math.hypot(dx, dy);
    const magnitude = Math.min(1, clamped / this.radius);

    // Kleine Totzone, damit ein ruhender Daumen nicht schleicht.
    if (magnitude < 0.18) return void (this.#stick = { x: 0, z: 0 });

    this.#stick = { x: (dx / clamped) * magnitude, z: (-dy / clamped) * magnitude };
  }

  // --- Kamera, Tippen, Zoom ------------------------------------------------

  #bindWorld() {
    const start = (event) => {
      if (event.touches.length === 2) {
        this.pinch = { distance: this.#pinchDistance(event.touches), moved: false, time: performance.now() };
        this.gesture = null;
        return;
      }

      const touch = event.changedTouches[0];
      this.gesture = {
        id: touch.identifier,
        startX: touch.clientX,
        startY: touch.clientY,
        lastX: touch.clientX,
        lastY: touch.clientY,
        time: performance.now(),
        moved: false,
      };
      this.#setPointer(touch);
    };

    const move = (event) => {
      if (this.pinch && event.touches.length === 2) {
        const distance = this.#pinchDistance(event.touches);
        this.#zoom += (this.pinch.distance - distance) * 2.2;
        this.pinch.distance = distance;
        this.pinch.moved = true;
        event.preventDefault();
        return;
      }

      if (!this.gesture) return;
      for (const touch of event.changedTouches) {
        if (touch.identifier !== this.gesture.id) continue;

        this.#look.x += (touch.clientX - this.gesture.lastX) * 1.35;
        this.#look.y += (touch.clientY - this.gesture.lastY) * 1.35;
        this.gesture.lastX = touch.clientX;
        this.gesture.lastY = touch.clientY;

        if (Math.hypot(touch.clientX - this.gesture.startX, touch.clientY - this.gesture.startY) > TAP_MOVE_LIMIT) {
          this.gesture.moved = true;
        }
        this.#setPointer(touch);
      }
      event.preventDefault();
    };

    const end = (event) => {
      if (this.pinch && event.touches.length < 2) {
        const quick = performance.now() - this.pinch.time < TAP_TIME_LIMIT;
        // Zwei-Finger-Tipp bricht ab, wie die rechte Maustaste.
        if (!this.pinch.moved && quick) this.#clicks.push({ button: 2, x: this.pointer.x, y: this.pointer.y });
        this.pinch = null;
        this.gesture = null;
        return;
      }

      if (!this.gesture) return;
      for (const touch of event.changedTouches) {
        if (touch.identifier !== this.gesture.id) continue;

        const quick = performance.now() - this.gesture.time < TAP_TIME_LIMIT;
        if (!this.gesture.moved && quick) {
          this.#setPointer(touch);
          this.#clicks.push({ button: 0, x: this.pointer.x, y: this.pointer.y });
        }
        this.gesture = null;
      }
    };

    this.#on(this.canvas, 'touchstart', start, { passive: false });
    this.#on(this.canvas, 'touchmove', move, { passive: false });
    this.#on(window, 'touchend', end);
    this.#on(window, 'touchcancel', end);
  }

  #pinchDistance(touches) {
    return Math.hypot(touches[0].clientX - touches[1].clientX, touches[0].clientY - touches[1].clientY);
  }

  #setPointer(touch) {
    this.pointer.x = (touch.clientX / window.innerWidth) * 2 - 1;
    this.pointer.y = -(touch.clientY / window.innerHeight) * 2 + 1;
    this.pointerStamp = performance.now();
  }

  #on(target, type, handler, options) {
    target.addEventListener(type, handler, options);
    this.#disposers.push(() => target.removeEventListener(type, handler, options));
  }

  // --- Schnittstelle -------------------------------------------------------

  get isSteering() {
    return this.stickTouch !== null;
  }

  getMoveIntent() {
    return { x: this.#stick.x, z: this.#stick.z };
  }

  consumeLook() {
    const look = { x: this.#look.x * CONFIG.touch.lookScale, y: this.#look.y * CONFIG.touch.lookScale };
    this.#look.x = 0;
    this.#look.y = 0;
    return look;
  }

  consumeZoom() {
    const zoom = this.#zoom;
    this.#zoom = 0;
    return zoom;
  }

  consumeClicks() {
    const clicks = this.#clicks;
    this.#clicks = [];
    return clicks;
  }

  isDown() {
    return false;
  }

  dispose() {
    for (const off of this.#disposers) off();
    this.#disposers.length = 0;
  }
}
