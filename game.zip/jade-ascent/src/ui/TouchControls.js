/**
 * Bildschirmknöpfe für Geräte ohne Tastatur.
 *
 * Sie senden nur "input:command" — dieselben Befehle, die auch die Tastatur
 * auslöst. Dadurch gibt es keine zweite Steuerungslogik, die auseinanderlaufen
 * könnte.
 */
const BUTTONS = [
  { command: 'dodge', label: '»', title: 'Ausweichen' },
  { command: 'cycleTarget', label: '⌖', title: 'Nächstes Ziel' },
  { command: 'toggleAuto', label: '⚔', title: 'Autoattack' },
  { command: 'cancel', label: '×', title: 'Abbrechen' },
];

const WINDOWS = [
  { panel: 'character', label: 'C', title: 'Charakter' },
  { panel: 'mastery', label: 'K', title: 'Masteries' },
  { panel: 'equipment', label: 'I', title: 'Ausrüstung' },
];

export class TouchControls {
  constructor(root, { bus }) {
    this.root = root;
    this.bus = bus;

    root.querySelector('[data-role="cluster"]').innerHTML = BUTTONS
      .map((entry) => `<button type="button" class="touch-button" data-command="${entry.command}" title="${entry.title}">${entry.label}</button>`)
      .join('');

    root.querySelector('[data-role="windows"]').innerHTML = WINDOWS
      .map((entry) => `<button type="button" class="touch-button touch-button-small" data-panel="${entry.panel}" title="${entry.title}">${entry.label}</button>`)
      .join('');

    root.addEventListener('click', (event) => {
      const button = event.target.closest('button');
      if (!button) return;

      if (button.dataset.command) bus.emit('input:command', { name: button.dataset.command });
      else if (button.dataset.panel) bus.emit('input:command', { name: 'panel', args: [button.dataset.panel] });
    });

    // Verhindert, dass ein Tippen auf einen Knopf zusätzlich als Weltklick ankommt.
    root.addEventListener('touchstart', (event) => event.stopPropagation(), { passive: true });
  }

  enable() {
    this.root.hidden = false;
    document.body.classList.add('touch-mode');
  }
}
