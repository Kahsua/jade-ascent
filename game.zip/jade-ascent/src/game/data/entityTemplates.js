import { Registry } from '../../core/Registry.js';

/**
 * Wer in der Welt existieren kann — als Daten.
 *
 * "model" verweist in die AssetRegistry, "behavior" wird ab Phase 7 von der
 * KI-Zustandsmaschine gelesen. Ein neues Monster ist ein Eintrag hier plus
 * ein Körper-Template, kein neuer Code.
 */
export const entityTemplates = new Registry('entities');

entityTemplates.registerAll({
  'player': {
    name: 'Wanderer',
    model: 'character.player',
    faction: 'player',
  },
  'npc.villager': {
    name: 'Dorfbewohner',
    experience: 6,
    model: 'character.villager',
    faction: 'neutral',
    respawn: 30,
    attributes: { strength: 4, dexterity: 5, intelligence: 4, vitality: 6 },
    ai: {
      behavior: 'passive', fleeOnDamage: true, fleeDuration: 6,
      aggroRadius: 0, leashRange: 28, wanderRadius: 7, moveSpeed: 3.4,
    },
  },
  'npc.warrior': {
    name: 'Wachsoldatin',
    experience: 70,
    model: 'character.warrior',
    faction: 'neutral',
    level: 4,
    respawn: 35,
    attributes: { strength: 11, dexterity: 6, intelligence: 4, vitality: 10 },
    equipment: { mainHand: 'item.greatsword.oak', head: 'item.helm.iron' },
    loot: [{ item: 'item.greatsword.oak', chance: 0.5 }, { item: 'item.helm.iron', chance: 0.3 }],
    ai: {
      behavior: 'neutral', attack: 'attack.greatsword',
      aggroRadius: 0, leashRange: 20, chaseRange: 24, wanderRadius: 3, moveSpeed: 4.6,
    },
  },
  'npc.archer': {
    name: 'Jäger',
    experience: 55,
    model: 'character.archer',
    faction: 'neutral',
    level: 3,
    respawn: 35,
    attributes: { strength: 6, dexterity: 12, intelligence: 5, vitality: 6 },
    equipment: { mainHand: 'item.bow.hunter', chest: 'item.chest.leather' },
    loot: [{ item: 'item.bow.hunter', chance: 0.4 }, { item: 'item.boots.swift', chance: 0.25 }],
    ai: {
      behavior: 'neutral', attack: 'attack.bow',
      aggroRadius: 0, leashRange: 24, chaseRange: 28, wanderRadius: 3, moveSpeed: 4.8,
    },
  },
  'npc.mage': {
    name: 'Magierin',
    experience: 50,
    model: 'character.mage',
    faction: 'neutral',
    level: 3,
    respawn: 35,
    attributes: { strength: 3, dexterity: 6, intelligence: 13, vitality: 5 },
    equipment: { mainHand: 'item.staff.apprentice' },
    loot: [{ item: 'item.staff.apprentice', chance: 0.4 }, { item: 'item.sword.jade', chance: 0.15 }],
    ai: {
      behavior: 'passive', fleeOnDamage: true, fleeDuration: 5,
      aggroRadius: 0, leashRange: 26, wanderRadius: 4, moveSpeed: 3.8,
    },
  },
  'beast.wolf': {
    name: 'Waldwolf',
    experience: 30,
    model: 'beast.wolf',
    faction: 'hostile',
    level: 2,
    respawn: 20,
    masteryPoints: 0,   // Bosse setzen hier später einen Wert
    loot: [{ item: 'item.dagger.swift', chance: 0.12 }, { item: 'item.boots.leather', chance: 0.2 }],
    attributes: { strength: 8, dexterity: 9, intelligence: 2, vitality: 7 },
    ai: {
      behavior: 'aggressive', attack: 'attack.bite',
      aggroFactions: ['player'],
      aggroRadius: 12, leashRange: 24, chaseRange: 30, wanderRadius: 9, moveSpeed: 5.4,
    },
  },
});
