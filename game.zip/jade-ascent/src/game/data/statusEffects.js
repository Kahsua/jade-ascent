import { Registry } from '../../core/Registry.js';

/**
 * Statuseffekte als Daten — nicht als Sonderlogik pro Skill.
 *
 * Felder:
 *   blocks      welche Gates gesperrt werden: 'move' | 'act' | 'cast'
 *   modifiers   moveSpeed / damageTaken / damageDealt, jeweils relativ
 *               (-0.4 = 40 % langsamer, +0.3 = 30 % mehr Schaden erlitten)
 *   dot         Schaden pro Sekunde, mit Schadensschule
 *   impulse     Rückstoß; wird beim Anwenden einmalig in Bewegung übersetzt
 *   invulnerable  hebt jeden Schaden auf
 *   imbue       Waffenverzauberung: Zusatzschaden und On-Hit-Effekt
 *   stacking    'refresh' (Dauer erneuern) | 'stack' (bis maxStacks)
 */
export const statusEffects = new Registry('statusEffects');

statusEffects.registerAll({
  slow: {
    name: 'Verlangsamt', glyph: '❆', category: 'debuff',
    modifiers: { moveSpeed: -0.4 }, stacking: 'refresh',
  },
  root: {
    name: 'Gefesselt', glyph: '⛓', category: 'debuff',
    blocks: ['move'], stacking: 'refresh',
  },
  stun: {
    name: 'Betäubt', glyph: '✷', category: 'debuff',
    blocks: ['move', 'act', 'cast'], stacking: 'refresh',
  },
  freeze: {
    name: 'Eingefroren', glyph: '❄', category: 'debuff',
    blocks: ['move', 'act', 'cast'], modifiers: { damageTaken: 0.2 }, stacking: 'refresh',
  },
  knockdown: {
    name: 'Niedergeschlagen', glyph: '↓', category: 'debuff',
    blocks: ['move', 'act', 'cast'], stacking: 'refresh',
  },
  knockback: {
    name: 'Zurückgestoßen', glyph: '↗', category: 'debuff',
    impulse: { distance: 4.5, duration: 0.25 }, stacking: 'refresh',
  },
  silence: {
    name: 'Verstummt', glyph: '⊘', category: 'debuff',
    blocks: ['cast'], stacking: 'refresh',
  },
  burn: {
    name: 'Brennt', glyph: '🔥', category: 'debuff',
    dot: { school: 'magic', amount: 4 }, stacking: 'stack', maxStacks: 3,
  },
  poison: {
    name: 'Vergiftet', glyph: '☠', category: 'debuff',
    dot: { school: 'magic', amount: 3 }, stacking: 'stack', maxStacks: 5,
  },
  bleed: {
    name: 'Blutet', glyph: '≈', category: 'debuff',
    dot: { school: 'physical', amount: 3.5 }, stacking: 'stack', maxStacks: 4,
  },
  vulnerable: {
    name: 'Verwundbar', glyph: '◈', category: 'debuff',
    modifiers: { damageTaken: 0.3 }, stacking: 'refresh',
  },
  weaken: {
    name: 'Geschwächt', glyph: '▽', category: 'debuff',
    modifiers: { damageDealt: -0.3 }, stacking: 'refresh',
  },
  invulnerable: {
    name: 'Unverwundbar', glyph: '◇', category: 'buff',
    invulnerable: true, stacking: 'refresh',
  },
  haste: {
    name: 'Hast', glyph: '⏵', category: 'buff',
    modifiers: { moveSpeed: 0.25, damageDealt: 0.1 }, stacking: 'refresh',
  },
  'imbue.fire': {
    name: 'Feuerbann', glyph: '☄', category: 'buff', stacking: 'refresh',
    // Zusatzschaden auf Waffentreffer. Der Anteil hängt vom Verhältnis
    // STR:INT ab — ein reiner Krieger holt daraus wenig, ein Hybrid viel.
    imbue: { school: 'magic', coefficient: 0.85, onHit: { effect: 'burn', duration: 4 } },
  },
});
