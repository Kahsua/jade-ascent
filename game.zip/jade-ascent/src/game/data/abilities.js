import { Registry } from '../../core/Registry.js';

/**
 * Fähigkeiten sind Datendefinitionen mit einer Liste von KOMPONENTEN.
 *
 * Ein AbilityExecutor liest diese Liste und ruft für jeden Komponententyp
 * einen wiederverwendbaren Handler auf. Eine neue Fähigkeit ist ein neuer
 * Eintrag hier — kein neuer Code.
 *
 * Komponententypen (siehe abilities/componentHandlers.js):
 *   damage         Schaden auf das aktuelle Ziel der Komponente
 *   projectile     Geschoss, das seine eigenen onHit-Komponenten mitführt
 *   aoe            Fläche; führt verschachtelte Komponenten pro Getroffenem aus
 *   movement       Ausweichschritt / Sprung
 *   resource       Leben oder Mana verändern
 *   status_effect  Buff/Debuff (Registry und Controller kommen in Phase 6)
 *
 * "targeting" bestimmt, was die Eingabe verlangt: 'target' | 'ground' | 'self'.
 * "animation" ist ein Hinweis an die Anzeige, keine Spiellogik.
 */
export const abilities = new Registry('abilities');

abilities.registerAll({
  'ability.strike': {
    name: 'Hieb', glyph: '⚔', targeting: 'target', range: 2.8, cooldown: 1.2, mana: 0,
    animation: 'swing',
    description: 'Nahkampfschlag mit der Haupthand.',
    components: [
      { type: 'damage', school: 'physical', base: 6, coefficient: 1 },
    ],
  },

  'ability.shot': {
    name: 'Schuss', glyph: '➹', targeting: 'target', range: 20, cooldown: 1, mana: 4,
    animation: 'shoot',
    description: 'Gezielter Pfeil auf ein Ziel.',
    components: [
      {
        type: 'projectile', speed: 34, model: 'arrow', lifetime: 3,
        onHit: [{ type: 'damage', school: 'physical', base: 4, coefficient: 1.15 }],
      },
    ],
  },

  'ability.firestorm': {
    name: 'Feuersturm', glyph: '✹', targeting: 'ground', range: 14, radius: 3.6, cooldown: 8, mana: 22,
    animation: 'cast',
    description: 'Flächenschaden auf einem markierten Bodenpunkt.',
    components: [
      {
        type: 'aoe', at: 'point', radius: 3.6, vfx: 'fire',
        components: [
          { type: 'damage', school: 'magic', base: 14, coefficient: 1.4 },
          { type: 'status_effect', effect: 'burn', duration: 5 },
        ],
      },
    ],
  },

  'ability.frostnova': {
    name: 'Frostnova', glyph: '❄', targeting: 'self', radius: 5, cooldown: 12, mana: 18,
    animation: 'cast',
    description: 'Eisstoß rund um dich, verlangsamt Getroffene.',
    components: [
      {
        type: 'aoe', at: 'self', radius: 5, vfx: 'frost',
        components: [
          { type: 'damage', school: 'magic', base: 8, coefficient: 0.7 },
          { type: 'status_effect', effect: 'slow', duration: 4, magnitude: 0.4 },
        ],
      },
    ],
  },

  'ability.thunderclap': {
    name: 'Donnerschlag', glyph: '✷', targeting: 'self', radius: 6, cooldown: 18, mana: 16,
    animation: 'swing',
    description: 'Stößt alles im Umkreis zurück und betäubt es kurz.',
    components: [
      {
        type: 'aoe', at: 'self', radius: 6, vfx: 'slash',
        components: [
          { type: 'damage', school: 'physical', base: 10, coefficient: 0.8 },
          { type: 'status_effect', effect: 'knockback' },
          { type: 'status_effect', effect: 'stun', duration: 1.6 },
        ],
      },
    ],
  },

  'ability.heal': {
    name: 'Heilstrom', glyph: '✚', targeting: 'self', cooldown: 10, mana: 20,
    animation: 'cast',
    description: 'Stellt sofort Leben wieder her.',
    components: [
      { type: 'resource', resource: 'health', at: 'self', base: 18, coefficient: 0.9 },
    ],
  },

  'ability.warcry': {
    name: 'Kampfschrei', glyph: '⚑', targeting: 'self', radius: 8, cooldown: 25, mana: 10,
    animation: 'cast',
    description: 'Stärkt dich kurzzeitig.',
    components: [
      { type: 'status_effect', effect: 'haste', at: 'self', duration: 8, magnitude: 0.25 },
    ],
  },

  'ability.imbue.fire': {
    name: 'Feuerbann', glyph: '☄', targeting: 'self', cooldown: 30, mana: 25,
    animation: 'cast',
    description: 'Verzaubert die Waffe zeitweise mit Feuerschaden.',
    components: [
      { type: 'status_effect', effect: 'imbue.fire', at: 'self', duration: 30 },
    ],
  },

  'ability.chainlightning': {
    name: 'Kettenblitz', glyph: '⚡', targeting: 'target', range: 16, cooldown: 9, mana: 20,
    animation: 'cast',
    description: 'Blitz, der auf bis zu drei weitere Gegner überspringt.',
    components: [
      {
        type: 'chain', jumps: 3, range: 7, falloff: 0.75,
        components: [{ type: 'damage', school: 'magic', base: 9, coefficient: 1 }],
      },
    ],
  },

  'ability.curse': {
    name: 'Fluch', glyph: '☾', targeting: 'target', range: 14, cooldown: 14, mana: 14,
    animation: 'cast',
    description: 'Macht ein Ziel verwundbar und schwächt seine Angriffe.',
    components: [
      { type: 'status_effect', effect: 'vulnerable', duration: 10 },
      { type: 'status_effect', effect: 'weaken', duration: 10 },
    ],
  },

  'ability.dodge': {
    name: 'Ausweichen', glyph: '»', targeting: 'self', cooldown: 0, charges: 2, chargeTime: 7, mana: 0,
    basic: true,
    animation: 'dash', global: false,
    description: 'Kurzer Ausweichschritt mit kurzer Unverwundbarkeit. Zwei Ladungen.',
    components: [
      { type: 'movement', mode: 'dash', distance: 5.2, duration: 0.28 },
      { type: 'status_effect', effect: 'invulnerable', at: 'self', duration: 0.4 },
    ],
  },

  // --- Autoattacks pro Waffentyp ------------------------------------------
  'attack.unarmed': {
    name: 'Faustschlag', glyph: '✊', targeting: 'target', range: 2.2, cooldown: 1.1, mana: 0,
    animation: 'swing', hidden: true,
    components: [{ type: 'damage', school: 'physical', base: 2, coefficient: 0.5 }],
  },
  'attack.sword': {
    name: 'Schwerthieb', glyph: '⚔', targeting: 'target', range: 2.8, cooldown: 1.1, mana: 0,
    animation: 'swing', hidden: true,
    components: [{ type: 'damage', school: 'physical', base: 4, coefficient: 0.85 }],
  },
  'attack.dagger': {
    name: 'Dolchstich', glyph: '🗡', targeting: 'target', range: 2.2, cooldown: 0.65, mana: 0,
    animation: 'swing', hidden: true,
    components: [{ type: 'damage', school: 'physical', base: 2, coefficient: 0.55 }],
  },
  'attack.greatsword': {
    name: 'Weiter Schwung', glyph: '⚔', targeting: 'target', range: 3.4, cooldown: 1.9, mana: 0,
    animation: 'swing', hidden: true,
    components: [
      {
        type: 'aoe', at: 'target', radius: 2.2, vfx: 'slash',
        components: [{ type: 'damage', school: 'physical', base: 7, coefficient: 1.15 }],
      },
    ],
  },
  'attack.spear': {
    name: 'Stoß', glyph: '➶', targeting: 'target', range: 3.8, cooldown: 1.3, mana: 0,
    animation: 'swing', hidden: true,
    components: [{ type: 'damage', school: 'physical', base: 5, coefficient: 0.95 }],
  },
  'attack.bow': {
    name: 'Pfeilschuss', glyph: '➹', targeting: 'target', range: 22, cooldown: 1.25, mana: 0,
    animation: 'shoot', hidden: true,
    components: [{
      type: 'projectile', speed: 34, model: 'arrow', lifetime: 3,
      onHit: [{ type: 'damage', school: 'physical', base: 3, coefficient: 0.9 }],
    }],
  },
  'attack.bite': {
    name: 'Biss', glyph: '𝕎', targeting: 'target', range: 2.4, cooldown: 1.7, mana: 0,
    animation: 'swing', hidden: true,
    components: [
      { type: 'damage', school: 'physical', base: 3, coefficient: 0.5 },
      { type: 'status_effect', effect: 'bleed', duration: 5, chance: 0.3 },
    ],
  },
  'attack.staff': {
    name: 'Magiegeschoss', glyph: '✳', targeting: 'target', range: 18, cooldown: 1.4, mana: 2,
    animation: 'cast', hidden: true,
    components: [{
      type: 'projectile', speed: 22, model: 'bolt', lifetime: 4,
      onHit: [{ type: 'damage', school: 'magic', base: 4, coefficient: 0.95 }],
    }],
  },
});

/** Standardbelegung, bis Drag & Drop dazukommt. */
export const DEFAULT_ACTION_BARS = [
  ['ability.strike', 'ability.shot', 'ability.firestorm', 'ability.frostnova', 'ability.heal', 'ability.thunderclap', null, 'ability.dodge'],
  ['ability.warcry', 'ability.imbue.fire', 'ability.chainlightning', 'ability.curse', null, null, null, null],
];
