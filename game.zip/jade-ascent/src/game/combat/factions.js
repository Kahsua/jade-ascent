/** Wer darf wen treffen. Bewusst schlicht: gleiche Fraktion = kein Ziel. */
export function isHostile(caster, target) {
  if (!caster || !target || caster.id === target.id) return false;
  return caster.template.faction !== target.template.faction;
}

export function isFriendly(caster, target) {
  return Boolean(caster && target) && caster.template.faction === target.template.faction;
}
