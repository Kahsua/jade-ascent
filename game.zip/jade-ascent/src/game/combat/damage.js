import { CONFIG } from '../../core/Config.js';

/**
 * Die eine Schadensformel. Jeder Treffer im Spiel läuft hier durch —
 * Spielerskill, Autoattack, Geschosseinschlag, Monsterangriff (Phase 7).
 *
 * Mitigation mit abnehmendem Ertrag, wie im Auftrag festgelegt:
 *   effektiv = roh * 100 / (100 + Verteidigung)
 * Niemand ist je immun; ein schlechter Build ist nur ineffizienter.
 *
 * Krit gilt für Waffen- UND Magiefähigkeiten gleichermaßen.
 */
export function computeRawDamage(caster, component) {
  const school = component.school ?? 'physical';
  const power = school === 'magic' ? caster.stats.magicPower : caster.stats.physicalPower;
  return (component.base ?? 0) + power * (component.coefficient ?? 0);
}

function defenseOf(target, school) {
  return school === 'magic' ? target.stats.magicResist : target.stats.armor;
}

export function mitigate(raw, defense) {
  const k = CONFIG.combat.defenseConstant;
  return raw * (k / (k + Math.max(0, defense)));
}

/**
 * Waffenverzauberung: addiert Magieschaden zum physischen Waffenschaden.
 * Der Anteil hängt vom Verhältnis STR:INT ab — wer auf Intelligenz geht,
 * holt mehr aus dem Bann heraus.
 */
function imbueBonus(caster, target, imbue) {
  if (!imbue) return 0;
  const { strength = 0, intelligence = 0 } = caster.state.attributes;
  const share = intelligence / Math.max(1, strength + intelligence);
  const raw = caster.stats.magicPower * imbue.coefficient * share;
  return mitigate(raw, defenseOf(target, imbue.school ?? 'magic'));
}

export function resolveDamage(caster, target, component, { rng = Math.random } = {}) {
  const school = component.school ?? 'physical';

  let raw = computeRawDamage(caster, component);
  raw *= caster.status?.damageDealtMultiplier?.() ?? 1;

  let amount = mitigate(raw, defenseOf(target, school));

  const imbue = school === 'physical' ? (caster.status?.imbue?.() ?? null) : null;
  const bonus = imbueBonus(caster, target, imbue);
  amount += bonus;

  const critical = rng() < (caster.stats.critChance ?? 0);
  if (critical) amount *= caster.stats.critDamage ?? 1.5;

  amount *= target.status?.damageTakenMultiplier?.() ?? 1;

  return {
    amount,
    raw,
    school,
    critical,
    mitigated: raw - mitigate(raw, defenseOf(target, school)),
    imbue: bonus > 0 ? { amount: bonus, onHit: imbue.onHit ?? null } : null,
  };
}
