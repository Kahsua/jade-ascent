import { heightAt } from '../Heightfield.js';

/**
 * Geschosse als reine Logik: Position, Richtung, Ziel, Restzeit.
 *
 * Ein Geschoss trägt seine eigenen onHit-Komponenten mit sich. Beim Einschlag
 * gibt es sie an denselben Executor zurück, der auch Sofortwirkungen abarbeitet
 * — deshalb braucht ein Pfeil keinen anderen Schadenspfad als ein Schwerthieb.
 *
 * Die Anzeige liest die Positionen pro Frame ab (all()), statt 60 Ereignisse
 * pro Sekunde und Geschoss zu bekommen.
 */
export class ProjectileSystem {
  #projectiles = new Map();
  #nextId = 1;

  constructor({ entities, bus }) {
    this.entities = entities;
    this.bus = bus;
    this.onHit = null; // wird vom AbilityExecutor gesetzt
  }

  spawn({ casterId, targetId, origin, direction, speed = 24, lifetime = 3, radius = 0.55, model = 'bolt', abilityId, components = [] }) {
    const id = `projectile_${this.#nextId += 1}`;
    const projectile = {
      id, casterId, targetId, abilityId, model, speed, radius,
      position: { x: origin.x, y: origin.y, z: origin.z },
      direction: { x: direction.x, z: direction.z },
      remaining: lifetime,
      components,
    };
    this.#projectiles.set(id, projectile);
    this.bus.emit('projectile:spawned', projectile);
    return projectile;
  }

  all() {
    return [...this.#projectiles.values()];
  }

  update(dt) {
    for (const projectile of this.#projectiles.values()) {
      const target = projectile.targetId ? this.entities.get(projectile.targetId) : null;

      // Leichte Zielsuche: das Geschoss dreht sich zum Ziel, statt starr zu
      // fliegen — sonst verfehlt jeder Pfeil ein laufendes Ziel.
      if (target?.isAlive) {
        const dx = target.position.x - projectile.position.x;
        const dz = target.position.z - projectile.position.z;
        const distance = Math.hypot(dx, dz) || 1;
        projectile.direction.x += ((dx / distance) - projectile.direction.x) * Math.min(1, dt * 9);
        projectile.direction.z += ((dz / distance) - projectile.direction.z) * Math.min(1, dt * 9);
        const length = Math.hypot(projectile.direction.x, projectile.direction.z) || 1;
        projectile.direction.x /= length;
        projectile.direction.z /= length;
      }

      projectile.position.x += projectile.direction.x * projectile.speed * dt;
      projectile.position.z += projectile.direction.z * projectile.speed * dt;
      projectile.position.y = heightAt(projectile.position.x, projectile.position.z) + 1.1;
      projectile.remaining -= dt;

      if (target?.isAlive) {
        const distance = Math.hypot(target.position.x - projectile.position.x, target.position.z - projectile.position.z);
        if (distance <= projectile.radius + 0.45) {
          this.#resolve(projectile, target);
          continue;
        }
      }

      if (projectile.remaining <= 0) this.#remove(projectile, false);
    }
  }

  #resolve(projectile, target) {
    const caster = this.entities.get(projectile.casterId);
    if (caster && this.onHit) {
      this.onHit({ caster, target, projectile, components: projectile.components });
    }
    this.bus.emit('vfx:impact', { position: { ...projectile.position }, model: projectile.model });
    this.#remove(projectile, true);
  }

  #remove(projectile, hit) {
    this.#projectiles.delete(projectile.id);
    this.bus.emit('projectile:removed', { id: projectile.id, hit });
  }
}
