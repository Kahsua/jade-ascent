import { abilities } from '../data/abilities.js';
import { componentHandlers } from './componentHandlers.js';
import { scaleAbility } from '../progression/scaling.js';

/**
 * EIN Executor für alle Fähigkeiten. Es gibt keine Skill-Klassen.
 *
 * Ablauf: prüfen (lebt, Abklingzeit/Ladung, Mana, Ziel, Reichweite) — dann die
 * Komponentenliste abarbeiten. Jeder Komponententyp hat genau einen Handler,
 * und Handler dürfen den Executor rekursiv aufrufen (siehe aoe).
 *
 * Der Executor hört auf "ability:requested" — dieselbe Meldung, die schon in
 * Phase 4 aus den Action-Bars kam. Ab Phase 7 senden Monster sie ebenfalls;
 * dafür ist hier nichts zu ändern.
 */
export class AbilityExecutor {
  constructor({ entities, bus, projectiles }) {
    this.entities = entities;
    this.bus = bus;
    this.projectiles = projectiles;

    projectiles.onHit = ({ caster, target, projectile, components }) => {
      this.runComponents(components, {
        executor: this,
        entities: this.entities,
        bus: this.bus,
        projectiles: this.projectiles,
        ability: { id: projectile.abilityId, ...(abilities.find(projectile.abilityId) ?? {}) },
        caster,
        target,
        point: null,
      });
    };

    bus.on('ability:requested', (request) => this.request(request));
  }

  /** @returns {boolean} ob die Fähigkeit ausgelöst wurde */
  request({ abilityId, casterId, targetId = null, point = null }) {
    const caster = this.entities.get(casterId);
    if (!caster || !caster.isAlive) return false;

    const definition = abilities.find(abilityId);
    if (!definition) return this.#deny(caster, `Unbekannte Fähigkeit: ${abilityId}`);

    // Nicht erlernte Fähigkeiten scheitern hier — Monster haben keine
    // Progressions-Komponente und sind davon nicht betroffen.
    if (caster.skills && !caster.skills.isUnlocked(abilityId)) {
      return this.#deny(caster, `${definition.name}: noch nicht erlernt`);
    }

    // Rang und Synergie-Boni fließen als skalierte Kopie ein; die
    // Registry-Daten bleiben unverändert.
    const rank = Math.max(1, caster.skills?.rankOf(abilityId) ?? 1);
    const ability = scaleAbility(
      { id: abilityId, ...definition },
      rank,
      caster.skills?.abilityBonus(abilityId) ?? 0,
    );

    // Die Gates des StatusEffectControllers sind die einzige Prüfung — der
    // Executor kennt weder Betäubung noch Verstummen beim Namen.
    if (!caster.status.canAct()) return this.#deny(caster, `${ability.name}: handlungsunfähig`);
    if ((ability.mana ?? 0) > 0 && !caster.status.canCast()) return this.#deny(caster, `${ability.name}: verstummt`);

    if (!caster.cooldowns.isReady(ability)) {
      const remaining = caster.cooldowns.remaining(abilityId);
      return this.#deny(caster, remaining > 0
        ? `${ability.name}: noch ${remaining.toFixed(1)} s`
        : `${ability.name}: keine Ladung frei`);
    }

    const target = targetId ? this.entities.get(targetId) : null;

    if (ability.targeting === 'target') {
      if (!target || !target.isAlive) return this.#deny(caster, `${ability.name}: kein gültiges Ziel`);
      const distance = Math.hypot(target.position.x - caster.position.x, target.position.z - caster.position.z);
      if (ability.range && distance > ability.range) {
        return this.#deny(caster, `${ability.name}: außer Reichweite (${distance.toFixed(1)} m von ${ability.range} m)`);
      }
    }

    if (ability.targeting === 'ground' && !point) return this.#deny(caster, `${ability.name}: kein Bodenpunkt`);

    if (ability.mana > 0 && !caster.resources.spendMana(ability.mana)) {
      return this.#deny(caster, `${ability.name}: nicht genug Mana (${ability.mana} nötig)`);
    }

    caster.cooldowns.consume(ability);

    this.bus.emit('ability:cast', {
      casterId: caster.id, abilityId, targetId: target?.id ?? null, point,
      animation: ability.animation ?? null, name: ability.name,
    });

    this.runComponents(ability.components ?? [], {
      executor: this,
      entities: this.entities,
      bus: this.bus,
      projectiles: this.projectiles,
      ability,
      caster,
      target,
      point,
    });

    return true;
  }

  /** Komponentenliste abarbeiten — auch verschachtelt aus einem Handler. */
  runComponents(components, context) {
    for (const component of components) {
      const handler = componentHandlers.find(component.type);
      if (!handler) {
        console.warn(`[AbilityExecutor] Kein Handler für Komponente "${component.type}"`);
        continue;
      }
      handler(context, component);
    }
  }

  #deny(caster, text) {
    // Nur der Spieler bekommt Meldungen; Monster scheitern still.
    if (caster.template.faction === 'player') this.bus.emit('ui:notice', { text, tone: 'warn' });
    return false;
  }
}
