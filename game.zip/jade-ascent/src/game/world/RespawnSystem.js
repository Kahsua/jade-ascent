/**
 * Gefallene kommen zurück: Monster nach der Zeit aus ihrem Template, der
 * Spieler an seinem Ausgangspunkt.
 *
 * Damit fallen die Testtasten aus den Phasen 3 bis 6 weg — die Welt setzt
 * sich von selbst zurück.
 */
export class RespawnSystem {
  #pending = [];

  constructor({ entities, bus, playerDelay = 6 }) {
    this.entities = entities;
    this.bus = bus;
    this.playerDelay = playerDelay;

    bus.on('entity:died', ({ id }) => this.#schedule(id));
  }

  #schedule(id) {
    const entity = this.entities.get(id);
    if (!entity) return;

    const isPlayer = entity.template.faction === 'player';
    const delay = isPlayer ? this.playerDelay : (entity.template.respawn ?? 25);
    if (delay <= 0) return;

    this.#pending.push({ id, remaining: delay, isPlayer });
    this.bus.emit('entity:defeated', { id, delay, isPlayer, name: entity.state.name });
  }

  update(dt) {
    for (let i = this.#pending.length - 1; i >= 0; i -= 1) {
      const entry = this.#pending[i];
      entry.remaining -= dt;
      if (entry.remaining > 0) continue;

      this.#pending.splice(i, 1);
      const entity = this.entities.get(entry.id);
      if (!entity) continue;

      const spawn = entity.state.spawnPoint;
      entity.state.position.x = spawn.x;
      entity.state.position.y = spawn.y;
      entity.state.position.z = spawn.z;
      entity.state.velocity.x = 0;
      entity.state.velocity.z = 0;
      entity.state.dash = null;
      entity.status.clear();
      entity.resources.revive();
      if (entity.ai) {
        entity.ai.targetId = null;
        entity.ai.state = 'idle';
      }

      this.bus.emit('entity:revived', { id: entity.id, atSpawn: true });
    }
  }
}
