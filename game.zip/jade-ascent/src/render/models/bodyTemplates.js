/**
 * Körperbau als DATEN, nicht als Code.
 *
 * Phase 1 hatte eine fest verdrahtete Figur. Ab hier ist jede Gestalt ein
 * Datensatz: Proportionen, Palette, Rig-Typ, Ausrüstungs-Slots. Ein neuer
 * Charakter- oder Monstertyp ist ein neuer Eintrag hier — kein neuer Code.
 *
 * "kind" wählt den Rig-Bauer (biped/quadruped), "animation" den Animator.
 * Beide werden über Registries aufgelöst, nicht über if/switch.
 */

const HUMAN_SLOTS = {
  mainHand: 'handR',
  offHand: 'handL',
  head: 'head',
  chest: 'chest',
  back: 'back',
};

const baseHuman = {
  kind: 'biped',
  animation: 'biped',
  scale: 1,
  slots: HUMAN_SLOTS,
  proportions: {
    hip: { y: 0.92, width: 0.34, height: 0.22, depth: 0.24 },
    torso: { offset: 0.14, width: 0.44, height: 0.5, depth: 0.26 },
    head: { size: 0.24, neck: 0.09, offset: 0.52 },
    arm: { shoulderY: 0.42, spread: 0.29, upper: 0.3, lower: 0.28, thickness: 0.078, splay: 0.14 },
    leg: { spread: 0.12, upper: 0.44, lower: 0.4, thickness: 0.1 },
  },
  palette: {
    skin: '#c58c5f',
    hair: '#33231a',
    tunic: '#3d6d59',
    trousers: '#3a4351',
    leather: '#5d452f',
    metal: '#98a2ab',
  },
};

/** Tiefes Verschmelzen für Template-Varianten. */
function extend(base, overrides) {
  const result = { ...base };
  for (const [key, value] of Object.entries(overrides)) {
    if (value && typeof value === 'object' && !Array.isArray(value) && typeof base[key] === 'object') {
      result[key] = extend(base[key], value);
    } else {
      result[key] = value;
    }
  }
  return result;
}

export const BODY_TEMPLATES = [
  extend(baseHuman, {
    id: 'character.player',
    label: 'Wanderer',
    palette: { tunic: '#2f6f66', trousers: '#37404e', leather: '#6b4f33' },
  }),

  extend(baseHuman, {
    id: 'character.villager',
    label: 'Dorfbewohner',
    palette: { tunic: '#8a6d3f', trousers: '#4a4238', hair: '#503a24' },
  }),

  extend(baseHuman, {
    id: 'character.warrior',
    label: 'Kriegerin',
    scale: 1.08,
    proportions: {
      torso: { width: 0.52, depth: 0.31 },
      arm: { thickness: 0.095, spread: 0.32 },
      leg: { thickness: 0.115 },
    },
    palette: { tunic: '#6d3a35', trousers: '#3b3630', leather: '#4a3524', metal: '#b6bcc2' },
  }),

  extend(baseHuman, {
    id: 'character.archer',
    label: 'Jäger',
    scale: 0.97,
    proportions: {
      torso: { width: 0.4, depth: 0.23 },
      arm: { thickness: 0.068 },
      leg: { thickness: 0.09 },
    },
    palette: { tunic: '#4a6034', trousers: '#3f4438', hair: '#6b4a22', skin: '#b57f52' },
  }),

  extend(baseHuman, {
    id: 'character.mage',
    label: 'Magierin',
    scale: 0.99,
    proportions: {
      torso: { height: 0.54, width: 0.42 },
      arm: { thickness: 0.07 },
    },
    palette: { tunic: '#4b3a72', trousers: '#332b45', hair: '#2a2230', leather: '#5c4a7a', skin: '#d0a077' },
  }),

  {
    id: 'beast.wolf',
    label: 'Waldwolf',
    kind: 'quadruped',
    animation: 'quadruped',
    scale: 1,
    slots: { head: 'head', back: 'back' },
    proportions: {
      body: { y: 0.66, length: 1.1, width: 0.44, height: 0.46 },
      head: { size: 0.3, snout: 0.22, offset: 0.72 },
      leg: { spreadX: 0.19, spreadZ: 0.38, upper: 0.32, lower: 0.3, thickness: 0.085 },
      tail: { segments: 2, length: 0.28, thickness: 0.06 },
    },
    palette: {
      fur: '#6a6259',
      furDark: '#4a443d',
      skin: '#2b2723',
      metal: '#98a2ab',
      leather: '#5d452f',
    },
  },
];
