import { CONFIG } from '../../core/Config.js';

const NO_ARM = {};

/**
 * Kurze Überlagerungen für Fähigkeiten. Jede Geste beschreibt, wie stark
 * Schulter und Ellbogen des jeweiligen Arms über ihre Grundhaltung
 * hinausgehen; der Verlauf ist eine halbe Sinuswelle.
 */
const GESTURES = {
  swing: { duration: 0.42, mainShoulder: -2.1, mainElbow: 0.6, torso: 0.3 },
  shoot: { duration: 0.35, mainShoulder: -0.35, mainElbow: -0.5, offShoulder: -0.3, torso: 0.12 },
  cast: { duration: 0.5, mainShoulder: -1.5, mainElbow: 0.35, offShoulder: -1.2, torso: -0.15 },
  dash: { duration: 0.3, mainShoulder: 0.8, offShoulder: 0.8, torso: 0.45 },
};

/**
 * Prozedurale Lauf-/Idle-Animation für Zweibeiner.
 *
 * Neu in Phase 2: setPose(). Eine ausgerüstete Waffe liefert eine Armhaltung
 * mit, die die Grundrotation der Arme verschiebt und den Schwung dämpft — ein
 * Bogen wird vorgestreckt gehalten, ein Großschwert beidhändig, ein Dolch
 * schwingt fast frei mit.
 *
 * Ab Phase 5 legt sich ein AnimationController darüber, der auf
 * "ability:cast" hört und Oberkörper-Posen überlagert. Die Beine bleiben hier.
 */
export class BipedLocomotion {
  constructor(model) {
    this.parts = model.parts;
    this.phase = 0;
    this.pose = null;
    this.gesture = null;
    this.hipRestY = this.parts.hips.position.y;
    this.torsoRestY = this.parts.torso.position.y;
    this.restZ = {
      L: this.parts.shoulderL.userData.restZ ?? this.parts.shoulderL.rotation.z,
      R: this.parts.shoulderR.userData.restZ ?? this.parts.shoulderR.rotation.z,
    };
  }

  /** Kurze Fähigkeiten-Geste über die Laufanimation legen. */
  triggerGesture(name) {
    const gesture = GESTURES[name];
    if (!gesture) return;
    this.gesture = { ...gesture, elapsed: 0 };
  }

  /** @param {{mainArm?: object, offArm?: object}|null} pose */
  setPose(pose) {
    this.pose = pose;
  }

  #arm(side, armPose, swing, stride, blend, mirror) {
    const p = this.parts;
    const shoulder = p[`shoulder${side}`];
    const elbow = p[`elbow${side}`];
    const damping = armPose.swing ?? 1;

    shoulder.rotation.x = (armPose.x ?? 0) + swing * stride * 0.75 * damping * mirror;
    shoulder.rotation.y = (armPose.y ?? 0) * (side === 'L' ? -1 : 1);
    shoulder.rotation.z = this.restZ[side] + (armPose.z ?? 0) * (side === 'L' ? -1 : 1);
    elbow.rotation.x = (armPose.elbow ?? -0.22) - Math.max(0, swing * mirror) * 0.55 * blend * damping;
  }

  update(dt, speed, maxSpeed = CONFIG.player.walkSpeed) {
    const p = this.parts;
    const blend = Math.min(speed / maxSpeed, 1);

    this.phase += dt * (2.1 + blend * 7.4);
    const swing = Math.sin(this.phase);
    const stride = 0.82 * blend;

    p.hipL.rotation.x = swing * stride;
    p.hipR.rotation.x = -swing * stride;
    p.kneeL.rotation.x = Math.max(0, -swing) * 1.15 * blend;
    p.kneeR.rotation.x = Math.max(0, swing) * 1.15 * blend;
    p.ankleL.rotation.x = -p.kneeL.rotation.x * 0.4;
    p.ankleR.rotation.x = -p.kneeR.rotation.x * 0.4;

    this.#arm('R', this.pose?.mainArm ?? NO_ARM, swing, stride, blend, 1);
    this.#arm('L', this.pose?.offArm ?? NO_ARM, swing, stride, blend, -1);

    let lean = 0;
    if (this.gesture) {
      this.gesture.elapsed += dt;
      const t = this.gesture.elapsed / this.gesture.duration;
      if (t >= 1) {
        this.gesture = null;
      } else {
        const curve = Math.sin(t * Math.PI);
        p.shoulderR.rotation.x += (this.gesture.mainShoulder ?? 0) * curve;
        p.elbowR.rotation.x += (this.gesture.mainElbow ?? 0) * curve;
        p.shoulderL.rotation.x += (this.gesture.offShoulder ?? 0) * curve;
        p.elbowL.rotation.x += (this.gesture.offElbow ?? 0) * curve;
        lean = (this.gesture.torso ?? 0) * curve;
      }
    }
    p.torso.rotation.x = lean;

    p.hips.rotation.y = swing * 0.09 * blend;
    p.torso.rotation.y = -swing * 0.13 * blend;
    p.hips.position.y = this.hipRestY + Math.abs(swing) * 0.042 * blend;

    const idle = 1 - blend;
    p.torso.position.y = this.torsoRestY + Math.sin(this.phase * 0.55) * 0.013 * idle;
    p.head.rotation.z = Math.sin(this.phase * 0.4) * 0.02 * idle;
  }
}
