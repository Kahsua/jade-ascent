import { CONFIG } from '../../core/Config.js';

/**
 * Vierbeiner: diagonale Beinpaare (Trab), dazu Kopfnicken und Schwanzwedeln.
 * Gleiche Schnittstelle wie BipedLocomotion, damit Views nichts unterscheiden
 * müssen — setPose() ist hier bewusst wirkungslos.
 */
export class QuadrupedLocomotion {
  constructor(model) {
    this.parts = model.parts;
    this.phase = 0;
    this.bodyRestY = this.parts.body.position.y;
    this.kneeRest = {
      FL: this.parts.kneeFL.userData.restX ?? 0,
      FR: this.parts.kneeFR.userData.restX ?? 0,
      BL: this.parts.kneeBL.userData.restX ?? 0,
      BR: this.parts.kneeBR.userData.restX ?? 0,
    };
  }

  setPose() {}

  triggerGesture() {}

  update(dt, speed, maxSpeed = CONFIG.player.walkSpeed) {
    const p = this.parts;
    const blend = Math.min(speed / maxSpeed, 1);

    this.phase += dt * (2.4 + blend * 9);
    const a = Math.sin(this.phase);
    const b = Math.sin(this.phase + Math.PI);
    const stride = 0.7 * blend;

    // Diagonalpaare: vorne links läuft mit hinten rechts.
    p.legFL.rotation.x = a * stride;
    p.legBR.rotation.x = a * stride;
    p.legFR.rotation.x = b * stride;
    p.legBL.rotation.x = b * stride;

    p.kneeFL.rotation.x = this.kneeRest.FL + Math.max(0, -a) * 0.7 * blend;
    p.kneeBR.rotation.x = this.kneeRest.BR - Math.max(0, -a) * 0.7 * blend;
    p.kneeFR.rotation.x = this.kneeRest.FR + Math.max(0, -b) * 0.7 * blend;
    p.kneeBL.rotation.x = this.kneeRest.BL - Math.max(0, -b) * 0.7 * blend;

    p.body.position.y = this.bodyRestY + Math.abs(a) * 0.035 * blend;
    p.body.rotation.z = a * 0.05 * blend;
    p.head.rotation.x = 0.35 + Math.sin(this.phase * 2) * 0.05 * blend;

    const idle = 1 - blend;
    const wag = Math.sin(this.phase * (1.4 + blend * 2));
    p.tail.forEach((segment, index) => {
      segment.rotation.y = wag * (0.22 + index * 0.16) * (0.5 + idle * 0.5);
      segment.rotation.x = 0.7 - blend * 0.35;
    });
    p.neck.rotation.y = Math.sin(this.phase * 0.35) * 0.12 * idle;
  }
}
