import * as THREE from 'three';
import { heightAt } from '../game/Heightfield.js';

const STYLE_COLORS = {
  fire: '#e07a3c',
  frost: '#6fc7e8',
  slash: '#e9e4d6',
  impact: '#ffd9a0',
};

/**
 * Kurzlebige Treffer- und Flächeneffekte.
 *
 * Nur Anzeige: die Schicht hört auf "vfx:aoe" und "vfx:impact", die von den
 * Komponenten-Handlern gemeldet werden. Die Spiellogik weiß nichts davon.
 */
export class EffectLayer {
  #active = [];

  constructor({ scene, bus }) {
    this.scene = scene;

    this.ringGeometry = new THREE.RingGeometry(0.72, 1, 40);
    this.ringGeometry.rotateX(-Math.PI / 2);
    this.sparkGeometry = new THREE.IcosahedronGeometry(0.2, 0);

    bus.on('vfx:aoe', ({ point, radius, style }) => this.#burst(point, radius, style));
    bus.on('vfx:impact', ({ position }) => this.#spark(position));
  }

  #burst(point, radius, style) {
    const material = new THREE.MeshBasicMaterial({
      color: STYLE_COLORS[style] ?? STYLE_COLORS.fire,
      transparent: true,
      opacity: 0.85,
      side: THREE.DoubleSide,
      depthWrite: false,
    });
    const mesh = new THREE.Mesh(this.ringGeometry, material);
    mesh.position.set(point.x, heightAt(point.x, point.z) + 0.09, point.z);
    mesh.renderOrder = 3;
    this.scene.add(mesh);
    this.#active.push({ mesh, material, life: 0, duration: 0.55, from: radius * 0.25, to: radius, kind: 'ring' });
  }

  #spark(position) {
    const material = new THREE.MeshBasicMaterial({ color: STYLE_COLORS.impact, transparent: true, opacity: 0.9 });
    const mesh = new THREE.Mesh(this.sparkGeometry, material);
    mesh.position.set(position.x, position.y, position.z);
    this.scene.add(mesh);
    this.#active.push({ mesh, material, life: 0, duration: 0.28, from: 0.4, to: 1.6, kind: 'spark' });
  }

  update(dt) {
    for (let i = this.#active.length - 1; i >= 0; i -= 1) {
      const effect = this.#active[i];
      effect.life += dt;
      const t = effect.life / effect.duration;

      if (t >= 1) {
        this.scene.remove(effect.mesh);
        effect.material.dispose();
        this.#active.splice(i, 1);
        continue;
      }

      const scale = effect.from + (effect.to - effect.from) * (effect.kind === 'ring' ? Math.sqrt(t) : t);
      effect.mesh.scale.setScalar(scale);
      effect.material.opacity = (1 - t) * 0.9;
      if (effect.kind === 'spark') effect.mesh.rotation.y += dt * 8;
    }
  }
}
