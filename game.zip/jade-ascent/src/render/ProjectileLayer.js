import * as THREE from 'three';
import { makeMetalTexture, makeBarkTexture } from './TextureFactory.js';

/**
 * Anzeige der Geschosse. Positionen werden pro Frame aus dem
 * ProjectileSystem abgelesen — nur Entstehen und Vergehen laufen über
 * Ereignisse.
 */
const builders = {
  arrow(materials) {
    const group = new THREE.Group();
    const shaft = new THREE.Mesh(new THREE.CylinderGeometry(0.018, 0.018, 0.7, 5), materials.wood);
    shaft.rotation.x = Math.PI / 2;
    const tip = new THREE.Mesh(new THREE.ConeGeometry(0.04, 0.12, 4), materials.steel);
    tip.rotation.x = Math.PI / 2;
    tip.position.z = 0.4;
    const fletching = new THREE.Mesh(new THREE.BoxGeometry(0.09, 0.002, 0.12), materials.steel);
    fletching.position.z = -0.3;
    group.add(shaft, tip, fletching);
    return group;
  },
  bolt(materials) {
    const group = new THREE.Group();
    const core = new THREE.Mesh(new THREE.IcosahedronGeometry(0.16, 0), materials.arcane);
    const halo = new THREE.Mesh(new THREE.IcosahedronGeometry(0.26, 0), materials.arcaneHalo);
    group.add(core, halo);
    return group;
  },
};

export class ProjectileLayer {
  #meshes = new Map();

  constructor({ scene, bus, projectiles }) {
    this.scene = scene;
    this.projectiles = projectiles;

    this.materials = {
      wood: new THREE.MeshStandardMaterial({ map: makeBarkTexture({ color: '#6b4a2c' }), roughness: 0.9 }),
      steel: new THREE.MeshStandardMaterial({ map: makeMetalTexture({ color: '#c2c8ce' }), roughness: 0.4, metalness: 0.7 }),
      arcane: new THREE.MeshBasicMaterial({ color: '#68e0c8' }),
      arcaneHalo: new THREE.MeshBasicMaterial({ color: '#3fae9a', transparent: true, opacity: 0.28, wireframe: true }),
    };

    bus.on('projectile:spawned', (projectile) => this.#add(projectile));
    bus.on('projectile:removed', ({ id }) => this.#remove(id));
  }

  #add(projectile) {
    const build = builders[projectile.model] ?? builders.bolt;
    const mesh = build(this.materials);
    mesh.position.set(projectile.position.x, projectile.position.y, projectile.position.z);
    this.scene.add(mesh);
    this.#meshes.set(projectile.id, mesh);
  }

  #remove(id) {
    const mesh = this.#meshes.get(id);
    if (!mesh) return;
    this.scene.remove(mesh);
    mesh.traverse((child) => child.geometry?.dispose?.());
    this.#meshes.delete(id);
  }

  sync(dt) {
    for (const projectile of this.projectiles.all()) {
      const mesh = this.#meshes.get(projectile.id);
      if (!mesh) continue;
      mesh.position.set(projectile.position.x, projectile.position.y, projectile.position.z);
      mesh.rotation.y = Math.atan2(projectile.direction.x, projectile.direction.z);
      if (projectile.model === 'bolt') mesh.rotation.z += dt * 6;
    }
  }
}
