import * as THREE from 'three';
import { mulberry32 } from '../core/math.js';
import { heightAt, slopeAt, WORLD_HALF } from '../game/Heightfield.js';
import { makeBarkTexture, makeNoiseTexture } from './TextureFactory.js';

/**
 * Bäume und Felsen aus mehreren Primitiven, deterministisch platziert.
 *
 * Rückgabe trennt bewusst zwei Dinge:
 *  - group      -> Anzeige (Meshes, Kamera-Kollision)
 *  - colliders  -> reine Daten ({x, z, radius}) für die Logikschicht
 * Die Bewegung sieht also nie ein Mesh.
 */
export function buildEnvironment({ trees = 110, rocks = 60, seed = 20260910, clearing = 11 } = {}) {
  const random = mulberry32(seed);
  const group = new THREE.Group();
  group.name = 'environment';
  const colliders = [];

  const barkMaterial = new THREE.MeshStandardMaterial({ map: makeBarkTexture({ color: '#59422e', repeat: 2 }), roughness: 0.95 });
  const foliageMaterials = ['#3f6b34', '#4c7c3c', '#355c30'].map((color) =>
    new THREE.MeshStandardMaterial({ map: makeNoiseTexture({ color, variance: 20 }), roughness: 0.9, flatShading: true }));
  const rockMaterials = ['#7d7f7a', '#6b6d69'].map((color) =>
    new THREE.MeshStandardMaterial({ map: makeNoiseTexture({ color, variance: 22 }), roughness: 1, flatShading: true }));

  const placement = () => {
    for (let attempt = 0; attempt < 24; attempt += 1) {
      const x = (random() * 2 - 1) * (WORLD_HALF - 4);
      const z = (random() * 2 - 1) * (WORLD_HALF - 4);
      if (Math.hypot(x, z) < clearing) continue;
      if (slopeAt(x, z) > 0.55) continue;
      return { x, z, y: heightAt(x, z) };
    }
    return null;
  };

  for (let i = 0; i < trees; i += 1) {
    const spot = placement();
    if (!spot) continue;

    const tree = new THREE.Group();
    const height = 2.1 + random() * 2.4;
    const radius = 0.17 + random() * 0.11;

    const trunk = new THREE.Mesh(new THREE.CylinderGeometry(radius * 0.7, radius, height, 7), barkMaterial);
    trunk.position.y = height / 2;
    trunk.castShadow = true;
    trunk.receiveShadow = true;
    tree.add(trunk);

    const foliage = foliageMaterials[Math.floor(random() * foliageMaterials.length)];
    const crowns = 3;
    for (let c = 0; c < crowns; c += 1) {
      const t = c / crowns;
      const cone = new THREE.Mesh(
        new THREE.ConeGeometry(1.5 - t * 0.75 + random() * 0.2, 1.5 - t * 0.35, 7),
        foliage,
      );
      cone.position.y = height * 0.72 + c * 0.75;
      cone.rotation.y = random() * Math.PI;
      cone.castShadow = true;
      tree.add(cone);
    }

    tree.position.set(spot.x, spot.y, spot.z);
    tree.rotation.y = random() * Math.PI * 2;
    group.add(tree);
    colliders.push({ x: spot.x, z: spot.z, radius: radius + 0.25 });
  }

  for (let i = 0; i < rocks; i += 1) {
    const spot = placement();
    if (!spot) continue;

    const rock = new THREE.Group();
    const material = rockMaterials[Math.floor(random() * rockMaterials.length)];
    const chunks = 1 + Math.floor(random() * 3);
    let widest = 0;

    for (let c = 0; c < chunks; c += 1) {
      const size = 0.35 + random() * 0.85;
      const mesh = new THREE.Mesh(new THREE.IcosahedronGeometry(size, 0), material);
      mesh.position.set((random() - 0.5) * 0.9, size * (0.35 + random() * 0.2), (random() - 0.5) * 0.9);
      mesh.rotation.set(random() * Math.PI, random() * Math.PI, random() * Math.PI);
      mesh.scale.set(1, 0.7 + random() * 0.5, 1);
      mesh.castShadow = true;
      mesh.receiveShadow = true;
      rock.add(mesh);
      widest = Math.max(widest, size + Math.hypot(mesh.position.x, mesh.position.z));
    }

    rock.position.set(spot.x, spot.y - 0.15, spot.z);
    group.add(rock);
    colliders.push({ x: spot.x, z: spot.z, radius: widest * 0.75 });
  }

  return { group, colliders };
}
