import * as THREE from 'three';
import { CONFIG } from '../../core/Config.js';
import { lerpAngle, smoothing } from '../../core/math.js';
import { createAnimator } from '../animation/createAnimator.js';
import { assets } from '../AssetRegistry.js';

/**
 * Brücke zwischen Logikzustand und Mesh — für Spieler, NPCs und ab Phase 7
 * auch Monster. Der View kennt nur { position, facing, speed }.
 *
 * Die Logik läuft im festen 60-Hz-Takt, gerendert wird mit Monitorrate; der
 * View interpoliert deshalb, statt Werte hart zu setzen.
 */
export class CharacterView {
  constructor(modelId, options = {}) {
    this.model = assets.createModel(modelId, options);
    this.root = this.model.root;
    this.animator = createAnimator(this.model);
    this.equipped = new Map();

    this._facing = 0;
    this._target = new THREE.Vector3();
    this._snapped = false;
    this.dead = false;
    this.maxSpeed = options.maxSpeed ?? CONFIG.player.walkSpeed;
  }

  /**
   * Ausrüstung sichtbar machen. Die Armhaltung folgt aus den Item-Daten,
   * nicht aus einer Fallunterscheidung im Animator.
   */
  equip(slot, attachmentId) {
    const definition = assets.equip(this.model, slot, attachmentId);
    if (definition) this.equipped.set(slot, { id: attachmentId, definition });
    else this.equipped.delete(slot);
    this.#refreshPose();
    return definition;
  }

  #refreshPose() {
    let pose = null;
    for (const { definition } of this.equipped.values()) {
      if (!definition.pose) continue;
      pose = { ...(pose ?? {}), ...definition.pose };
    }
    this.animator.setPose(pose);
  }

  equippedLabel(slot) {
    const entry = this.equipped.get(slot);
    return entry ? entry.definition.label : null;
  }

  /** Nach einem Respawn: nicht zur neuen Position gleiten, sondern springen. */
  snap() {
    this._snapped = false;
  }

  /** Kurze Animation für eine eingesetzte Fähigkeit. */
  playGesture(name) {
    if (!this.dead) this.animator.triggerGesture?.(name);
  }

  /** Sichtbarer Tod: die Figur kippt zur Seite und friert ein. */
  setDead(dead) {
    this.dead = dead;
    this.root.rotation.z = dead ? Math.PI / 2.1 : 0;
    this.root.position.y += dead ? 0.25 : 0;
  }

  sync(state, dt) {
    this._target.set(state.position.x, state.position.y, state.position.z);

    if (!this._snapped) {
      this.root.position.copy(this._target);
      this._facing = state.facing ?? 0;
      this._snapped = true;
    } else {
      this.root.position.lerp(this._target, smoothing(22, dt));
      this._facing = lerpAngle(this._facing, state.facing ?? 0, smoothing(CONFIG.player.turnRate * 1.5, dt));
    }

    if (this.dead) return;

    this.root.rotation.y = this._facing;
    this.animator.update(dt, state.speed ?? 0, this.maxSpeed);
  }

  dispose() {
    this.model.dispose?.();
  }
}
